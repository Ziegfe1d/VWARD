'use strict';
(function () {

/* ---------- Утилиты ---------- */
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const dom = d => esc(d).replace(/\./g, '.<wbr>');
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* хранилище браузера недоступно */ } },
  del(k) { try { localStorage.removeItem(k); } catch (e) { /* хранилище браузера недоступно */ } }
};
const num = v => (v == null || v === '' || isNaN(Number(v))) ? null : Number(v);
const fmtInt = v => num(v) == null ? '—' : Number(v).toLocaleString('ru-RU');
const fmtKB = kb => { const n = num(kb); if (n == null) return '—'; if (n >= 1048576) return (n / 1048576).toFixed(1).replace('.', ',') + ' ГБ'; if (n >= 1024) return Math.round(n / 1024) + ' МБ'; return n + ' КБ'; };
/* Как пришло последнее обновление: method.state пишется при каждой установке, last-apply.state - только по файлам. */
const lastApplyNote = (la, lm) => {
  if (lm && lm.method === 'full') return 'последнее обновление: целиком';
  if (!la) return '';
  const n = la.changed_files, kb = Math.ceil((la.fetched_bytes || 0) / 1024);
  return 'последнее обновление: ' + (lm ? 'изменённые файлы, ' : '') + (n ? 'заменено ' + n + ' ' + plural(n, 'файл', 'файла', 'файлов') + ', скачано ' + fmtKB(kb) : 'файлы не менялись');
};
const fmtUptime = s => { const n = num(s); if (n == null) return '—'; const d = Math.floor(n / 86400), h = Math.floor(n % 86400 / 3600), m = Math.floor(n % 3600 / 60); return d ? d + ' д ' + h + ' ч' : h ? h + ' ч ' + m + ' мин' : m + ' мин'; };
const fmtSpeed = v => { const n = num(v); return n == null ? '' : n >= 1000 ? (n / 1000).toString().replace('.', ',') + ' Гбит/с' : n + ' Мбит/с'; };
const isTrue = v => v === true || v === 'true' || v === '1' || v === 1 || v === 'yes' || v === 'up';
const IPV4 = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;
const DOMAIN = /^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/;

/* ---------- Иконки: одна сетка 24×24, одна толщина линии ---------- */
const ICON_PATHS = {
  tools: '<path d="M14.7 6.3a4 4 0 0 0-5.3 5.3L4 17v3h3l5.4-5.4a4 4 0 0 0 5.3-5.3l-2.5 2.5-2.6-.4-.4-2.6z"/>',
  home: '<path d="M4 10.5 12 4l8 6.5"/><path d="M6 9v11h4.5v-5.5h3V20H18V9"/>',
  platform: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5"/>',
  refresh: '<path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3"/><path d="M19.5 4.5V9H15"/>',
  power: '<path d="M12 3.5v8"/><path d="M7 6.2a7.5 7.5 0 1 0 10 0"/>',
  globe: '<circle cx="12" cy="12" r="8"/><path d="M4 12h16"/><path d="M12 4c2.2 2.3 3.2 5 3.2 8s-1 5.7-3.2 8c-2.2-2.3-3.2-5-3.2-8s1-5.7 3.2-8z"/>',
  shield: '<path d="M12 3.8 5.5 6.3v5c0 4.2 2.7 7.4 6.5 8.9 3.8-1.5 6.5-4.7 6.5-8.9v-5z"/><path d="m9.3 12.2 1.9 1.9 3.6-3.8"/>',
  route: '<circle cx="6.5" cy="17.5" r="2"/><circle cx="17.5" cy="6.5" r="2"/><path d="M8.5 17.5H15a3 3 0 0 0 0-6H9a3 3 0 0 1 0-6h6.5"/>',
  wifi: '<path d="M3.5 9.5a12 12 0 0 1 17 0"/><path d="M6.5 12.8a7.8 7.8 0 0 1 11 0"/><path d="M9.5 16a3.6 3.6 0 0 1 5 0"/><path d="M12 19.2h.01"/>',
  block: '<circle cx="12" cy="12" r="8"/><path d="m6.4 6.4 11.2 11.2"/>',
  pin: '<path d="M9 4h6l-1 5 3 3v2H7v-2l3-3z"/><path d="M12 14v6"/>',
  lock: '<rect x="5" y="10.5" width="14" height="9.5" rx="2"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/><path d="M12 14.5v2"/>',
  sliders: '<path d="M4 7h9"/><path d="M17 7h3"/><circle cx="15" cy="7" r="2"/><path d="M4 17h3"/><path d="M11 17h9"/><circle cx="9" cy="17" r="2"/>',
  list: '<rect x="4.5" y="3.5" width="15" height="17" rx="2"/><path d="M8 8h8"/><path d="M8 12h8"/><path d="M8 16h5"/>',
  logs: '<path d="M9 6.5h11"/><path d="M9 12h11"/><path d="M9 17.5h11"/><path d="M4.5 6.5h.01"/><path d="M4.5 12h.01"/><path d="M4.5 17.5h.01"/>',
  runtime: '<circle cx="12" cy="12" r="8"/><path d="M12 7.5V12l3 2"/>',
  storage: '<ellipse cx="12" cy="6.5" rx="7" ry="2.5"/><path d="M5 6.5v11c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5v-11"/><path d="M5 12c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5"/>',
  bell: '<path d="M6.5 16.5V11a5.5 5.5 0 0 1 11 0v5.5l1.5 1.5H5z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
  sun: '<circle cx="12" cy="12" r="3.8"/><path d="M12 3.5v1.8M12 18.7v1.8M3.5 12h1.8M18.7 12h1.8M6 6l1.3 1.3M16.7 16.7 18 18M6 18l1.3-1.3M16.7 7.3 18 6"/>',
  moon: '<path d="M19.5 14.2A7.8 7.8 0 1 1 9.8 4.5a6.2 6.2 0 0 0 9.7 9.7z"/>',
  auto: '<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor" stroke="none"/>',
  back: '<path d="M19 12H5.5"/><path d="m11 6-6 6 6 6"/>',
  chevron: '<path d="m9.5 6 6 6-6 6"/>',
  close: '<path d="m6.5 6.5 11 11M17.5 6.5l-11 11"/>',
  plus: '<path d="M12 5.5v13M5.5 12h13"/>',
  alert: '<path d="M12 4.5 3.5 19h17z"/><path d="M12 10v4"/><path d="M12 16.8h.01"/>',
  check: '<path d="m5.5 12.5 4 4 9-9"/>',
  edit: '<path d="M5 19h3.5L18.2 9.3a2 2 0 0 0-2.8-2.8L5.7 16.2z"/><path d="m14 8 2.8 2.8"/>',
  eye: '<path d="M3 12s3.3-6 9-6 9 6 9 6-3.3 6-9 6-9-6-9-6z"/><circle cx="12" cy="12" r="2.5"/>',
  eyeOff: '<path d="M4 4l16 16"/><path d="M9.9 6.3A9 9 0 0 1 12 6c5.7 0 9 6 9 6a15 15 0 0 1-2.6 3.3M6.3 7.7A15 15 0 0 0 3 12s3.3 6 9 6a8.7 8.7 0 0 0 3.6-.8"/>',
  more: '<path d="M5.5 12h.01M12 12h.01M18.5 12h.01"/>',
  undo: '<path d="M9 14.5 4.5 10 9 5.5"/><path d="M4.5 10H14a5.5 5.5 0 0 1 0 11h-2"/>',
  up: '<path d="m6 15 6-6 6 6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  copy: '<rect x="8.5" y="8.5" width="11" height="11" rx="2"/><path d="M15.5 8.5V6.5a2 2 0 0 0-2-2h-7a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h2"/>',
  share: '<circle cx="17.5" cy="6" r="2.2"/><circle cx="6.5" cy="12" r="2.2"/><circle cx="17.5" cy="18" r="2.2"/><path d="m8.5 11 7-3.9M8.5 13l7 3.9"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
  save: '<path d="M12 4.5v10"/><path d="m7.5 10.5 4.5 4.5 4.5-4.5"/><path d="M5 19.5h14"/>',
  archive: '<rect x="4" y="4.5" width="16" height="4.5" rx="1.5"/><path d="M5.5 9v9a1.5 1.5 0 0 0 1.5 1.5h10a1.5 1.5 0 0 0 1.5-1.5V9"/><path d="M10 13h4"/>',
  sort: '<path d="M7 4v16"/><path d="m4 17 3 3 3-3"/><path d="M13 6h7"/><path d="M13 12h5"/><path d="M13 18h3"/>',
  wrap: '<path d="M4 6.5h16"/><path d="M4 12h12.5a3 3 0 0 1 0 6H13"/><path d="m15 16-2 2 2 2"/><path d="M4 17.5h5"/>',
  trash: '<path d="M4.5 7h15"/><path d="M9.5 7V5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2"/><path d="M6.5 7l.8 11.5a1.5 1.5 0 0 0 1.5 1.5h6.4a1.5 1.5 0 0 0 1.5-1.5L17.5 7"/><path d="M10 11v5.5M14 11v5.5"/>',
  broom: '<path d="M19.5 4.5 12 12"/><path d="M12.5 11.5 8.8 9.2c-1.1-.7-2.6-.4-3.3.7L4 12.5l7.5 7.5 2.6-1.5c1.1-.7 1.4-2.2.7-3.3z"/><path d="m7 15 2.5 2.5"/>',
  download: '<path d="M12 4.5v10"/><path d="m7.5 10 4.5 4.5 4.5-4.5"/><path d="M5 19.5h14"/>',
  box: '<path d="M4 8 12 4l8 4v8l-8 4-8-4z"/><path d="m4 8 8 4 8-4"/><path d="M12 12v8"/>',
  clock: '<circle cx="12" cy="12" r="8"/><path d="M12 7.5V12l3 2"/>',
  server: '<rect x="4" y="4.5" width="16" height="6" rx="1.5"/><rect x="4" y="13.5" width="16" height="6" rx="1.5"/><path d="M7.5 7.5h.01M7.5 16.5h.01"/>',
  usb: '<rect x="7.5" y="9" width="9" height="11.5" rx="1.5"/><path d="M9.5 9V4h5v5"/><path d="M11 6h.01M13 6h.01"/>',
  flag: '<path d="M5.5 20.5V4.5"/><path d="M5.5 5h11l-2 4 2 4h-11"/>',
  key: '<circle cx="8" cy="15" r="3.5"/><path d="m10.5 12.5 8-8"/><path d="m16 7 2.5 2.5"/><path d="m13.5 9.5 2 2"/>',
  cpu: '<rect x="6.5" y="6.5" width="11" height="11" rx="1.5"/><rect x="9.5" y="9.5" width="5" height="5"/><path d="M9.5 3.5v3M14.5 3.5v3M9.5 17.5v3M14.5 17.5v3M3.5 9.5h3M3.5 14.5h3M17.5 9.5h3M17.5 14.5h3"/>',
  logout: '<path d="M9.5 4.5h-3a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h3"/><path d="M14 8l4 4-4 4"/><path d="M18 12H9"/>',
  reset: '<path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3"/><path d="M4.5 4.5V9H9"/><path d="M12 9v3l2 1.5"/>',
  spark: '<path d="M12 3.5 13.8 9 19.5 10.5 13.8 12 12 17.5 10.2 12 4.5 10.5 10.2 9z"/><path d="M18.5 16v4M16.5 18h4"/>',
  dns: '<circle cx="12" cy="12" r="8"/><path d="M4 12h16"/><path d="M12 4c2.2 2.3 3.2 5 3.2 8s-1 5.7-3.2 8"/><path d="M15.5 17.5h5M18 15v5"/>',
  filter: '<path d="M4.5 5.5h15l-6 7v5.5l-3 1.5v-7z"/>',
  cert: '<rect x="4" y="4.5" width="16" height="11" rx="1.5"/><path d="M7.5 8.5h9M7.5 11.5h5"/><circle cx="15.5" cy="16.5" r="2.5"/><path d="m14.2 18.6-.7 2.4 2-1 2 1-.7-2.4"/>',
  info: '<circle cx="12" cy="12" r="8"/><path d="M12 11v5"/><path d="M12 8h.01"/>',
  help: '<circle cx="12" cy="12" r="8.5"/><path d="M9.7 9.6a2.4 2.4 0 1 1 3.4 2.2c-.7.3-1.1.9-1.1 1.6v.4"/><path d="M12 16.8h.01"/>',
  pulse: '<path d="M3.5 12h4l2-5 4 10 2-5h5"/>',
  external: '<path d="M14 4.5h5.5V10"/><path d="M19.5 4.5 11 13"/><path d="M18 13.5V18a1.5 1.5 0 0 1-1.5 1.5h-10A1.5 1.5 0 0 1 5 18V8a1.5 1.5 0 0 1 1.5-1.5H11"/>'
};
function iconSvg(name, cls) { return '<svg class="icon' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + (ICON_PATHS[name] || ICON_PATHS.platform) + '</svg>'; }
const ico = iconSvg;

/* ---------- API ---------- */
const API = '/cgi-bin/api.cgi';
// The 20 s cover the whole answer, its body too (fix.35.4: the timer stopped with the headers and a
// body that stopped coming left «проверяется…» for ever); apiBody reads it within them and aborts.
async function apiFetch(url, options) {
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 20000);
  let r;
  try { r = await fetch(url, Object.assign({ cache: 'no-store', credentials: 'same-origin' }, options || {}, { signal: controller.signal })); }
  catch (e) { clearTimeout(timer); throw new Error(e.name === 'AbortError' ? 'роутер не ответил за 20 секунд' : 'нет связи с роутером'); }
  r.vwardDone = () => clearTimeout(timer);
  if (r.status === 401) { showLogin(); throw new Error('нужно войти'); }
  if (r.status === 403 && r.headers.get('Content-Type') && r.headers.get('Content-Type').includes('json')) {
    const x = await r.clone().json().catch(() => ({}));
    if (x.error === 'device_not_registered') { showDeviceBlocked(); throw new Error('устройство не зарегистрировано'); }
  }
  return r;
}
async function apiBody(r) {
  try { return await r.text(); }
  catch (e) { throw new Error(e.name === 'AbortError' ? 'роутер не передал ответ за 20 секунд' : 'ответ роутера оборвался'); }
  finally { if (r.vwardDone) r.vwardDone(); }
}
async function apiJson(r) {
  const t = await apiBody(r);
  if (!t.trim()) throw new Error('роутер вернул пустой ответ');
  let x;
  try { x = JSON.parse(t); } catch (e) { throw new Error('роутер вернул неполный ответ'); }
  if (x && x.error === 'jq_broken') throw new Error(API_ERRORS.jq_broken);
  return x;
}
async function apiGet(action, params) {
  const q = new URLSearchParams(Object.assign({ action: action }, params || {}));
  return apiJson(await apiFetch(API + '?' + q.toString()));
}
// A journal text: an HTTP error, a JSON error instead of the text or a body that stops coming are
// failures, never an empty journal (fix.35.3: apiFetch's 20 s end with the headers, not the body).
async function apiText(action, params) {
  const q = new URLSearchParams(Object.assign({ action: action }, params || {}));
  const r = await apiFetch(API + '?' + q.toString());
  if (!r.ok) { if (r.vwardDone) r.vwardDone(); throw new Error('роутер ответил ошибкой HTTP ' + r.status); }
  let tm;
  const t = await Promise.race([apiBody(r), new Promise((_, no) => { tm = setTimeout(() => no(new Error('роутер не передал ответ за 20 секунд')), 20000); })])
    .finally(() => clearTimeout(tm));
  if (/^\s*\{\s*"ok"\s*:\s*false/.test(t)) { let x = {}; try { x = JSON.parse(t); } catch (e) { /* a cut answer */ } throw new Error(x.error ? errText(x) : 'роутер вернул ошибку вместо журнала'); }
  return t;
}
async function apiPost(action, fields) {
  const r = await apiFetch(API + '?action=' + encodeURIComponent(action), {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-VWARD-Request': 'console' },
    body: new URLSearchParams(fields).toString()
  });
  return apiJson(r);
}
/* ---------- Стабильность ---------- */
// Index of the hours given (the watcher's hourly lines: at, dns_ok, dns_fail, events,
// repairs_ok, repairs_failed, mem_min_kb, load_max_x100, programs_gone, leaks) and of the
// checks the watcher does not do (CHK, stabChecks): DNS answered 28, VWARD's programs kept
// running 14, repairs that helped 14, enough memory 14, tunnel passed traffic 10, updates
// downloaded 10, HTTPS 5, Keenetic answered in time 5. A part with nothing checked is left out,
// not counted as 100%; less than half of the weight checked - no index («не проверено»).
const STAB_W = { dns: 28, progs: 14, rep: 14, res: 14, tunnel: 10, feed: 10, https: 5, rci: 5 };
function stabScore(rows, chk) {
  if (!rows || !rows.length) return null;
  const sum = i => rows.reduce((a, r) => a + (Number(r[i]) || 0), 0);
  const dnsOk = sum(1), dnsFail = sum(2), ok = sum(4), bad = sum(5), downs = sum(8), leaks = sum(9);
  const known = rows.filter(r => r[6] >= 0), low = known.filter(r => r[6] < 16384).length;
  const dns = dnsOk + dnsFail ? dnsOk / (dnsOk + dnsFail) : null;
  // Programs: the share of hours without a program gone or a leak, not minus 10% each (fix.30).
  const progs = 1 - rows.filter(r => (Number(r[8]) || 0) + (Number(r[9]) || 0) > 0).length / rows.length;
  // Repairs by cases, not attempts: an hour whose repairs did not help is one case
  // (600 restarts of one tunnel were 600 «failures» before).
  const repH = rows.filter(r => (Number(r[4]) || 0) + (Number(r[5]) || 0) > 0), repBad = repH.filter(r => (Number(r[5]) || 0) > 0 && !(Number(r[4]) || 0)).length;
  const rep = repH.length ? 1 - repBad / repH.length : 1;
  const res = known.length ? 1 - low / known.length : null;
  const parts = Object.assign({ dns, progs, rep, res }, chk || {});
  let w = 0, v = 0;
  Object.keys(STAB_W).forEach(k => { if (parts[k] != null) { w += STAB_W[k]; v += STAB_W[k] * parts[k]; } });
  const total = Object.keys(STAB_W).reduce((a, k) => a + STAB_W[k], 0);
  return { index: w * 2 >= total ? Math.round(100 * v / w) : null, dns, dnsOk, dnsFail, ok, bad, downs, leaks, low, hours: rows.length };
}
// The checks the watcher does not do, each 0..1 or null (nothing checked): the routes tunnel
// passed traffic in the last hour (switched off by the owner - not counted), the update feed
// answered within two days, curl did not crash on HTTPS within the hour, Keenetic answered
// every request in time today.
function stabChecks(d) {
  const c = d && d.checks || {}, now = c.now || Date.now() / 1000, name = prof().tunnel_interface;
  const t = ((st().wg || {}).interfaces || []).find(x => x.name === name);
  const q = (c.tunnels || []).find(x => x.name === name);
  const tunnel = t && tunOff(t) ? null : q && q.n ? q.ok / q.n : null;
  const fresh = x => x && now - x < 2 * 86400;
  const feed = c.feed_fail_at > (c.feed_ok_at || 0) ? 0 : fresh(c.feed_ok_at) ? 1 : null;
  const https = c.https_crash_at ? 0 : fresh(c.feed_ok_at) ? 1 : null;
  // Keenetic: the share of refused requests among all of them (fix.30); without the counter
  // (an older router part) a smooth curve instead of «more than 10 - 0%».
  const rci = c.rci_fails_day == null ? null : c.rci_calls_day > 0 ? Math.max(0, 1 - c.rci_fails_day / c.rci_calls_day) : 1 / (1 + c.rci_fails_day / 20);
  return { tunnel, feed, https, rci, c, q, off: !!(t && tunOff(t)), name };
}
// The hours of the last SPAN seconds; the running hour from the watcher's own totals
// while no hourly line is written yet.
function stabRows(d, span) {
  const st = d && d.state || {}, now = st.now || Date.now() / 1000;
  const rows = (d && d.hours || []).filter(r => r[0] >= now - span);
  if (!rows.length && st.samples) rows.push([st.started || now, st.dns_ok, st.dns_fail, st.events, st.actions_ok, st.actions_fail, st.mem_min_kb, st.load_max_x100, 0, 0]);
  return rows;
}
const STAB_WATCH = n => n === 'route-engine' ? 'Маршрутизация' : n === 'panel' ? 'Панель VWARD' :
  /^awg-t\d+$/.test(n) ? 'AmneziaWG · туннель ' + n.slice(5) : /^xray-v\d+$/.test(n) ? 'Xray · туннель ' + n.slice(6) : n;
// Programs by name, one name everywhere (owner 02.11).
const PROG_NAME = { 'vward-route-engine.sh': 'Маршрутизация', 'vward-sentinel': 'Контроль состояния', 'vward-cron-supervisor.sh': 'Агент компонентов', 'vward-dnscap': 'Захват DNS-запросов',
  'vward-awg': 'AmneziaWG', xray: 'Xray', lighttpd: 'Панель VWARD', AdGuardHome: 'AdGuard Home', https_dns_proxy: 'DoH-клиент', 'sing-box': 'sing-box', dnsmasq: 'dnsmasq' };
// A duration for people (owner 02.11): «8 ч 28 мин», seconds only under a minute.
// A number and its unit never part across lines (owner 12.11: «0,73» and «с» on two lines): U+00A0.
const fmtDur = sec => { const n = Math.round(+sec || 0); if (n < 60) return (Math.round((+sec || 0) * 10) / 10).toString().replace('.', ',') + '\u00a0с'; const d = Math.floor(n / 86400), h = Math.floor(n % 86400 / 3600), m = Math.floor(n % 3600 / 60); return d ? d + '\u00a0д ' + h + '\u00a0ч' : h ? h + '\u00a0ч ' + m + '\u00a0мин' : m + '\u00a0мин'; };
function stabEvent(w) {
  const f = String(w || '').split('|');
  const name = STAB_WATCH(f[2] || '');
  switch (f[0] === 'ACT' ? f[1] : f[0]) {
    case 'down': return name + ': пропал, запущен снова';
    case 'leak': return name + ': утечка памяти (' + fmtKB(parseInt(String(f[3]).replace('rss_kb=', ''), 10)) + '), перезапущен';
    case 'grow': return name + ': память растёт выше обычной';
    case 'link': return 'Интерфейс ' + f[2] + (f[3] === 'up' ? ' поднялся' : ' упал') + ': проверка сразу';
    case 'addr': return 'Интерфейс ' + f[2] + ' потерял адрес: проверка сразу';
    case 'mem-low': return 'Мало памяти на роутере';
    case 'dns-fail': return f[2] === 'adguardhome-start' ? 'DNS не отвечал: AdGuard Home запущен' : 'DNS не отвечал';
    case 'MEM_RESTART': return STAB_WATCH(f[1]) + ': утечка памяти, перезапущен';
    case 'MEM_LOW': return 'Мало памяти на роутере';
    case 'MEM_OK': return 'Память снова в норме';
    case 'PANEL_STARTED': return 'Панель VWARD запущена снова';
    case 'PANEL_START_FAILED': return 'Панель VWARD не запустилась, повтор позже';
    case 'AGH_STARTED': return 'AdGuard Home запущен после загрузки';
    case 'CROND_RESTARTED': return 'Планировщик заданий запущен снова';
    case 'SENTINEL_STARTED': return 'Агент реального времени запущен';
    case 'SENTINEL_START_FAILED': return 'Агент реального времени не запустился';
    default: return w;
  }
}
const STAB_JOB = { 'tunnel-health': 'Проверка туннелей', 'tunnel-guard': 'Агент туннелей', 'wan-guard': 'Агент интернета', 'wan-recovery': 'Восстановление интернета',
  'ads-scheduler': 'Планировщик рекламы', 'ads-guard': 'Скан рекламы', 'route-reconciler': 'Сверка маршрутов', 'route-engine': 'Маршрутизация',
  'route-hints-update': 'Подсказки маршрутов', 'policy-chain': 'IP-категории', 'housekeeping': 'Обслуживание', 'wifi-client-guard': 'Wi-Fi клиенты',
  'console-config': 'Действия Панели VWARD', 'console-mutation': 'Изменения из Панели VWARD' };
// The rows of stabChecks: what is known, or «не проверено».
function stabCheckRows(k) {
  const c = k.c, ago = x => fmtStamp(x);
  return [
    ['Туннель передаёт трафик', k.off ? 'выключен владельцем' : k.tunnel == null ? 'не проверено' : pct(k.tunnel), k.tunnel == null ? '' : k.tunnel >= 0.95 ? 'ok' : k.tunnel >= 0.8 ? 'warn' : 'crit', '', '',
      k.q && k.q.n && !k.off ? (k.name ? tunLabel(k.name) + ': ' : '') + k.q.ok + ' из ' + k.q.n + ' проверок за час' : k.name ? '' : 'туннель маршрутов не выбран'],
    ['Обновления скачиваются', k.feed == null ? 'не проверено' : k.feed ? 'да' : 'нет', k.feed == null ? '' : k.feed ? 'ok' : 'crit', '', '',
      [c.feed_ok_at ? 'последний раз ' + ago(c.feed_ok_at) : '', c.feed_fail_at > (c.feed_ok_at || 0) ? 'ошибка ' + ago(c.feed_fail_at) : ''].filter(Boolean).join(' · ')],
    ['HTTPS работает', k.https == null ? 'не проверено' : k.https ? 'да' : 'curl падает', k.https == null ? '' : k.https ? 'ok' : 'warn', '', '',
      c.https_crash_at ? 'загрузки идут запасным путём, с ' + ago(c.https_crash_at) : ''],
    ['Keenetic отвечает вовремя', k.rci == null ? 'не проверено' : c.rci_fails_day ? 'не ответил ' + c.rci_fails_day + ' ' + plural(c.rci_fails_day, 'раз', 'раза', 'раз') + ' за сутки' : 'да',
      k.rci == null ? '' : c.rci_fails_day ? 'warn' : 'ok', '', '', c.rci_fail_at ? 'последний раз ' + ago(c.rci_fail_at) : '']
  ];
}
const stabCls = i => i == null ? '' : i >= 95 ? 'ok' : i >= 80 ? 'warn' : 'crit';
const pct = x => x == null ? '—' : (Math.round(x * 1000) / 10).toString().replace('.', ',') + '%';
const API_ERRORS = {
  reference_preview_changed: 'настройки изменились после предпросмотра; перечитай состояние и повтори выбор',
  jq_broken: 'на роутере не работает программа jq - переустановите её: opkg install --force-reinstall jq',
  upstream_not_encrypted: 'сначала зашифруйте выход AdGuard Home (https://... в «Upstream DNS-серверы»)', invalid_mac: 'неверный MAC-адрес',
  chain_failed: 'DNS Keenetic не ответил через AdGuard Home', client_conflict: 'адрес роутера занят другим клиентом AdGuard Home',
  router_unavailable: 'Keenetic не ответил, повторите через минуту', nat_failed: 'роутер не принял правило перенаправления', filter_failed: 'роутер не принял правило блокировки',
  not_upgradable: 'обновление уже не нужно - проверьте ещё раз', ext_update_busy: 'уже идёт проверка или установка',
  notes_unavailable: 'описание версии не найдено', invalid_version: 'неверная версия',
  smartdns_agh_failed: 'AdGuard Home не принял изменение строк Smart DNS', smartdns_agh_unavailable: 'модуль AdGuard Home не установлен', upstream_file_unsupported: 'upstream AdGuard Home заданы файлом - строки Smart DNS меняйте в нём вручную',
  this_device_not_registered: 'это устройство не зарегистрировано в Keenetic - вы потеряли бы доступ', devices_unavailable: 'список устройств Keenetic сейчас недоступен', device_not_registered: 'устройство не зарегистрировано в Keenetic', host_not_allowed: 'VWARD открыт по чужому имени - откройте его по IP-адресу роутера или добавьте имя в ALLOWED_HOSTS файла /opt/etc/vward/console/auth.conf',
  file_closed: 'файл закрыт: в нём ключи или пароли', not_found: 'не найдено', invalid_path: 'недопустимый путь', folder_missing: 'папки нет на роутере',
  not_a_file: 'это не файл', not_a_folder: 'это не папка', invalid_root: 'неизвестная папка',
  updater_busy: 'идёт обновление, повторите позже', confirmation_required: 'требуется подтверждение',
  vward_off: 'VWARD отключён - сначала включите его', router_config_unavailable: 'роутер не отдал свои настройки',
  action_unavailable: 'действие недоступно на этом роутере', invalid_domain: 'неверный домен',
  invalid_ipv4: 'неверный IPv4-адрес', control_busy: 'другое действие ещё выполняется', busy: 'другое изменение ещё выполняется, повторите через несколько секунд',
  no_pending_update: 'нет загруженного обновления', state_action_not_allowed: 'в текущем состоянии обновления это недоступно',
  rollback_unavailable: 'нет резервной копии для отката', recovery_not_required: 'восстановление не требуется',
  config_unavailable: 'файл настроек недоступен', invalid_mac: 'неверный MAC-адрес',
  invalid_value: 'недопустимое значение', invalid_window: 'начало и конец окна совпадают', invalid_category: 'нет такой категории',
  router_rejected: 'роутер отклонил изменение', verification_failed: 'изменение не подтвердилось и отменено',
  core_refused: 'ядро маршрутизации отказалось: объект защищён или не найден', core_journal_blocked: 'прошлая операция ядра не завершена, и роутер не совпадает ни с «до», ни с «после»: проверьте маршрут в «Проверке адреса» и пришлите журнал', core_failed: 'ядро маршрутизации не ответило',
  ai_verification_failed: 'итоговый путь сервисов не подтвердился; проверь фактические маршруты, ручные изменения сохранены',
  saved_state_unknown: 'данные возврата DNS повреждены или недоступны; запись остановлена, данные сохранены',
  config_save_failed: 'роутер не сохранил конфигурацию', router_config_unavailable: 'не удалось прочитать конфигурацию роутера',
  route_change_busy: 'маршруты сейчас меняет другая задача, повторите', profile_unavailable: 'профиль устройства не определён',
  policy_group_unavailable: 'группа маршрутизации не найдена', list_full: 'список заполнен', backup_failed: 'не удалось сделать резервную копию',
  conf_not_awg3: 'в файле нет настроек AmneziaWG 3.x - это другой файл', conf_other_tunnel: 'файл от другого туннеля: ключ сервера не совпадает', adopt_move_failed: 'туннель поднят в модуле, но списки не перенеслись - перенесите их на странице туннеля', engine_replace_unsupported: 'туннель модуля не заменяется - добавьте новый и удалите этот', engine_full: 'в модуле уже 5 туннелей', speed_busy: 'замер скорости уже идёт', subscription_expired: 'подписка истекла: провайдер присылает заглушки вместо серверов - продлите её у провайдера', subscription_unavailable: 'адрес подписки не ответил', checksum_mismatch: 'скачанная программа не совпала с контрольной суммой', arch_unsupported: 'процессор роутера не поддерживается контуром',
  services_unavailable: 'каталог сервисов недоступен', invalid_service: 'неверное имя сервиса', unknown_service: 'такого сервиса нет в каталоге', service_too_big: 'у сервиса больше 300 доменов - Keenetic столько не примет в один список', service_not_enabled: 'сервис не включён', service_reference_only: 'список создан или изменён пользователем; автоматическое изменение запрещено', service_recovery_required: 'предыдущее действие не удалось подтвердить; проверь результат ниже и выбери, что сохранить', service_recovery_unverified: 'состояние не совпало с тем, что было до операции: она оставлена незавершённой', service_recovery_restore_failed: 'не удалось вернуть списки как до операции: она оставлена незавершённой, данные сохранены', smartdns_domain_other_server: 'домен уже направлен на другой сервер Smart DNS: он не перезаписан - уберите прежний сервер или выберите его', service_recovery_running: 'операция ещё выполняется', service_recovery_absent: 'операция уже завершена', list_limit: 'Keenetic не принял домены: достигнут предел списка', no_free_list: 'в Keenetic нет свободного номера доменного списка', catalog_invalid: 'каталог скачался повреждённым - работает прежний',
  write_failed: 'не удалось записать файл', custom_manifest_url: 'адрес манифеста задан вручную - канал меняется в update.conf', invalid_tunnel: 'недопустимое имя туннеля', tunnel_no_handshake: 'сервер не ответил на рукопожатие за 30 секунд - туннель не изменён', conf_no_address: 'в файле нет адреса IPv4 (строка Address)', engine_failed: 'программа модуля не ответила', engine_start_failed: 'программа модуля не запустилась', engine_unavailable: 'модуль туннеля не установлен', main_tunnel: 'это туннель по умолчанию: сначала назначьте по умолчанию другой туннель', tunnel_off: 'туннель выключен: сначала включите его на его странице', tunnel_address_taken: 'такой адрес в туннеле уже занят другим туннелем: у двух туннелей он должен быть разным', invalid_subnet: 'нужна подсеть IPv4, например 149.154.160.0/20 (не шире /8)', private_subnet: 'это адреса домашней сети, провайдера или служебные - в VPN они не отправляются', invalid_description: 'название: до 64 символов, без кавычек', no_free_tunnel: 'на роутере нет свободного номера туннеля',
  conf_empty: 'файл пустой', conf_syntax: 'это не файл WireGuard', conf_peer_count: 'в файле должен быть ровно один [Peer]', conf_key_private: 'неверный PrivateKey', conf_public_key: 'неверный PublicKey', conf_preshared_key: 'неверный PresharedKey', conf_address: 'нет адреса IPv4 в Address', conf_endpoint: 'неверный Endpoint (нужно сервер:порт)', conf_mtu: 'MTU вне 1280-1500', conf_keepalive: 'неверный PersistentKeepalive', conf_allowed_ips: 'неверный AllowedIPs', conf_awg: 'неверные параметры AmneziaWG', conf_unknown_setting: 'в файле настройки, которых не знают ни Keenetic, ни модуль AmneziaWG VWARD (новая версия AmneziaWG - нужно обновление модуля); без них туннель работал бы не так, как в файле', tunnel_device_missing: 'туннель не поднят на роутере', unknown_tunnel: 'туннель не найден',
  failopen_active: 'туннель недоступен, списки VPN идут напрямую: дождитесь восстановления', policy_sync_busy: 'идёт обновление IP-категорий, повторите позже',
  unsupported_route: 'правило маршрута группы задано нестандартно: переключите туннель в веб-интерфейсе Keenetic',
  profile_verification_failed: 'профиль устройства не принял новый туннель, изменения отменены',
  rollback_incomplete: 'откат не завершён: проверьте маршруты групп в веб-интерфейсе Keenetic',
  temporary_file_unavailable: 'нет места для временного файла', component_disabled: 'компонент выключен: включите его в «Система → Компоненты»',
  core_component: 'базовый компонент нельзя выключить', wrong_credentials: 'неверный логин или пароль', invalid_mac: 'неверный MAC-адрес', invalid_backup: 'неверное имя копии', unknown_backup: 'копия не найдена', backup_damaged: 'копия повреждена', backup_failed: 'не удалось создать копию', restore_failed: 'не удалось восстановить', adguard_rejected: 'AdGuard Home не принял изменение', unknown_filter: 'такого списка нет в AdGuard Home', invalid_service: 'неизвестный сервис', invalid_setting: 'неизвестная настройка', invalid_name: 'недопустимое название', invalid_password: 'пароль: только латиница, цифры и обычные знаки, до 128 символов', too_many_attempts: 'слишком много попыток - подождите 5 минут',
  router_auth_unavailable: 'роутер не ответил на проверку пароля', invalid_login: 'недопустимый логин', auth_required: 'нужно войти', invalid_url: 'неверный адрес: нужен https без пробелов и логина', invalid_format: 'неизвестный формат списка',
  adguard_unavailable: 'AdGuard Home не ответил', adguard_not_configured: 'AdGuard Home не подключён: нет адреса в профиле роутера', adguard_auth_required: 'AdGuard Home требует логин и пароль — подключение не настроено', invalid_search: 'в поиске допустимы буквы, цифры, точки и дефисы', invalid_category: 'нет такой категории', invalid_component: 'нет такого компонента', registry_unavailable: 'реестр компонентов недоступен',
  // fix.31: the codes the Panel showed as they are.
  smartdns_doh_component: 'В Keenetic нет компонента «Прокси-сервер DNS-over-HTTPS»: установите его в веб-интерфейсе Keenetic («Общие настройки» → «Изменить набор компонентов»), роутер перезагрузится',
  smartdns_not_configured: 'Smart DNS не настроен: укажите сервер DoH в разделе «ИИ-сервисы»',
  smartdns_server_ambiguous: 'у этого сервера несколько адресов: вставьте точный адрес в поле «Свой сервер DoH» и нажмите «Убрать по адресу»', smartdns_keenetic_full: 'лимит Smart DNS в Keenetic исчерпан (8 из 8 доменов)',
  service_list: 'список сервиса не создан в Keenetic', invalid_arguments: 'неверные параметры запроса', helper_failed: 'действие завершилось без ответа',
  doh_limit: 'в Keenetic нет места для ещё одного сервера DNS-over-HTTPS', doh_remove_failed: 'Keenetic не удалил строку Smart DNS', doh_remove_unsafe: 'строка Smart DNS используется не только VWARD: не удалена',
  package_install_refused: 'установка пакета отклонена проверкой безопасности или зависимостей', package_recovery_required: 'нужно разобрать незавершённую установку пакета', engine_in_use: 'у движка уже есть настроенные туннели', install_recovery_required: 'нужно разобрать незавершённую установку Xray', unzip_unavailable: 'не найдена программа распаковки ZIP',
  smartdns_off: 'Smart DNS выключен: включите его на странице «DNS»', settings_busy: 'настройки сохраняются, повторите через секунду',
  smartdns_dead: 'Smart DNS-сервер не отвечает', smartdns_unknown: 'ответ Smart DNS-сервера не подтверждён', list_dns_shared_domain: 'домен используется другим списком: нет права менять его DNS', list_dns_reference_only: 'DNS или список изменены вне операции: запись остановлена', list_dns_conflict: 'для домена уже настроен другой DNS-сервер', list_dns_concurrent: 'настройки изменились во время операции', list_dns_write_failed: 'роутер отклонил запись DNS списка', list_dns_verification_failed: 'результат записи DNS не подтверждён',
  list_dns_active: 'сначала выберите для списка VPN или Провайдер, затем меняйте домены или удаляйте список', operation_still_running: 'операция ещё выполняется, результат появится в журнале', install_busy: 'установка Xray уже выполняется', install_concurrent: 'файлы Xray изменились во время загрузки',
  group_not_found: 'список не найден в Keenetic', group_not_routed: 'у списка нет маршрута', unknown_group: 'нет такого списка', invalid_group: 'недопустимое имя списка', list_not_found: 'список не найден', component_busy: 'уже идёт другая операция с компонентом', agh_credentials_required: 'нужны логин и пароль для AdGuard Home', agh_not_installed: 'AdGuard Home не установлен', agh_setup_failed: 'AdGuard Home не принял настройки', agh_stop_failed: 'AdGuard Home не остановился', no_free_port: 'нет свободного порта', dns_release_failed: 'не удалось убрать DNS-строки из Keenetic', default_tunnel_in_module: 'туннель по умолчанию в этом модуле: выберите, куда перевести маршруты', list_too_long: 'в объединённом списке будет больше 300 доменов',
  domain_not_resolved: 'домен не разрешается в адрес', download_failed: 'не удалось скачать файл', feed_unavailable: 'сервер обновлений недоступен', unpack_failed: 'архив повреждён',
  no_space: 'недостаточно места на USB-накопителе', space_unknown: 'не удалось узнать свободное место на USB-накопителе', router_save_failed: 'Keenetic не сохранил настройки', tunnel_unavailable: 'туннель недоступен', upgrade_rolled_back: 'обновление откатилось: проверка после установки не прошла',
  agh_start_failed: 'AdGuard Home не запустился', agh_build_broken: 'сборка AdGuard Home не запускается на этом роутере', agh_no_build: 'нет сборки AdGuard Home для этого процессора',
  conf_not_awg: 'файл не похож на конфигурацию WireGuard или AmneziaWG', vless_replace_unsupported: 'для этого туннеля замена конфигурации не поддерживается', value_too_long: 'слишком длинное значение',
  invalid_operation: 'неизвестное действие', method_not_allowed: 'недопустимый запрос', unknown_parameter: 'неизвестный параметр запроса', invalid_body: 'неверный запрос',
  temporary_file_failed: 'нет места для временного файла', session_failed: 'не удалось начать сеанс', stability_unavailable: 'данные стабильности недоступны', admission_unavailable: 'роутер занят, повторите позже'
};
// The router's answer to a refused command; for a file, the settings it holds that nobody knows.
const errText = x => errBase(x) + (x && x.reason ? (x.error === 'conf_unknown_setting' ? ': ' + x.reason.split(',').join(', ') : ' (ответ роутера: ' + x.reason + ')') : '');
const errBase = x => API_ERRORS[x && x.error] || (x && /^conf_rejected_/.test(x.error || '') ? 'роутер не принял настройку ' + x.error.slice(14).replace(/_/g, ' ') + ' - туннель не изменён' : '') || (x && x.error) || (x && x.rc != null ? 'код ' + x.rc : 'роутер ответил без данных');

/* ---------- Данные ---------- */
const S = { act: {}, tq: null, auth: null, cron: null, status: null, route: null, lists: null, update: null, security: null, diag: null, wifi: null, ads: null, https: null, config: null, adsstats: null, adspub: null, agh: null, ext: null, listd: null, laddr: null, services: null, svcd: null, awg: null, wanhist: null, backups: null, qlog: null, review: null, blocked: null, logs: {}, tprobe: {}, errors: {}, loadedAt: {} };
// The last address check stays on the page until the next one (the page redraws itself).
let RPROBE = null;
// Where the check says traffic goes, in words: through which tunnel, or past the VPN.
/* ---------- Реклама: проверить или заблокировать адрес ---------- */
// A banner's address (a link is fine) → what AdGuard Home does with it and which list or rule
// decides (ads-view check); «Заблокировать» / «Разблокировать» change the owner's own rules
// in AdGuard Home and show the check again.
let ADSCHK = null;
const baseDomain = d => d.split('.').slice(-2).join('.');
function adsCheckPanel() {
  const a = S.ads || {}, r = ADSCHK;
  let out = '';
  if (r && r.error) out = '<p class="field-warn">' + esc(r.error) + '</p>';
  else if (r && r.x && !r.x.ok) out = '<p class="field-warn">' + esc(r.x.error === 'adguard_unavailable' || r.x.error === 'adguard_auth_required' ? 'AdGuard Home недоступен или не подключён: «Компоненты → AdGuard Home».' : errText(r.x)) + '</p>';
  else if (r && r.x) {
    const x = r.x, d = x.domain, rules = (x.rules || []).map(y => [y.list || 'правило', y.text]), L = linkInfo(r.link || d);
    // A page inside a site's own domain (yandex.ru/an/count/...) without ad markers: blocking
    // the domain closes the whole site, so the button says so.
    const inSite = !!L.path && !L.ad && (d === baseDomain(d) || d === 'www.' + baseDomain(d));
    const acts = [], rule = (op, kind, dom, icon, label, cls) => btn('ads-urule', icon, label, cls, ' data-op="' + op + '" data-kind="' + kind + '" data-dom="' + esc(dom) + '"');
    if (x.blocked) {
      if (x.user_block) acts.push(rule('remove', 'block', d, 'close', 'Снять блокировку', 'primary'));
      else acts.push(rule('add', 'allow', d, 'check', 'Добавить в исключения', ''));
    } else if (x.allowed) {
      if (x.user_allow) acts.push(rule('remove', 'allow', d, 'close', 'Удалить исключение', ''));
    } else if (inSite) {
      acts.push(rule('add', 'block', d, 'block', 'Заблокировать домен ' + d + ' целиком', 'danger'));
    } else {
      acts.push(rule('add', 'block', d, 'block', 'Заблокировать ' + d, 'primary'));
      if (baseDomain(d) !== d) acts.push(rule('add', 'block', baseDomain(d), 'block', 'Заблокировать ' + baseDomain(d) + ' с поддоменами', ''));
    }
    // The redirect chain packed into the link: every host with its own status.
    const chain = (r.chain || []).filter(c => c.x && c.x.ok);
    const open = [d].filter(() => !x.blocked && !x.allowed).concat(chain.filter(c => !c.x.blocked && !c.x.allowed).map(c => c.d));
    if (chain.length && open.length > 1) acts[0] = acts[0].replace('btn primary', 'btn'), acts.unshift(btn('ads-chain-block', 'block', 'Заблокировать все домены цепочки (' + open.length + ')', 'primary', ' data-doms="' + esc(open.join(' ')) + '"'));
    out = '<p class="probe-verdict' + (x.blocked ? ' vpn' : '') + '">' + esc(d) + (x.blocked ? ': блокируется' : x.allowed ? ': разрешён исключением' : ': не фильтруется') + '</p>' +
      (rules.length ? kv(rules) : '') + (x.service ? kv([['Сервис', x.service]]) : '') +
      (L.ad ? kv([['Тип ссылки', L.chain.length > 1 ? 'рекламная, переадресация через ' + L.chain.length + ' ' + plural(L.chain.length, 'домен', 'домена', 'доменов') : 'рекламная (параметры партнёрской сети)']]) : '') +
      (chain.length ? '<p class="form-label site-head">Цепочка переадресации</p>' + kv(chain.map(c => [c.d, c.x.blocked ? 'блокируется' : c.x.allowed ? 'исключение' : 'не фильтруется', c.x.blocked ? 'ok' : c.x.allowed ? '' : 'warn'])) : '') +
      (inSite && !x.blocked && !x.allowed ? '<p class="field-warn">Адрес указывает на страницу внутри ' + esc(d) + ' (' + esc(L.path) + '). AdGuard Home фильтрует на уровне DNS: блокировка применяется к домену целиком, со всеми страницами и поддоменами. Для блокировки только этого пути используйте правило браузерного блокировщика (uBlock Origin, AdGuard): ||' + esc(d + '/' + L.path.split('/')[1]) + '/</p>' : '') +
      '<div class="panel-actions">' + acts.join('') + btn('ads-deep', 'search', 'Анализ VWARD', '', ' data-dom="' + esc(d) + '"') + '</div>' +
      (x.blocked || x.allowed ? '' : '<p class="result-note">Правило записывается в пользовательские правила AdGuard Home и применяется ко всем устройствам сети сразу.</p>');
  }
  return panel('Проверка блокировки', inputBar({ form: 'ads-check', label: 'Домен или ссылка', id: 'adsCheck', value: r && (r.link || r.value), placeholder: 'например, ads.example.com',
    aria: 'Домен или ссылка', busy: r && r.busy, off: S.ads && !a.agh_connected, icon: 'search', btn: 'Проверить' }) + out,
    { fixed: true, desc: S.ads && !a.agh_connected ? 'Требуется подключение к AdGuard Home: «Компоненты → AdGuard Home».' : 'Статус фильтрации домена, сработавшие списки и правила. Принимает домен или полную рекламную ссылку, включая цепочки переадресации.' });
}
// A link, taken apart: its path, the hosts it redirects through (addresses inside its
// parameters - plain, URL-encoded or base64, as ad networks pack them), and whether it
// carries the markers of an ad network (partner, click and sub ids, utm_*).
function linkInfo(raw) {
  const v = String(raw || '').trim(), chain = [];
  const add = h => { h = hostOf(h); if (DOMAIN.test(h) && !chain.includes(h)) chain.push(h); };
  add(v);
  const m0 = v.match(/^(?:[a-z][a-z0-9+.-]*:\/\/)?[^/?#]+(\/[^?#]*)/i), path = m0 && m0[1] !== '/' ? m0[1].slice(0, 80) : '';
  const q = v.includes('?') ? v.slice(v.indexOf('?') + 1).split('#')[0] : '';
  for (const pair of q.split('&').slice(0, 40)) {
    let x = pair.slice(pair.indexOf('=') + 1);
    try { x = decodeURIComponent(x.replace(/\+/g, ' ')); } catch (e) { /* as is */ }
    if (!/^(https?:)?\/\//i.test(x) && /^[A-Za-z0-9+/_-]{16,}={0,2}$/.test(x)) { try { x = atob(x.replace(/-/g, '+').replace(/_/g, '/')); } catch (e) { /* not base64 */ } }
    const m = x.match(/^(?:https?:)?\/\/([^/?#\s]+)/i);
    if (m) add(m[1]);
    if (chain.length >= 6) break;
  }
  const ad = chain.length > 1 || /[?&](utm_[a-z]+|partner[a-z_]*|affi[a-z_-]*|aff_[a-z]+|click_?id|sub_?id[a-z0-9_]*|zoneid|campaign[a-z_]*|web_?master[a-z_]*|rotator|landing)=/i.test(v);
  return { path: path, chain: chain, ad: ad };
}
async function adsCheck(v, link) {
  link = link || v;
  const L = linkInfo(link), rest = L.chain.filter(h => h !== v).slice(0, 5);
  ADSCHK = { value: v, link: link, busy: true }; render();
  const ask = h => apiGet('ads-view', { view: 'check', search: h }).catch(e => ({ ok: false, error: e.message }));
  try {
    const [x, ...more] = await Promise.all([apiGet('ads-view', { view: 'check', search: v })].concat(rest.map(ask)));
    ADSCHK = { value: v, link: link, x: x, chain: rest.map((h, i) => ({ d: h, x: more[i] })) };
  } catch (e) { ADSCHK = { value: v, link: link, error: 'Ошибка: ' + e.message }; }
  render();
}
async function adsUserRule(op, kind, d) {
  let x;
  try { x = await apiPost('ads-control', { op: 'agh', setting: 'user-rule', value: op, kind: kind, domain: d }); } catch (e) { x = { ok: false, error: e.message }; }
  toast(x.ok ? (op === 'add' ? (kind === 'block' ? d + ': блокировка добавлена' : d + ': исключение добавлено') : d + ': правило удалено') : 'Не выполнено: ' + errText(x));
  await adsCheck(ADSCHK && ADSCHK.value || d, ADSCHK && ADSCHK.link || '');
}
// Every host of the chain blocked in turn, then one check.
async function adsChainBlock(doms) {
  let ok = 0, err = '';
  for (const d of doms) {
    let x;
    try { x = await apiPost('ads-control', { op: 'agh', setting: 'user-rule', value: 'add', kind: 'block', domain: d }); } catch (e) { x = { ok: false, error: e.message }; }
    if (x.ok) ok++; else err = err || d + ': ' + errText(x);
  }
  toast(err ? 'Заблокировано ' + ok + ' из ' + doms.length + '; ' + err : 'Заблокировано доменов: ' + ok);
  await adsCheck(ADSCHK && ADSCHK.value || doms[0], ADSCHK && ADSCHK.link || '');
}

/* ---------- Проверить сайт ---------- */
// Where the site is set up (route-probe) and whether it opens right now directly and through
// every tunnel (site-test), asked side by side; «Диагностика и восстановление» then repairs what it can.
const hostOf = v => String(v || '').trim().toLowerCase().replace(/^[a-z][a-z0-9+.-]*:\/\//, '').replace(/^[^@/]*@/, '').replace(/[/?#].*$/, '').replace(/:\d+$/, '').replace(/^\*\./, '').replace(/\.$/, '');
function sitePanel() {
  return panel('Проверка адреса', inputBar({ form: 'probe', label: 'Домен, ссылка или IPv4-адрес', id: 'probeInput', value: RPROBE && RPROBE.value, placeholder: 'например, youtube.com',
    aria: 'Домен, ссылка или IPv4-адрес', busy: RPROBE && (RPROBE.busy || RPROBE.fixing || RPROBE.doing), icon: 'search', btn: 'Проверить' }) + '<div id="probeResult">' + probeText(RPROBE) + siteTestText(RPROBE) + siteDoText(RPROBE) + probeDetails(RPROBE) + '</div>',
    { fixed: true, desc: 'Текущий маршрут домена и его основание, доступность через провайдера и каждый туннель, выбор политики маршрутизации.' });
}
// What is set up for a checked domain: VWARD's lists, Smart DNS, a block in AdGuard Home.
const hasDom = (l, x) => (l || []).some(d => (typeof d === 'string' ? d : d.domain) === x);
const underAny = (d, l) => (l || []).some(x => d === x || d.endsWith('.' + x));
function siteState(r) {
  const x = (r && r.x) || {}, d = x.value || '', c = cfgRoute(), L = S.lists || {}, b = r && r.b && r.b.ok ? r.b : null;
  const tuns = ((st().wg && st().wg.interfaces) || []).map(t => t.name).concat(prof().tunnel_interface || []);
  const vpnRoutes = (x.routes || []).filter(t => tuns.includes(t.interface));
  const sd = L.smartdns_domains || [];
  return {
    d: d, group: c.group || '', mine: hasDom(c.domains, d), force: hasDom(c.force_vpn, d), adaptive: !!x.adaptive_auto || hasDom(c.adaptive, d),
    smart: underAny(d, sd), smartOwn: sd.includes(d), smartHere: ((L.smartdns_sources || {}).adguard || []).length > 0,
    lists: vpnRoutes.filter(t => t.group !== c.group && t.group !== 'AdaptiveAuto').map(t => t.group),
    vpn: vpnRoutes.length > 0, agh: !!b, blocked: !!(b && b.blocked), userBlock: !!(b && b.user_block)
  };
}
const siteNow = s => s.blocked ? 'block' : s.smart ? 'smart' : s.vpn || s.force ? 'vpn' : 'direct';
// «Политика маршрутизации»: every way the domain can go; the active one is marked, blocking asks first.
let SITEDOM = '';
function siteDoText(r) {
  if (!r || r.busy || !r.x || !r.x.ok || r.x.type !== 'domain') return '';
  const s = siteState(r), now = siteNow(s), ok = cfgOk() && !r.doing;
  // One slider, as on «Smart DNS» and the lists (owner 12.11.2026), not a stack of buttons.
  const ways = [['vpn', 'VPN']].concat(s.smartHere ? [['smart', 'Smart DNS']] : [], [['direct', 'Провайдер']], s.agh && !s.userBlock ? [['block', 'Блок']] : [])
    .map(w => [w[0], w[1], !ok]);
  SITEDOM = s.d;
  const acts = [choiceSlider('site-do', ways, now, 'Как открывать ' + s.d, true)];
  if (s.agh && s.userBlock) acts.push('<div class="panel-actions">' + btn('site-do', 'close', 'Снять блокировку', '', ' data-how="unblock" data-dom="' + esc(s.d) + '"' + (r.doing ? ' disabled' : '')) + '</div>');
  const steps = r.did ? '<ul class="fix-steps">' + r.did.map(f => '<li class="' + (f.ok === false ? 'crit' : f.ok ? 'ok' : '') + '">' + esc(f.text) + '</li>').join('') + '</ul>' : '';
  return '<p class="form-label site-head">Как открывать</p>' +
    (confirmBox('site-block', 'Заблокировать ' + s.d + ' в AdGuard Home? Домен и его поддомены станут недоступны для всех устройств сети.', 'Заблокировать', true) ||
     acts.join('')) + steps +
    (s.blocked && !s.userBlock ? '<p class="result-note">Домен блокируется списком фильтрации AdGuard Home. Исключение добавляется в «Реклама → Проверка адреса».</p>' : '');
}
// One choice as the steps it takes; the check runs again at the end.
async function siteDo(how, d) {
  const r = RPROBE;
  if (!r || !r.x || r.x.value !== d) return;
  const s = siteState(r), did = [];
  r.doing = true; r.did = did; render();
  const step = async (fields, text, api) => {
    let x;
    try { x = await apiPost(api || 'config', fields); } catch (e) { x = { ok: false, error: e.message }; }
    did.push({ text: x.ok ? text : text + ': ошибка - ' + errText(x), ok: !!x.ok }); render();
    return x.ok;
  };
  const cfgStep = (op, action, text) => step({ op: op, action: action, target: d }, text);
  try {
    if (how === 'block') { await step({ op: 'agh', setting: 'user-rule', value: 'add', kind: 'block', domain: d }, d + ': блокировка в AdGuard Home добавлена', 'ads-control'); return; }
    if (how === 'unblock' || s.userBlock) {
      if (!await step({ op: 'agh', setting: 'user-rule', value: 'remove', kind: 'block', domain: d }, d + ': блокировка в AdGuard Home снята', 'ads-control') || how === 'unblock') return;
    }
    // Smart DNS answers with the service's own proxy: through VPN it stops working, and back.
    if (how !== 'smart' && s.smart) {
      if (s.smartOwn) { if (!await cfgStep('smartdns-domain', 'remove', d + ': удалён из Smart DNS')) return; }
      else did.push({ text: d + ': Smart DNS задан для родительского домена, изменение выполняется на странице «Smart DNS»', ok: false });
    }
    if (how === 'vpn') {
      // Always a Keenetic list: force-vpn.conf is read by the shell engine only, so with no group
      // claude.ai stayed direct while the Panel said «через VPN» (owner 12.11.2026). No list for
      // «Мои домены» yet: the router makes VWARD's own list «VWARD» through the VPN.
      if (!s.vpn && !s.force) await cfgStep('route-domain', 'add', d + (s.group ? ': добавлен в «Мои домены», маршрут через VPN' : ': добавлен в список «VWARD» через VPN'));
      return;
    }
    if (s.mine && !await cfgStep('route-domain', 'remove', d + ': удалён из «Мои домены»')) return;
    if (s.force && !await cfgStep('force-vpn', 'remove', d + ': снято «всегда через VPN»')) return;
    if (s.adaptive && !await cfgStep('adaptive', 'remove', d + ': удалён из автоподбора')) return;
    for (const g of s.lists) {
      const l = ((S.lists && S.lists.lists) || []).find(x => x.name === g), name = (r.x.names && r.x.names[g]) || (l && l.description) || g;
      const own = l && (l.domains || []).includes(d);
      if (!await step({ op: 'list-domain', action: own ? 'remove' : 'exclude', target: g, value: d }, d + (own ? ': удалён из списка «' : ': добавлен в исключения списка «') + name + '»')) return;
    }
    if (how === 'smart') { await cfgStep('smartdns-domain', 'add', d + ': добавлен в Smart DNS'); return; }
    if (!did.length) did.push({ text: d + ': маршрут через провайдера уже задан', ok: true });
  } finally {
    r.doing = false;
    await Promise.all(['config', 'route', 'lists'].map(k => load(k, true)));
    const keep = did.slice();
    await siteCheck(d);
    if (RPROBE && RPROBE.value === d) { RPROBE.did = keep.concat({ text: 'Изменения применяются к новым DNS-запросам. Кэш DNS устройств и браузеров обновляется в течение 1-5 минут.', ok: null }); render(); }
  }
}
const DIRECT = 'direct';
const siteVia = v => v === DIRECT ? 'Провайдер (без VPN)' : 'VPN «' + tunLabel(v) + '»';
// fix.35.3: an answer is not «доступен» unless it is a page or a redirect (403/404/5xx named as they are).
const siteVal = y => y.verdict === 'open' ? 'доступен · ' + fmtInt(y.ms) + ' мс' : y.verdict === 'blocked' ? 'ограничен (HTTP ' + y.code + ')' :
  y.verdict === 'denied' ? 'отказ (HTTP 403)' : y.verdict === 'error' ? 'ошибка сервера (HTTP ' + y.code + ')' : y.verdict === 'answer' ? 'ответ HTTP ' + y.code + ': работа сайта не подтверждена' : 'нет ответа, таймаут 6 с';
// Where the tested address came from: a Smart DNS domain may get the Smart DNS proxy's address, then a
// «direct» answer is that proxy's, not the provider's path to the site.
const siteSrc = x => 'Адрес ' + x.ip + (x.dns ? ' от DNS ' + x.dns : '') + (x.smartdns ? ': домен идёт через Smart DNS - ответ «без VPN» может быть от прокси Smart DNS, прямой путь не подтверждён' : '');
function siteTestText(r) {
  if (!r || r.busy || !r.t) return '';
  const x = r.t;
  const rows = x.ok ? kv(x.results.map(y => [siteVia(y.via), siteVal(y), y.verdict === 'open' ? (x.smartdns && y.via === DIRECT ? 'warn' : 'ok') : y.verdict === 'answer' ? 'warn' : 'crit'])) + (x.smartdns ? '<p class="panel-desc">' + esc(siteSrc(x)) + '</p>' : '') +
      (x.results.some(y => y.via !== DIRECT && y.verdict === 'denied') ? '<p class="panel-desc">Отказ 403 через VPN часто означает защиту сайта от программ: проверка с роутера её не проходит, а в браузере сайт может открыться.</p>' : '') :
    '<p class="field-warn">' + esc(x.error === 'domain_not_resolved' ? 'Домен не разрешается в DNS: проверьте написание.' : errText(x)) + '</p>';
  const mv = r.move && !r.fixing ? '<div class="panel-actions">' + btn('site-move', 'route', 'Перевести список на «' + tunLabel(r.move.to) + '»', 'primary', ' data-list="' + esc(r.move.list) + '" data-to="' + esc(r.move.to) + '"') + '</div>' : '';
  const fix = r.fix ? '<ul class="fix-steps">' + r.fix.map(f => '<li class="' + (f.ok === false ? 'crit' : f.ok ? 'ok' : '') + '">' + esc(f.text) + '</li>').join('') + '</ul>' : '';
  const acts = [];
  if (x.ok && !r.fixing) {
    // Sending it through VPN is «VPN-туннель» above.
    acts.push(btn('site-fix', 'refresh', 'Диагностика и восстановление', '', ' data-dom="' + esc(x.domain) + '"' + (cfgOk() ? '' : ' disabled')));
  }
  return '<p class="form-label site-head">Доступность</p>' + rows + fix + mv + (acts.length ? '<div class="panel-actions">' + acts.join('') + '</div>' : '');
}
async function siteCheck(v) {
  const ip = IPV4.test(v);
  RPROBE = { value: v, busy: true }; render();
  const [x, t, b] = await Promise.all([
    apiGet('route-probe', { type: ip ? 'ip' : 'domain', value: v }).catch(e => ({ ok: false, error: e.message })),
    ip ? Promise.resolve(null) : apiGet('site-test', { domain: v }).catch(e => ({ ok: false, error: e.message })),
    ip ? Promise.resolve(null) : apiGet('ads-view', { view: 'check', search: v }).catch(() => null)]);
  RPROBE = { value: v, x: x, t: t, b: b }; render();
}
// «Диагностика и восстановление»: each step in the result, then one line of what was done.
async function siteFix(d) {
  const r = RPROBE, steps = [];
  const step = (text, ok) => { steps.push({ text: text, ok: ok }); r.fix = steps.slice(); render(); };
  r.fixing = true; r.fix = []; render();
  try {
    const w = st().wan || {};
    if (w.internet === false) { step('Канал провайдера недоступен: туннели не могут установить соединение. Восстановление WAN выполняется автоматически, состояние - в разделе «Сеть».', false); return; }
    step('Канал провайдера доступен', true);
    const routes = (r.x && r.x.routes) || [], tun = routes.length ? routes[0].interface : '', listName = routes.length ? routes[0].group : '';
    let t = r.t && r.t.ok ? r.t : await apiGet('site-test', { domain: d });
    const res = v => ((t && t.results) || []).find(y => y.via === v);
    if (tun && res(tun) && res(tun).verdict !== 'open') {
      step('Туннель «' + tunLabel(tun) + '»: домен недоступен, выполняется перезапуск туннеля', null);
      const j = await tunnelState('restart', tun), on = j && j.ok && isTrue((tunNow(tun) || {}).connected);
      step(!j || !j.ok ? 'Перезапуск туннеля не выполнен: ' + (j ? j.text : 'туннель уже переключается') : on ? 'Туннель «' + tunLabel(tun) + '» перезапущен, сервер отвечает'
        : 'Туннель «' + tunLabel(tun) + '» перезапущен, сервер не ответил за минуту', !!(j && j.ok && on));
      t = await apiGet('site-test', { domain: d }).catch(e => ({ ok: false, error: e.message }));
      r.t = t;
    }
    const open = ((t && t.results) || []).filter(y => y.verdict === 'open'), direct = res(DIRECT);
    if (!t || !t.ok) { step('Повторная проверка не выполнена: ' + errText(t || {}), false); return; }
    if (tun && res(tun) && res(tun).verdict === 'open') { step('Домен доступен через «' + tunLabel(tun) + '». Обновите страницу в браузере.', true); return; }
    if (!tun && direct && direct.verdict === 'open') { step('Домен доступен с роутера через провайдера. Если устройство не открывает его, проверьте кэш браузера и VPN или прокси на самом устройстве.', true); return; }
    const mine = prof().tunnel_interface;
    if (!tun && open.some(y => y.via === mine)) {
      const x = await cfgSet({ op: 'route-domain', action: 'add', target: d }, d + ' идёт через VPN', ['route']);
      step(x && x.ok ? d + ': добавлен в «Мои домены», маршрут через «' + tunLabel(mine) + '». Обновите страницу в браузере.' : d + ': добавление в «Мои домены» не выполнено', !!(x && x.ok));
      return;
    }
    const other = open.find(y => y.via !== DIRECT);
    if (other) {
      step('Домен доступен через «' + tunLabel(other.via) + '»' + (listName ? ': требуется перевести список, в котором он задан, на этот туннель' : ': требуется добавить его в список, маршрутизируемый через этот туннель'), null);
      if (listName && listName !== 'AdaptiveAuto' && ((S.lists && S.lists.lists) || []).some(l => l.name === listName)) r.move = { list: listName, to: other.via };
      return;
    }
    step('Домен недоступен ни через провайдера, ни через туннели: вероятна недоступность самого сервиса. Повторите проверку позже.', false);
  } catch (e) { step('Ошибка: ' + e.message, false); }
  finally { r.fixing = false; render(); }
}

function probeText(r) {
  if (!r) return '';
  if (r.busy) return '<p class="panel-desc">Проверка ' + esc(r.value) + '…</p>';
  if (r.error) return '<p class="field-warn">' + esc(r.error) + '</p>';
  const x = r.x || {};
  if (!x.ok) return '<p class="field-warn">' + esc(errText(x)) + '</p>';
  const tuns = ((st().wg && st().wg.interfaces) || []).map(t => t.name);
  const via = t => tuns.includes(t) || t === prof().tunnel_interface ? 'через VPN «' + tunLabel(t) + '»' : t === prof().wan_interface || t === 'ISP' ? 'через провайдера (без VPN)' : 'через ' + t;
  const routerRows = (x.router_routes || []).filter(p => p.device !== 'lo');
  const routerText = routerRows.length ? routerRows.map(p => p.ip + ': ' + (p.known ? 'через ' + p.device + (p.gateway ? ', шлюз ' + p.gateway : '') : 'маршрут не определён')).join('; ') : 'нет данных о маршруте IPv4';
  const clientNote = '<p class="panel-desc">Путь устройства не проверен. Маршрут роутера может отличаться от маршрута приложения, UDP и IPv6.</p>';
  if (x.type === 'ip') {
    const cats = (x.policy_matches || []).map(m => m.category);
    return '<p class="probe-verdict">' + esc(x.value) + ': маршрут роутера</p>' +
      kv([['Маршрут IPv4', routerText], ['IP-категории', cats.length ? cats.join(', ') : 'нет'],
        ['Настроенный маршрут категории', x.configured_route ? 'подсеть ' + x.owned_cidr + ', ' + (x.interface || '') : 'не найден']]) + clientNote;
  }
  const routes = x.routes || [], name = g => g === 'AdaptiveAuto' ? 'Автоподбор' : (x.names && x.names[g]) || g;
  const head = esc(x.value) + (routes.length ? ': настройка списка ' + esc(via(routes[0].interface)) : ': маршрут в списках не задан');
  const why = routes.length ? routes.map(t => (t.group === 'AdaptiveAuto' ? 'добавлен автоподбором' : 'в списке «' + name(t.group) + '»') + (routes.length > 1 ? ', маршрут ' + via(t.interface) : '')).join('; ')
    : (x.groups || []).length ? 'в списке «' + name(x.groups[0]) + '», маршрут для списка не задан' : 'не входит ни в один список';
  const hints = [...new Set((x.hints || []).map(h => h.category))];
  const s = siteState(r);
  const head2 = s.blocked ? esc(x.value) + ': заблокирован в AdGuard Home' : s.smart && !routes.length ? esc(x.value) + ': настроен Smart DNS' : head;
  // One line says it: «claude.ai: напрямую - не входит ни в один список» (no «Основание» repeating it).
  const head3 = !routes.length && !(x.groups || []).length && !s.blocked && !s.smart ? esc(x.value) + ': напрямую - не входит ни в один список' : head2;
  return '<p class="probe-verdict ' + (routes.length || s.blocked ? 'vpn' : '') + '">' + head3 + '</p>' + kv([
    head3 === head2 ? ['Основание', why] : null,
    s.smart ? ['Smart DNS', s.smartOwn ? 'задан для домена' : 'задан для родительского домена'] : null,
    s.agh ? ['AdGuard Home', s.blocked ? (s.userBlock ? 'блокировка пользовательским правилом' : 'блокировка списком фильтрации') : 'не фильтруется'] : null,
    hints.length ? ['В каталоге сервисов', hints.slice(0, 3).join(', ')] : null
  ].filter(Boolean));
}
// The router's route and DNS answer: for a closer look, folded under the result (owner 12.11.2026).
function probeDetails(r) {
  if (!r || r.busy || r.error || !r.x || !r.x.ok || r.x.type === 'ip') return '';
  const x = r.x, lo = (x.router_routes || []).filter(p => p.device === 'lo').map(p => p.ip), rows = (x.router_routes || []).filter(p => p.device !== 'lo');
  const ips = ((x.dns && x.dns.ipv4) || []).filter(ip => !lo.includes(ip));
  return '<details class="prop-old"><summary>Подробности: маршрут роутера и DNS</summary>' + kv([
    ['Маршрут роутера IPv4', rows.length ? rows.map(p => p.ip + ': ' + (p.known ? 'через ' + p.device + (p.gateway ? ', шлюз ' + p.gateway : '') : 'маршрут не определён')).join('; ') : 'нет данных'],
    ['Адреса от DNS', ips.join(', ') || 'не определены'],
    r.t && r.t.ok && r.t.dns ? ['Проверка шла на', r.t.ip + ' (DNS ' + r.t.dns + ')'] : null
  ].filter(Boolean)) + '<p class="panel-desc">Проверка идёт с роутера: путь самого устройства (приложение, UDP, IPv6) может отличаться.</p></details>';
}
const ADSV = { filter: 'all', search: '', blockedSearch: '', allowedSearch: '', filtersOpen: false };
// Files page: the open folder.
const FILES = { root: '', path: '' };
const LOADERS = {
  status: () => apiGet('status'), route: () => apiGet('route-data'), update: () => apiGet('update-data'), lists: () => apiGet('lists-data'),
  security: () => apiGet('security-data'), diag: () => apiGet('diagnostics'), wifi: () => apiGet('wifi-data'),
  ads: () => apiGet('ads-data'), https: () => apiGet('ads-https-data'), config: () => apiGet('config-data'),
  adsstats: () => apiGet('ads-view', { view: 'stats' }), agh: () => apiGet('ads-view', { view: 'agh' }), backups: () => apiGet('backup-data'), ext: () => apiGet('ext-update-data'),
  wanhist: () => apiText('log', { name: 'recovery', count: 100 }).then(t => ({ ok: true, text: t })),
  awg: () => apiGet('awg-data'), tq: () => apiGet('tunnel-quality'), stab: () => apiGet('stability'), services: () => apiGet('services-data'), svcd: () => current.startsWith('s-') ? apiGet('services-data', { id: current.slice(2) }) : Promise.resolve(null),
  listd: () => current.startsWith('l-') ? apiGet('list-data', { name: current.slice(2) }) : Promise.resolve(null),
  laddr: () => current.startsWith('ip-') ? apiGet('list-addrs', { name: current.slice(3) }) : Promise.resolve(null), files: () => FILES.root ? apiGet('files', { op: 'list', root: FILES.root, path: FILES.path }) : Promise.resolve(null), adspub: () => apiGet('ads-view', { view: 'publish-status' }),
  qlog: () => apiGet('ads-view', { view: 'querylog', filter: ADSV.filter, search: ADSV.search }),
  review: () => apiGet('ads-view', { view: 'list', kind: 'review' }),
  cron: () => apiGet('cron-data'), cleanup: () => apiGet('cleanup-data'), ai: () => apiGet('ai-data'), auth: () => apiGet('auth'), off: () => apiGet('vward-off'), notes: () => apiGet('notes'), journal: () => apiGet('journal-data'),
  blocked: () => apiGet('ads-view', { view: 'list', kind: 'blocked', search: ADSV.blockedSearch }),
  allowed: () => apiGet('ads-view', { view: 'list', kind: 'allowed', search: ADSV.allowedSearch })
};
// The last answers are kept in the browser: a reopened console shows them at once
// and refreshes from the router in the background.  Nothing secret is in them;
// a login prompt or «Выйти» drops them.
const CACHE_KEYS = ['tq', 'status', 'route', 'lists', 'update', 'security', 'wifi', 'ads', 'config', 'adsstats', 'agh', 'backups', 'cron', 'awg', 'ext', 'diag', 'adspub', 'services', 'notes'];
const CACHE_TTL = 86400000, CACHE_MAX = 400000;
S.cached = {};
function cacheRead() {
  CACHE_KEYS.forEach(k => {
    const c = store.get('vward-cache-' + k, null);
    if (c && c.d && Date.now() - c.t < CACHE_TTL) { S[k] = c.d; S.cached[k] = c.t; }
  });
}
function cacheWrite(k) {
  if (!CACHE_KEYS.includes(k)) return;
  const v = JSON.stringify({ t: Date.now(), d: S[k] });
  if (v.length < CACHE_MAX) { try { localStorage.setItem('vward-cache-' + k, v); } catch (e) { /* хранилище браузера недоступно */ } }
}
function cacheDrop() { CACHE_KEYS.forEach(k => store.del('vward-cache-' + k)); S.cached = {}; }
const inflight = {};
// How long an answer stays fresh (seconds) before the page's refresh asks again. What changes
// by the second (status, jobs) follows every tick; settings and catalogs rarely change, and
// asking them every 15 seconds only loaded the router. An action reloads what it changed.
const KEY_TTL = { off: 10, notes: 25, status: 5, ads: 10, tq: 55, route: 55, awg: 25, wifi: 55, diag: 55, stab: 55, lists: 110, config: 110, adspub: 55, adsstats: 110, agh: 110,
  https: 290, security: 290, services: 290, update: 110, ext: 590, backups: 290, cron: 110 };
// «Запустить проверку»: the progress, the result or the error stay on the page (the bell is only
// an extra channel). load() keeps errors in S.errors, so a failed run is not reported as done.
let DIAG_RUN = null;
function diagRun() {
  if (DIAG_RUN && DIAG_RUN.busy) return;
  DIAG_RUN = { busy: true };
  render();
  load('diag', true).then(() => {
    const ch = (S.diag && S.diag.checks) || [], err = S.errors.diag, ok = ch.filter(x => x.status === 'PASS').length;
    DIAG_RUN = err ? { error: err, at: new Date() } : { done: true, at: new Date(), ok: ok, n: ch.length };
    render();
    if (err) toast('Диагностика не выполнена: ' + err, 'warn'); else toast('Диагностика выполнена');
  });
}
const diagRunNote = () => {
  const r = DIAG_RUN; if (!r) return '';
  if (r.busy) return '<p class="result-note" role="status">Проверка выполняется…</p>';
  const at = r.at.toLocaleTimeString('ru-RU');
  return r.error ? '<p class="result-note warn" role="status">Проверка не выполнена в ' + at + ': ' + esc(r.error) + '</p>'
                 : '<p class="result-note" role="status">Проверка выполнена в ' + at + ': в норме ' + r.ok + ' из ' + r.n + '.</p>';
};
async function load(key, force) {
  if (inflight[key]) return inflight[key];
  if (!force && S[key] && Date.now() - (S.loadedAt[key] || 0) < (KEY_TTL[key] || 5) * 1000) return S[key];
  inflight[key] = (async () => {
    try { S[key] = await LOADERS[key](); S.errors[key] = null; delete S.cached[key]; cacheWrite(key); if (key === 'status') panelVerWatch(); }
    catch (e) { S.errors[key] = e.message; }
    finally { S.loadedAt[key] = Date.now(); delete inflight[key]; }
    return S[key];
  })();
  return inflight[key];
}
const st = () => S.status || {};
// The router got a new VWARD while this tab was open: its scripts are the old ones. Say so once,
// with a button that loads the new Panel (owner 2026-10-19).
// On the update screen the toast covered its title (owner 2026-10-24): that screen offers the
// reload itself, with the button «Перезагрузить страницу».
let panelVer = '', panelVerSaid = false, panelVerNew = '';
function panelVerWatch() {
  const v = (S.status && S.status.platform && S.status.platform.version) || '';
  if (!v) return;
  if (!panelVer) { panelVer = v; return; }
  if (v === panelVer) return;
  panelVerNew = v;
  if (panelVerSaid || current === 'u-vward') return;
  panelVerSaid = true;
  popup({ sev: 'warn', icon: 'save', title: 'Панель обновлена', text: 'На роутере VWARD ' + v + '. Перезагрузите страницу, чтобы открыть новую версию Панели.', stay: true, btn: ['Перезагрузить страницу', () => location.reload()] });
}
const plat = () => st().platform || {};
const prof = () => (S.security && S.security.profile) || {};
const cfg = () => S.config || {};
const cfgOk = () => !!(S.config && S.config.ok && S.config.writable);
const cfgRoute = () => cfg().route || {};

/* ---------- Структура разделов ---------- */
const PAGES = [
  { id: 'overview', title: 'Обзор', icon: 'home', group: 'Главное', data: ['status', 'route', 'wifi', 'ads', 'adsstats', 'lists', 'awg', 'tq'] },
  { id: 'wan', title: 'Сеть', icon: 'globe', group: 'Сеть', data: ['status', 'security', 'config', 'wifi'] },
  { id: 'vpn', title: 'VPN', icon: 'shield', group: 'Сеть', data: ['status', 'security', 'config', 'route', 'awg', 'ext', 'tq'] },
  { id: 'routes', title: 'Маршруты', icon: 'list', group: 'Сеть', data: ['route', 'security', 'status', 'config', 'lists', 'services'] },
  { id: 'ads', title: 'Реклама и трекеры', icon: 'block', group: 'Сеть', data: ['ads', 'security', 'adspub'] },
  // ИИ-сервисы (owner 2026-10-17): each AI service through VPN, Smart DNS or the provider.
  { id: 'ai', title: 'DNS', icon: 'spark', group: 'Сеть', data: ['ai', 'status', 'config'] },
  // Programs VWARD works with (AdGuard Home, later its own tunnel engine): each has its page here.
  { id: 'utils', title: 'Компоненты', icon: 'tools', group: 'VWARD', data: ['status', 'config', 'cron', 'ads', 'agh', 'security', 'ext', 'awg'] },
  { id: 'system', title: 'Система', icon: 'platform', group: 'VWARD', data: ['status', 'diag', 'security', 'config', 'stab', 'cron', 'cleanup', 'backups', 'update', 'ext'] },
  { id: 'settings', title: 'Настройки', icon: 'sliders', group: 'VWARD', data: ['security', 'auth', 'status', 'config'] },
  // The raw journals: diagnostics to save or send; each section shows its own events itself.
  { id: 'logs', title: 'Журналы', icon: 'logs', group: 'VWARD', data: [] }
];
const SHORT = { ai: 'DNS', overview: 'Обзор', logs: 'Журналы', wan: 'Сеть', vpn: 'VPN', routes: 'Маршруты', ads: 'Реклама', utils: 'Компоненты', system: 'Система', settings: 'Настройки' };
// When each component runs, its section and its log; its name and description come from the parts'
// registry the router sends (fix.38: one list of names, compName / partOf).
const COMPONENTS = [
  { id: 'route-engine', when: 'служба, работает без расписания', page: 'routes', log: 'adaptive' },
  { id: 'route-reconciler', when: 'каждые 5 минут', page: 'routes', log: 'routing' },
  { id: 'route-tools', when: 'подсказки - раз в сутки', page: 'routes', log: 'routing' },
  { id: 'policy-sync', when: 'раз в сутки, в 00:10', page: 'routes', log: 'policy' },
  { id: 'tunnel-guard', when: 'каждую минуту', page: 'vpn', log: 'tunnel' },
  { id: 'wan-guard', when: 'каждую минуту', page: 'wan', log: 'wan' },
  { id: 'wifi-client-guard', when: 'каждые 5 минут', page: 'wifi', log: 'wifi' },
  { id: 'ads-privacy-guard', when: 'каждую минуту', page: 'ads', log: 'ads' },
  { id: 'runtime', when: 'проверка раз в минуту', page: 'system', log: 'cron' },
  { id: 'console', when: 'веб-сервер, без расписания', page: 'settings', log: 'console' },
  { id: 'update-engine', when: 'по настройкам обновлений', page: 'u-vward', log: 'updater' },
  { id: 'platform-core', when: 'не запускается - это файлы версии и карты установки', page: 'system', log: 'console' }
];
const comp = id => COMPONENTS.find(c => c.id === id);
// A part's name: the registry's (before the router's answer: «Компонент»).
const compName = id => (((st().parts || {}).list || []).find(p => p.id === id) || {}).title || 'Компонент';
const capFirst = t => t ? t[0].toUpperCase() + t.slice(1) : t;
/* Граф компонентов приходит из реестра через API (config-data). */
const graphOf = id => ((cfg().components) || []).find(x => x.id === id);
// On or off: the router's answer about the part (fix.38, one source for every page), else the graph.
const compOn = id => { const p = (st().parts && st().parts.list || []).find(x => x.id === id); if (p && p.enabled != null) return p.enabled; const g = graphOf(id); return !g || g.enabled !== false; };
let adsStatsAsked = false;
// Ads switched off as a component: its page's own answer, or the registry when that is loaded.
const adsOff = () => (S.ads && S.ads.component_enabled === false) || !compOn('ads-privacy-guard');
/* Что включится или выключится вместе с компонентом - как в vward-console-config.sh. */
function compCascade(id, off) {
  const g = cfg().components || [];
  // Back on: what went off with it comes back too (vward-console-config.sh does the same).
  let set = [id].concat(off ? [] : g.filter(x => x.off_with === id && x.id !== id && x.enabled === false).map(x => x.id)), grow = true;
  while (grow) {
    const add = off ? g.filter(x => x.requires_running.some(d => set.includes(d))).map(x => x.id)
      : g.filter(x => set.includes(x.id)).reduce((a, x) => a.concat(x.requires_running), []);
    const fresh = add.filter(x => !set.includes(x));
    grow = fresh.length > 0; set = set.concat(fresh);
  }
  return set.slice(1).filter(x => off ? compOn(x) : !compOn(x));
}
const compNames = ids => ids.map(x => '«' + compName(x) + '»').join(', ');
const LOG_TABS = [
  { id: 'wan', label: 'Интернет' }, { id: 'recovery', label: 'Восстановление' }, { id: 'tunnel', label: 'VPN' },
  { id: 'adaptive', label: 'Автоподбор доменов' }, { id: 'core', label: 'Автоподбор (Go)' }, { id: 'routing', label: 'Сверка маршрутов' }, { id: 'policy', label: 'IP-категории' }, { id: 'wifi', label: 'Wi-Fi' },
  { id: 'ads', label: 'Реклама' }, { id: 'updater', label: 'Обновления' }, { id: 'cron', label: 'Расписание' }, { id: 'console', label: 'Панель VWARD' },
  { id: 'awg', label: 'AmneziaWG' }, { id: 'vless', label: 'VLESS' }, { id: 'sentinel', label: 'Реальное время' },
  { id: 'supervisor', label: 'Агент компонентов' }, { id: 'housekeeping', label: 'Обслуживание' }, { id: 'integrity', label: 'Целостность файлов' }, { id: 'off', label: 'Отключение VWARD' }
];
// «Все»: every journal in one timeline (first, and open by default).
const LOG_VIEW = [{ id: 'all', label: 'Все' }].concat(LOG_TABS);
const logLabel = id => (LOG_VIEW.find(t => t.id === id) || {}).label || id;
// logTime LINE: the time an entry starts with («2026-10-04 11:40:12», «…+0300», «…T…Z»), or null.
function logTime(line) {
  const m = /^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(?:\.\d+)?\s*(Z|[+-]\d{2}:?\d{2})?/.exec(line);
  if (!m) return null;
  const tz = !m[3] ? '' : m[3] === 'Z' ? 'Z' : m[3].replace(/^([+-]\d{2}):?(\d{2})$/, '$1:$2');
  const t = Date.parse(m[1] + 'T' + m[2] + tz);
  return isNaN(t) ? null : t;
}
// mergeLogs PARTS: [{label, text}] as one timeline, oldest first; a line without a time
// belongs to the entry above it; each entry is marked with its journal. A line without a time
// and nothing above it («Лог пока пуст или недоступен», a program's raw output) stays in its
// own journal only: in the timeline it stood on top of everything (fix.30).
// Newest first by default (owner 2026-11-01), the order is the viewer's choice; an entry keeps
// its continuation lines under its own time whatever the order. info (optional) receives
// each source's state - its last event, empty, not created or unreadable - so a source with
// nothing new is not «broken» and a broken one is not silently left out.
function mergeLogs(parts, newestFirst, info, limit) {
  const entries = [];
  parts.forEach(p => {
    let last = null, latest = null, n = 0;
    const text = String(p.text || ''), first = text.trim().split('\n')[0] || '';
    text.split('\n').forEach(line => {
      if (!line.trim()) return;
      const t = logTime(line);
      if (t == null && last) { last.lines.push('    ' + line); return; }
      if (t == null) return;
      last = { t: t, n: entries.length, lines: ['[' + p.label + '] ' + line] };
      entries.push(last); n++; if (latest == null || t > latest) latest = t;
    });
    if (info) info.push({ label: p.label, last: latest, state: n ? 'ok' : /^Журнал недоступен/.test(first) ? 'error' : /^Журнал ещё не создан/.test(first) ? 'missing' : /^За последние \d+ ч записей нет/.test(first) ? 'quiet' : 'empty' });
  });
  entries.sort((a, b) => newestFirst ? b.t - a.t || b.n - a.n : a.t - b.t || a.n - b.n);
  // limit: the newest LIMIT entries of the timeline, in the chosen order.
  const kept = !limit || entries.length <= limit ? entries : newestFirst ? entries.slice(0, limit) : entries.slice(-limit);
  return kept.map(e => e.lines.join('\n')).join('\n');
}
/* The journals as cards (owner 02.11, display only - copy, save and share keep the raw files):
   time HH:MM:SS (the date once a day), a level sign, words instead of internal codes, numbers
   rounded with units, no «|»; the autopick checks (HINT_*) folded into one counter in «Важное»,
   warnings and errors always shown. */
let logImportant = (typeof store === 'undefined' ? null : store.get('vward-log-view')) !== 'all';
const LOG_CODES = {
  DNS_CHAIN_OUT: 'AdGuard Home выведен из цепочки DNS, Keenetic спрашивает DNS провайдера', DNS_CHAIN_IN: 'AdGuard Home снова в цепочке DNS',
  DNS_CHAIN_KEEP: 'AdGuard Home оставлен в цепочке: DNS провайдера тоже не отвечает', WOULD_TAKE_OUT: 'Песочница: VWARD вывел бы AdGuard Home из цепочки, Keenetic не изменён',
  START_PHASE: 'Запуск движка: этап',
  HINT_DIRECT_OK: 'Проверка напрямую: открывается', HINT_ADAPTIVE_CHECK: 'Проверка автоподбора', HINT_WG_UNAVAILABLE: 'Подсказка: VPN недоступен, проверка без него',
  HINT_SKIP_RU_ZONE: 'Российский домен: не через VPN', HINT_AGH_BLOCKED: 'Подсказка: домен блокирует AdGuard Home', HINT_SKIP_ADAPTIVE_OFF: 'Подсказка: автоподбор выключен',
  CONSOLE_CONFIG: 'Настройки Панели VWARD изменены', START: 'Автоподбор запущен', STOP: 'Автоподбор остановлен', STOP_REQUEST: 'Остановка по запросу',
  WATCHDOG_RESTART: 'Перезапуск после сбоя', WATCHDOG_CORES_TRANSIENT: 'Второй процесс исчез сам, перезапуск не нужен', START_FAILED: 'Запуск не удался', START_SLOW: 'Медленный запуск, дождались',
  PERSIST_RESTORE_OK: 'AdaptiveAuto восстановлен', PERSIST_RESTORE_PARTIAL: 'AdaptiveAuto восстановлен не полностью', PERSIST_RESTORE_LOCK_FAIL: 'Восстановление AdaptiveAuto отложено: изменения заняты',
  PERSIST_RESTORE_FAIL: 'Keenetic отклонил команду восстановления', PERSIST_RESTORE_SKIP_INVALID: 'Имя пропущено: Keenetic его не примет', PERSIST_MISSING_START: 'Сохранённого AdaptiveAuto нет',
  ADAPTIVE_RU_OUT: 'Российские домены выведены из VPN', AUTO_VPN: 'Через VPN (автоподбор)', AUTO_DIRECT_MAINT: 'Снова напрямую', VPN_OK: 'Открывается через VPN', VPN_OK_RETRY: 'Открывается через VPN',
  DIRECT_OK: 'Открывается напрямую', DIRECT_UNSTABLE: 'Напрямую нестабильно', NO_IPV4: 'Нет IPv4-адреса', ADAPTIVE_NO_IPV4: 'Нет IPv4-адреса', RECHECK_ADAPTIVE: 'Повторная проверка',
  BROKEN_ISP_AND_VPN: 'Не открывается ни напрямую, ни через VPN', MAINT_BROKEN: 'Не открывается ни напрямую, ни через VPN', MAINT_VPN_OK: 'Открывается через VPN',
  MAINT_ISP_UNKNOWN: 'Проверка через провайдера без ответа', MAINT_ISP_BAD: 'Провайдер не пропускает', MAINT_DIRECT_CONFIRM: 'Напрямую: подтверждение', MAINT_DIRECT_CONFIRM_WAIT: 'Напрямую: ждём подтверждения',
  MAINT_ISP_PROBE_UNRELIABLE: 'Проверка через провайдера недостоверна: сайты не оцениваются', ADD_ABORT_ISP_UNRELIABLE: 'Не добавлен в VPN: проверка через провайдера недостоверна',
  ADD_SKIP_RU_ZONE: 'Российский домен: не через VPN', ADD_SKIP_ROUTER_OWN: 'Служба роутера (KeenDNS, облако): не через VPN', HINT_SKIP_ROUTER_OWN: 'Служба роутера (KeenDNS, облако): не через VPN', ADD_ABORT_WG_FAIL: 'Не добавлен: VPN тоже не открывает', ADD_ABORT_DIRECT_RECOVERED: 'Не добавлен: открылся напрямую',
  ABORTED_ISP_PROBE_UNRELIABLE: 'Проверка IP-категорий остановлена: проверка через провайдера недостоверна', ABORTED_TUNNEL_DOWN: 'Проверка IP-категорий остановлена: туннель не отвечает',
  AGH_BIND_FULL: 'Нет места для DNS-привязки в Keenetic', AGH_UNBIND: 'DNS-привязка снята', ADAPTIVE_FULL: 'AdaptiveAuto полон'
};
const logLevel = t => /ERROR|FAILED\b|_FAIL\b|CRASH|BROKEN|ошибк|не удал/i.test(t) ? 'err' :
  /WARN|UNSTABLE|UNRELIABLE|TIMEOUT|_DOWN\b|RESTART|ABORT|SKIP|FULL\b|не отвечает|DNS_CHAIN_OUT|WOULD_TAKE_OUT/i.test(t) ? 'warn' :
  /_OK\b|\bOK\b|PASS|SUCCESS|RECOVERED|RESTORED|_UP\b|DNS_CHAIN_IN\b/.test(t) ? 'ok' : 'info';
const LOG_SIGN = { err: 'alert', warn: 'alert', ok: 'check', info: 'info' };
const wbr = h => h.replace(/([.\-\/])(?=[A-Za-z0-9А-Яа-я])/g, '$1<wbr>');
// Reasons the DNS guard writes (DNS_CHAIN_OUT reason=…, WOULD_TAKE_OUT …): words, not codes.
const LOG_VALUES = { loop_upstream: 'AdGuard Home отправляет запросы обратно роутеру', loop: 'AdGuard Home перезапускался по кругу', silent: 'AdGuard Home не отвечал',
  silent_10min: 'AdGuard Home не отвечал 10 минут', fast: 'AdGuard Home не отвечал 15 с', update: 'плановый перезапуск AdGuard Home', keenetic_busy: 'Keenetic был занят',
  provider_silent: 'DNS провайдера тоже не отвечал', hourly_limit: 'уже выводился в этот час' };
function logField(f) {
  const m = /^([a-z_]+)=(.*)$/i.exec(f), k = m ? m[1] : '', v0 = m ? m[2] : f;
  if ((!k || k === 'reason') && LOG_VALUES[v0]) return (k ? 'причина: ' : '') + LOG_VALUES[v0];
  let v = v0.replace(/\b(\d+)\.(\d{3,})\b/g, (x, a, b) => (Math.round(+(a + '.' + b) * 100) / 100).toString().replace('.', ','));
  // A time field, or a bare fraction with 3+ decimals (curl's time of a probe): seconds.
  if ((/time|took|elapsed|dur|wait/i.test(k) && /^\d+([.,]\d+)?$/.test(v)) || (!k && /^\d+\.\d{3,}$/.test(v0))) v += '\u00a0с';
  return (k ? k.replace(/_/g, ' ') + ': ' : '') + v;
}
function logEntry(raw) {
  let src = '', line = raw.split('\n')[0], more = raw.split('\n').slice(1).map(x => x.trim()).filter(Boolean);
  const sm = /^\[([^\]]+)\] (.*)$/.exec(line); if (sm) { src = sm[1]; line = sm[2]; }
  const t = logTime(line), body = line.replace(/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?\s*(?:Z|[+-]\d{2}:?\d{2})?\s*\|?\s*/, '');
  // A code first, after «|» or a space (CONSOLE_CONFIG op ...): words instead.
  const cm = /^([A-Z][A-Z0-9_]{2,})(?:\s*\|\s*|\s+|$)/.exec(body), code = cm ? cm[1] : '';
  const parts = (cm ? body.slice(cm[0].length) : body).split('|').map(x => x.trim()).filter(Boolean);
  // A Panel action says what really happened (fix.35.3: «result=checked» read «изменены»); its
  // technical words go to the details, the raw line stays in copy and export.
  if (code === 'CONSOLE_CONFIG') {
    const all = parts.join(' '), r = (/\bresult=([a-z_]+)/.exec(all) || [])[1], er = (/\berror=([a-z0-9_]+)/.exec(all) || [])[1];
    const what = r === 'changed' ? 'изменены' : r === 'unchanged' ? 'без изменений' : r === 'checked' ? 'проверены' : er ? 'действие не выполнено' + (API_ERRORS[er] ? ': ' + API_ERRORS[er] : '') : 'действие';
    return { t: t, src: src, code: code, text: 'Настройки Панели VWARD: ' + what, more: [all].concat(more), level: er ? 'warn' : logLevel(code + ' ' + body) };
  }
  // A fork is not a restored VPN channel. Show the attempt as a warning, not
  // a successful recovery; put the technical tunnel identifier in details.
  if (code === 'VLESS_ENGINE') {
    const event = parts[0] || '';
    const attempted = /^restart_attempted (OpkgTun[0-9])(?: on its adapter)?$/.exec(event);
    const started = /^started (OpkgTun[0-9]) by request$/.exec(event);
    if (attempted || started) {
      const tun = (attempted || started)[1];
      return { t: t, src: src, code: code,
        text: attempted ? 'Xray: попытка перезапуска' : 'Xray: процесс запущен, соединение не проверено',
        more: ['Туннель ' + tun].concat(parts.slice(1).map(logField), more),
        level: attempted ? 'warn' : 'info' };
    }
  }
  const words = (code ? (LOG_CODES[code] || code.toLowerCase().replace(/_/g, ' ')) : '') + (parts.length ? (code ? ': ' : '') + parts.map(logField).join(' · ') : '');
  return { t: t, src: src, code: code, text: words.replace(/\bCONSOLE\b/g, 'Панель VWARD').replace(/Консоль/g, 'Панель VWARD'), more: more, level: logLevel(code + ' ' + body) };
}
function logFeed(text) {
  if (text == null) return '<p class="panel-desc log-wait">Загрузка записей…</p>';
  const raw = [], lines = String(text).split('\n');
  lines.forEach(l => { if (!l.trim()) return; if (logTime(l.replace(/^\[[^\]]+\] /, '')) == null && raw.length) raw[raw.length - 1] += '\n' + l; else raw.push(l); });
  if (!raw.length) return '<p class="panel-desc">' + esc(String(text).trim() || 'Записей нет') + '</p>';
  let day = '', html = '', hints = [], hintAt = -1;
  // The same entry again and again in a row (a minute check repeating itself) is one card that
  // says how often and since when; a different entry in between keeps both (owner 02.11).
  const tm = x => x ? new Date(x).toLocaleTimeString('ru-RU') : '';
  const card = (e, rep) => '<div class="log-e ' + e.level + '"><time>' + tm(e.t) + '</time>' + ico(LOG_SIGN[e.level], 'log-sign') +
    '<div class="log-t">' + (e.src ? '<small class="log-src">' + esc(e.src) + '</small>' : '') + wbr(esc(e.text)) + (e.more.length ? '<small class="log-more">' + wbr(esc(e.more.join(' '))) + '</small>' : '') +
    (rep ? '<small class="log-more">Повторилось ' + rep.n + ' ' + plural(rep.n, 'раз', 'раза', 'раз') + ' подряд, ' + tm(Math.min(rep.a, rep.b)) + '–' + tm(Math.max(rep.a, rep.b)) + '</small>' : '') + '</div></div>';
  const out = [];
  let rep = null;
  raw.map(logEntry).forEach(e => {
    const d = e.t ? new Date(e.t).toLocaleDateString('ru-RU') : '';
    const key = e.src + '\n' + e.level + '\n' + e.text + '\n' + e.more.join(' ');
    if (rep && rep.key === key && d === day) { rep.n++; rep.b = e.t; out[rep.at] = card(rep.e, rep); return; }
    rep = null;
    if (d && d !== day) { day = d; out.push('<div class="log-day">' + esc(d) + '</div>'); }
    if (logImportant && /^HINT_/.test(e.code) && (e.level === 'info' || e.level === 'ok')) { if (hintAt < 0) { hintAt = out.length; out.push(''); } hints.push(card(e)); return; }
    rep = { key: key, e: e, n: 1, a: e.t, b: e.t, at: out.length };
    out.push(card(e));
  });
  if (hintAt >= 0) out[hintAt] = '<details class="log-group"><summary>' + ico('route', 'log-sign') + 'Автоподбор: ' + hints.length + ' ' + plural(hints.length, 'проверка', 'проверки', 'проверок') + '</summary>' + hints.join('') + '</details>';
  return out.join('');
}
const DETAILS = {
  'd-diag': { title: 'Диагностика', parent: 'system' },
  'd-stability': { title: 'Стабильность', parent: 'system', data: ['stab', 'status'] },
  'd-files': { title: 'Файлы VWARD', parent: 'system', data: ['files'] },
  'd-control': { title: 'Управление', parent: 'system', data: ['config', 'status', 'ads', 'lists', 'ext'] },
  'd-cron': { title: 'Задания по расписанию', parent: 'd-diag' },
  'u-vward': { title: 'VWARD', parent: 'system', data: ['status', 'update', 'config'] },
  'u-agh': { title: 'Обновление AdGuard Home', parent: 'system', data: ['ext'] },
  'u-fw': { title: 'Прошивка Keenetic', parent: 'system', data: ['ext'] },
  'u-opkg': { title: 'Пакеты Entware', parent: 'system', data: ['ext'] },
  'd-notes': { title: 'Что нового', parent: 'u-vward', data: ['status', 'update'] },
  'd-mydomains': { title: 'Мои домены', parent: 'routes' },
  'd-force': { title: 'Мои домены', parent: 'routes' },
  'd-adaptive': { title: 'Автоподбор доменов', parent: 'routes' },
  'd-smartdns': { title: 'Домены Smart DNS', parent: 'ai', data: ['lists', 'config'] },
  'd-wanrec': { title: 'Восстановление: дополнительно', parent: 'wan', data: ['status', 'config', 'wanhist'] },
  'd-rsources': { title: 'Источники', parent: 'routes', data: ['route', 'services'] },
  'd-services': { title: 'Сервисы', parent: 'routes', data: ['services', 'lists', 'status', 'config'] },
  'd-wificlients': { title: 'Все клиенты', parent: 'wifi', data: ['wifi', 'config'] },
  'd-ipcats': { title: 'IP-категории', parent: 'routes', data: ['route', 'config', 'status'] },
  lists: { title: 'Доменные списки', parent: 'routes', data: ['lists', 'config', 'status', 'services'] },
  wifi: { title: 'Wi-Fi клиенты', parent: 'wan', data: ['wifi', 'security', 'config'] },
  'd-querylog': { title: 'Журнал запросов', parent: 'ads' },
  'd-adrecent': { title: 'Решения агента', parent: 'ads' },
  'd-adspub': { title: 'Правила в AdGuard Home', parent: 'ads' },
  'd-adprobe': { title: 'Подробный разбор', parent: 'ads' },
  'd-adsettings': { title: 'Настройки проверки', parent: 'ads' },
  'd-review': { title: 'На проверке', parent: 'ads' },
  'd-blocked': { title: 'Заблокировано', parent: 'ads' },
  'd-allowed': { title: 'Разрешено', parent: 'ads' },
  'd-adcats': { title: 'Категории блокировки', parent: 'ads' },
  'd-rules': { title: 'Мои правила', parent: 'ads' },
  'd-sources': { title: 'Источники списков', parent: 'ads' },
  'd-jobs': { title: 'Задания', parent: 'ads' },
  'd-https': { title: 'HTTPS-фильтр', parent: 'ads' },
  'd-agh': { title: 'AdGuard Home', parent: 'utils', data: ['status', 'ads', 'agh', 'security', 'ext', 'adsstats'] },
  'd-dnsex': { title: 'Исключения фильтрации', parent: 'd-agh', data: ['ads'] },
  'd-awg': { title: 'AmneziaWG', parent: 'utils', data: ['awg', 'status', 'ext', 'lists'] },
  'd-vless': { title: 'Модуль VLESS', parent: 'utils', data: ['awg', 'status', 'lists'] },
  'd-dnsmasq': { title: 'dnsmasq', parent: 'utils', data: ['status'] },
  'd-singbox': { title: 'sing-box', parent: 'utils', data: ['status', 'awg'] },
  'd-dnscap': { title: 'Захват DNS-запросов', parent: 'utils', data: ['status'] },
  'd-doh': { title: 'DoH-клиент', parent: 'utils', data: ['status'] },
  'd-agents': { title: 'Агенты', parent: 'utils', data: ['config', 'status', 'cron'] },
  'd-aghfilters': { title: 'Фильтры AdGuard Home', parent: 'd-agh', data: ['agh', 'ads'] },
  'd-aghservices': { title: 'Блокировка сервисов', parent: 'd-agh', data: ['agh', 'ads'] }
};
// fix.38.1 (Panel audit 12.11.2026): the «Зависимости» pages had no way in since stage 3 - gone; an old
// address opens the component (idOf), the links between parts stay in the switch-off confirmation.
COMPONENTS.forEach(c => { DETAILS['c-' + c.id] = { get title() { return compName(c.id); }, parent: 'utils' }; });
function page(id) {
  if (!id) return null;
  const p = PAGES.find(x => x.id === id);
  if (p) return p;
  if (DETAILS[id]) return Object.assign({ id: id }, DETAILS[id]);
  if (id.startsWith('t-')) return { id: id, title: tunLabel(id.slice(2)), parent: 'vpn' };
  if (id.startsWith('tn-')) return { id: id, title: 'Подсети', parent: 't-' + id.slice(3) };
  if (id.startsWith('l-')) { const l = ((S.lists && S.lists.lists) || []).find(x => x.name === id.slice(2)); return { id: id, title: l ? l.description || l.name : 'Список', parent: 'lists' }; }
  if (id.startsWith('ip-')) return { id: id, title: 'IP-адреса', parent: 'l-' + id.slice(3) };
  if (id.startsWith('s-')) { const x = ((S.services && S.services.services) || []).find(v => v.id === id.slice(2)); return { id: id, title: x ? x.title : id.slice(2), parent: 'd-services' }; }
  if (id.startsWith('w-')) return { id: id, title: typeof wifiName === 'function' ? wifiName(id.slice(2)) : id.slice(2), parent: 'wifi' };
  return null;
}
const parentOf = id => { const p = page(id); return p && p.parent; };
// Every page has its own address, built from the way to it: /network, /vpn/tunnel/<name>,
// /domains/lists/<list>/ip.  Old #addresses still open.
const SLUG = { ai: 'ai', 'd-control': 'control', overview: '', wan: 'network', vpn: 'vpn', routes: 'domains', lists: 'lists', wifi: 'wifi', ads: 'ads', system: 'system', settings: 'settings', logs: 'logs', utils: 'utilities', 'd-agh': 'adguard-home', 'd-awg': 'amneziawg',
  'd-mydomains': 'my', 'd-force': 'always-vpn', 'd-adaptive': 'autopick', 'd-rsources': 'sources', 'd-services': 'services', 'd-ipcats': 'ip-categories', 'd-wanrec': 'recovery', 'd-wificlients': 'clients',
  'u-vward': 'vward', 'u-agh': 'adguard-home-update', 'u-fw': 'firmware', 'u-opkg': 'entware', 'd-dnsex': 'exceptions', 'd-aghfilters': 'filters', 'd-aghservices': 'services', 'd-adcats': 'categories',
  'd-adrecent': 'recent', 'd-adspub': 'publish', 'd-adprobe': 'probe', 'd-adsettings': 'settings',
  'd-dnsmasq': 'dnsmasq', 'd-singbox': 'sing-box', 'd-dnscap': 'dns-capture', 'd-doh': 'doh-client' };
function slugOf(id) {
  if (Object.prototype.hasOwnProperty.call(SLUG, id)) return SLUG[id];
  const m = /^(ip|tn|[duactlsw])-(.+)$/.exec(id);
  const enc = v => encodeURIComponent(v).replace(/%3A/gi, ':');
  if (!m) return enc(id);
  const k = m[1], v = m[2];
  return k === 'a' ? 'events-' + v : k === 'ip' ? 'ip' : k === 'tn' ? 'subnets' : k === 't' ? 'tunnel/' + enc(v) : enc(v);
}
function pathOf(id) {
  const seg = []; let x = id, n = 0;
  while (x && n++ < 12) { const sl = slugOf(x); if (sl) seg.unshift(sl); x = parentOf(x); }
  return '/' + seg.join('/');
}
function idOf(path) {
  let p = '/' + String(path || '').split(/[?#]/)[0].replace(/^\/+|\/+$/g, '');
  // «Обновления» live in «Система» since 2026-10-17: old links still open.
  if (p === '/updates' || p.startsWith('/updates/')) p = '/system' + p.slice(8);
  if (p === '/' || p === '/index.html') return 'overview';
  const hit = PAGES.map(x => x.id).concat(Object.keys(DETAILS)).find(id => pathOf(id) === p);
  if (hit) return hit;
  const under = (base, rest) => p.startsWith(base + '/') ? p.slice(base.length + 1).split('/').map(decodeURIComponent) : null;
  let r = under(pathOf('vpn'));
  if (r && r.length === 2 && r[0] === 'tunnel') return 't-' + r[1];
  if (r && r.length === 3 && r[0] === 'tunnel' && r[2] === 'subnets') return 'tn-' + r[1];
  r = under(pathOf('lists'));
  if (r && r.length === 1) return 'l-' + r[0];
  if (r && r.length === 2 && r[1] === 'ip') return 'ip-' + r[0];
  r = under(pathOf('wifi'));
  if (r && r.length === 1) return 'w-' + r[0];
  r = under(pathOf('d-services'));
  if (r && r.length === 1) return 's-' + r[0];
  // A bookmark of a removed «Зависимости» page (…/<component>/deps) opens the component.
  if (/\/deps$/.test(p)) return idOf(p.slice(0, -5));
  return null;
}
const navId = id => { let x = id; while (parentOf(x)) x = parentOf(x); return x; };
const DATA_FOR = id => { if (DETAILS[id] && DETAILS[id].data) return DETAILS[id].data; const p = PAGES.find(x => x.id === navId(id)); return p ? p.data : []; };

/* ---------- Состояние интерфейса ---------- */
const TAB_MAX = 4, TAB_DEFAULT = ['overview', 'wan', 'vpn', 'routes'];
const tabStored = store.get('vward-tabs', TAB_DEFAULT);
let tabIds = (Array.isArray(tabStored) ? tabStored : TAB_DEFAULT).filter(id => PAGES.some(p => p.id === id)).slice(0, TAB_MAX);
// Sections that became pages inside others (lists, Wi-Fi) leave the bar; defaults fill their
// place. Only then: a section the owner took off the bar stays off after a reload.
if (!tabIds.length || tabIds.length < Math.min(Array.isArray(tabStored) ? tabStored.length : 0, TAB_MAX))
  TAB_DEFAULT.forEach(id => { if (tabIds.length < TAB_MAX && !tabIds.includes(id)) tabIds.push(id); });
// Once: the journals left the panel (sections show their own events); the free place gets a default section.
if (!store.get('vward-tabs-logs-moved', false)) {
  tabIds = tabIds.filter(id => id !== 'logs');
  TAB_DEFAULT.forEach(id => { if (tabIds.length < TAB_MAX && !tabIds.includes(id)) tabIds.push(id); });
  store.set('vward-tabs', tabIds); store.set('vward-tabs-logs-moved', true);
}
let theme = store.get('vward-theme', 'system'); if (!['system', 'time', 'light', 'dark'].includes(theme)) theme = 'system';
const REFRESH_SEC = 15;
// No «Среда выполнения»: a stopped scheduler is a notification in the bell (owner 2026-10-12).
const CARD_IDS = ['system', 'updates', 'wan', 'vpn', 'lists', 'routes', 'wifi', 'ads', 'storage'];
let cardOrder = store.get('vward-card-order', CARD_IDS).filter(id => CARD_IDS.includes(id));
CARD_IDS.forEach((id, i) => { if (!cardOrder.includes(id)) cardOrder.splice(Math.min(i, cardOrder.length), 0, id); });
let hiddenCards = store.get('vward-card-hidden', []).filter(id => CARD_IDS.includes(id));
let cardView = store.get('vward-card-view', 'grid'); if (!['grid', 'list'].includes(cardView)) cardView = 'grid';
let authForm = false, loginOpen = false;
let current = 'overview', editing = false, confirm = null, logTab = 'all', logWrap = true, actionResult = null;
// «Все»: newest first unless the viewer chose otherwise (kept in this browser); each source's state.
let logNewest = store.get('vward-log-order') !== 'oldest';
const LOGINFO = [];
// «Журналы» load on the owner's request only (owner 12.11.2026: «Показать журнал», the last N
// entries, more on request, nothing by itself). logShown: what each source was asked for on this
// visit (nothing: not shown); logN: entries a time, kept in this browser.
const LOG_STEPS = [50, 100, 200], LOG_MAX = 1000, LOGMORE = {};
let logN = LOG_STEPS.includes(+store.get('vward-log-n')) ? +store.get('vward-log-n') : 50;
let logShown = {}, logFilters = false, logQuery = '';

/* ---------- Построение блоков ---------- */
// The heading and its description sit above the card; the card holds only the content.
// A block's own status sits in its heading instead of a first row repeating the title.
const headPill = (cls, text) => '<span class="pill ' + (cls || '') + ' head-pill">' + esc(text) + '</span>';
// Collapsed blocks, per page and title, kept in this browser (at most 300).
const FOLDED = store.get('vward-folded', {});
const foldKey = title => current + '|' + title;
function foldToggle(key) {
  if (FOLDED[key]) delete FOLDED[key]; else FOLDED[key] = 1;
  const keys = Object.keys(FOLDED);
  keys.slice(0, Math.max(0, keys.length - 300)).forEach(k => delete FOLDED[k]);
  store.set('vward-folded', FOLDED);
}
// The icon of a block's title (owner 2026-10-17: every section with its sign), by its words.
const HEAD_ICONS = [
  [/^Добавить|^Новый/, 'plus'],
  // Each section its own sign (owner 02.11: one «i» for different sections).
  [/Хранение журнал/, 'archive'], [/Восстановление интернета/, 'globe'], [/^Исключени/, 'filter'], [/^Режим/, 'sliders'], [/События и реакции/, 'pulse'],
  [/Удален|Корзин/, 'trash'], [/Очистк/, 'broom'], [/Сброс/, 'reset'], [/Аварийн/, 'power'], [/Резервн/, 'archive'],
  [/Сертификат/, 'cert'], [/ИИ-сервис/, 'spark'], [/Управлени/, 'sliders'], [/Агент|Работают всегда|Решения агента|Предполагаем/, 'shield'],
  [/Сервер|Страны/, 'server'], [/Smart DNS|DNS/, 'dns'], [/AdGuard|Фильтр|Блокиров|Заблокир|Разрешено|Правил|На проверке/, 'block'],
  [/Туннел|VPN|Переподключ|Модуль/, 'shield'], [/Маршрут|Доменн|Домен|Подсет|Список|Списки|Сервис|IP-категор|Автоподбор/, 'route'],
  [/Wi-Fi|Диапазон|Устройства|Клиент/, 'wifi'], [/Интернет|Сеть|Подключение|Смена адреса|Домашняя/, 'globe'],
  [/Обновлен|Пакеты|Прошивк|Установлено|Последние установки/, 'download'], [/Журнал|Событи|История|Итог/, 'logs'],
  [/Хранилищ|Папки|Файл|Флешк/, 'usb'], [/Расписан|Планировщик|Задани|Очередь/, 'clock'], [/Нагрузк|Стабильност/, 'pulse'],
  [/Диагностик|Проверк/, 'check'], [/Уведомлен/, 'bell'], [/Вход|Доступ/, 'lock'], [/Оформлени|Меню/, 'sliders'],
  [/Автоматика/, 'refresh'], [/Устройство|Состояние|Система|Платформ|Программы|Компонент|Зависи|Нужен для|Утилит/, 'platform'], [/Настройк|Дополнительно|Конфигурац/, 'sliders']
];
// Four states of a program or module, everywhere (owner 2026-10-17): works, switched off by you,
// not needed now, failing.
const ST = { on: ['ok', 'Работает'], off: ['off', 'Выключен'], idle: ['off', 'Отключён'], bad: ['crit', 'Не работает'], none: ['off', 'Не установлен'], unlinked: ['off', 'Не подключено'] };
// One component state model (owner 2026-11-01). The facts stay apart: known, installed, enabled
// (not switched off by the owner or by VWARD), selected (in the active DNS chain / serving a
// tunnel / meant to run), running (a process), works (proven by a check: true, false, or null
// when not proven). «Работает» only when the work itself is proven, never from a process alone.
const CS = { works: ['ok', 'Работает'], installed: ['off', 'Установлен'], off: ['off', 'Выключен'], unused: ['off', 'Не используется'],
  none: ['off', 'Не установлен'], bad: ['crit', 'Не работает'], nolink: ['crit', 'Нет связи'], unknown: ['', 'Нет данных'] };
function compStatus(f) {
  if (!f || !f.known) return CS.unknown;
  if (!f.installed) return CS.none;
  if (f.enabled === false) return CS.off;
  if (!f.selected) return f.running ? CS.unused : CS.installed;
  if (f.works === true) return CS.works;
  if (f.works === false) return f.vpn ? CS.nolink : CS.bad;
  return CS.unknown;
}
// System services: a process is not enough, the work must be fresh (state file of the sentinel
// within 3 minutes; domains captured within 15 minutes). No fresh data is «Нет данных», not green.
// Lightened VWARD (owner 11.11.2026): optional parts of the agents, off until switched on one by one;
// their names and switches are the parts' registry (fix.38).
const extrasOf = () => (st().services || {}).extras || null;
// An older router answer without «extras»: every part on, as before the lightening.
const extraOn = n => { const x = extrasOf(); return !x || !!x.all || (x.on || []).includes(n); };
const sentinelFacts = (se, known) => ({ known, installed: !!se.installed, enabled: true, selected: !!se.installed, running: !!se.running,
  works: !se.running ? false : se.fresh === true ? true : se.fresh === false ? false : null });
const dnscapFacts = (cp, known) => ({ known, installed: !!cp.installed, enabled: true, selected: !!cp.installed, running: !!cp.running,
  works: !cp.running ? false : cp.fresh === true ? true : null });
const dohFacts = (d, known) => ({ known, installed: !!d.installed, enabled: true, selected: !!d.running, running: !!d.running, works: null });
// The active DNS handler chosen by the owner (dns-mode): AdGuard Home unless set otherwise.
const dnsMode = () => { const c = (((st().services || {}).components) || []).find(x => x.id === 'dns-mode'); return c ? c.state : 'agh'; };
const pkgFacts = id => {
  const c = (((st().services || {}).components) || []).find(x => x.id === id), known = !!S.status && !S.cached.status;
  if (!c || c.state === 'unknown') return { known: false };
  // «Выключен» is the owner's own choice; a package left off after installation (the default)
  // is «Установлен» while not selected, «Не работает» once selected and still not running.
  return { known, installed: c.state !== 'not-installed', autostart: c.state === 'enabled-not-running' || c.state === 'running-unverified',
    running: c.state === 'running-unverified', version: c.version, label: c.label };
};
// One state of AdGuard Home for every page (owner 2026-10-19): «Не установлен», «Не подключено»,
// «Выключен» - grey; «Работает» - green; «Не работает» - red. [class, text, why]: the program
// that does not run comes first - connected or not, nothing works through it (Viva 2026-10-19:
// «Не подключено» on one page, «Не работает» on another, the program not running at all).
// Data from the browser's copy while the router has not answered yet: no verdict on it (Viva
// 2026-10-21: «Не установлен» from a copy older than the installation, the router slow).
function aghState() {
  const v = aghVerdict();
  if (S.cached.status && v[0] !== 'ok') return ['', 'Нет данных', 'роутер ещё не ответил, последние данные от ' + new Date(S.cached.status).toTimeString().slice(0, 5)];
  return v;
}
function aghVerdict() {
  const a = S.ads || {}, g = S.agh, sv = st().services || {}, ag = (S.security && S.security.external_services && S.security.external_services.adguard) || {}, e = (S.ext && S.ext.agh) || {};
  if (!S.ads || !S.status) return ['', '—', ''];
  const installed = !!sv.adguard || !(sv.adguard_installed === false || (sv.adguard_installed == null && !ag.port && !e.installed && !(e.official || {}).installed));
  const running = sv.adguard === true, selected = dnsMode() === 'agh', down = running && a.agh_connected && aghDown(a, g);
  // The common model (compStatus); the owner's own «фильтрация выключена» stays «Выключен».
  const f = { known: true, installed, enabled: !sv.adguard_disabled && !(g && g.ok && g.protection === false), selected, running,
    works: !running || sv.adguard_broken ? false : !a.agh_connected ? null : down ? false : true };
  const why = !installed ? 'программа не найдена на роутере' : sv.adguard_disabled ? 'выключен в Панели' : g && g.ok && g.protection === false ? 'фильтрация выключена' :
    !selected ? (running ? 'запущен, но не в DNS-цепочке' : 'не выбран активным DNS') : sv.adguard_broken ? 'программа не запускается на этом роутере' :
    !running ? 'программа не запущена' : !a.agh_connected ? 'VWARD не подключён: нужны логин и пароль' : down ? 'не отвечает на запросы' : '';
  return compStatus(f).concat(why);
}
const headIcon = t => { const m = HEAD_ICONS.find(x => x[0].test(t || '')); return m ? m[1] : 'info'; };
function panel(title, body, opts) {
  opts = opts || {};
  const p = page(current), same = p && p.title === title, extra = opts.readonly || opts.right;
  // A block under its own title folds to that title (the page's main block and the address
  // check do not); the state on the right of the title stays visible.
  const foldable = !same && !opts.fixed && !!title, key = foldable ? foldKey(title) : '', folded = foldable && !!FOLDED[key];
  const toggle = foldable ? '<button class="block-toggle" type="button" data-fold="' + esc(key) + '" aria-expanded="' + !folded + '" aria-label="' + (folded ? 'Развернуть' : 'Свернуть') + ' «' + esc(title) + '»" title="' + (folded ? 'Развернуть' : 'Свернуть') + '">' + ico('chevron') + '</button>' : '';
  const longDesc = opts.desc && String(opts.desc).length > DESC_MAX && !!title, dq = 'p:' + title;
  // A page's own block: its «?» goes next to the page title at the top (owner 2026-11-01:
  // the title and its «?» together, never apart); the explanation opens in the block.
  if (same && longDesc) PAGEQ = { k: dq, title: title, shown: true };
  const head = same && !extra ? '' : '<div class="block-head' + (foldable ? ' foldable' : '') + '"' + (foldable ? ' data-fold="' + esc(key) + '"' : '') + '>' + (same ? '' : '<h2>' + ico(opts.icon || headIcon(title), 'head-ico') + esc(title) + '</h2>') + (longDesc && !folded && !same ? qBtn(dq, title) : '') + (opts.beta ? '<span class="tag beta">Бета</span>' : '') + (opts.readonly ? '<span class="note">' + ico('lock') + 'Только чтение</span>' : '') + (opts.right || '') + toggle + '</div>';
  return '<section class="block' + (folded ? ' folded' : '') + '"' + (same ? ' aria-label="' + esc(title) + '"' : '') + '>' + head + (folded ? '' : (opts.desc && (!longDesc || same || qOpen(dq)) ? '<p class="block-desc">' + esc(opts.desc) + '</p>' : '') + (body ? '<div class="panel">' + body + '</div>' : '')) + '</section>';
}
/* A long explanation hides behind «?» next to its title and opens in place (owner 2026-10-17);
   short ones stay visible. QOPEN keeps what is open across re-renders of the page. */
const HINT_MAX = 40, DESC_MAX = 70, QOPEN = new Set();
const qKey = k => current + '|' + k, qOpen = k => QOPEN.has(qKey(k));
const qBtn = (k, what) => '<button class="q-btn" type="button" data-q="' + esc(k) + '" aria-expanded="' + qOpen(k) + '" aria-label="Пояснение: ' + esc(what) + '" title="Пояснение">' + ico('help') + '</button>';
function dtHtml(key, hint) {
  if (!hint) return esc(key);
  const s = String(hint);
  if (s.length <= HINT_MAX) return esc(key) + '<span class="hint">' + esc(s) + '</span>';
  return '<span class="dt-t">' + esc(key) + qBtn('r:' + key, key) + '</span><span class="hint more"' + (qOpen('r:' + key) ? '' : ' hidden') + '>' + esc(s) + '</span>';
}
/* Строка: [название, значение, метка состояния, переход (страница или http-адрес), доп. атрибуты перехода, подсказка] */
function kv(rows) {
  return '<dl class="kv">' + rows.filter(Boolean).map(r => {
    const ext = r[3] && /^https?:/.test(r[3]);
    const none = !r[2] && /^(нет|—|не было|нет данных|не установлен|пусто)$/.test(String(r[1]));
    const val = r[2] ? '<span class="pill ' + r[2] + '">' + esc(r[1]) + '</span>' : '<span class="num' + (none ? ' none' : '') + '">' + esc(r[1]) + '</span>';
    const link = r[3] && !ext;
    return '<div class="kv-row' + (link ? ' link" role="button" tabindex="0" data-go="' + esc(r[3]) + '"' + (r[4] || '') : '"') + ' data-key="' + esc(r[0]) + '"><dt>' + dtHtml(r[0], r[5]) + '</dt><dd>' +
      (ext ? '<a class="kv-ext" href="' + esc(r[3]) + '" target="_blank" rel="noopener">' + val + ico('external', 'chev') + '</a>' : val + (link ? ico(r[6] ? 'external' : 'chevron', 'chev') : '')) + '</dd></div>';
  }).join('') + '</dl>';
}
function ctrlRow(key, control, hint, cls) { if (!cls && /<select|seg-slider/.test(control)) cls = 'stack'; return '<div class="kv-row' + (cls ? ' ' + cls : '') + '" data-key="' + esc(key) + '"><dt>' + dtHtml(key, hint) + '</dt><dd>' + control + '</dd></div>'; }
const sw = (attr, on, label, disabled) => '<label class="switch"><input type="checkbox" ' + attr + (on ? ' checked' : '') + (disabled ? ' disabled' : '') + ' aria-label="' + esc(label) + '"><i></i></label>';
const sel = (attr, label, opts, value) => '<select class="input compact" ' + attr + ' aria-label="' + esc(label) + '">' + opts.map(o => '<option value="' + esc(o[0]) + '"' + (String(value) === String(o[0]) ? ' selected' : '') + (o[2] ? ' disabled' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select>';
// One sign per action across the Panel (owner 2026-10-17): delete - a bin, clear - a broom...
const BTN_ICONS = [[/^Удалить/, 'trash'], [/^Очистить/, 'broom'], [/^Скачать/, 'download'], [/^Установить/, 'box'], [/^Выйти/, 'logout'],
  [/^Сбросить|^Полный сброс/, 'reset'], [/^(Выключить|Отключить|Включить)/, 'power'], [/^(Перезапустить|Обновить|Повторить)/, 'refresh'],
  [/^Проверить/, 'refresh'], [/^Переустановить/, 'refresh'], [/^Добавить/, 'plus'], [/^Сохранить|^Применить/, 'save'], [/^Восстановить|^Вернуть/, 'undo'], [/^Отмена/, 'close']];
const btnIcon = (label, icon) => { const m = BTN_ICONS.find(x => x[0].test(label || '')); return m ? m[1] : icon; };
const btn = (act, icon, label, cls, extra) => { const i = btnIcon(label, icon); return '<button class="btn' + (cls ? ' ' + cls : '') + '" type="button" data-act="' + act + '"' + (extra || '') + '>' + (i ? ico(i) : '') + esc(label) + '</button>'; };
const empty = t => '<div class="empty">' + esc(t) + '</div>';
function confirmBox(id, text, yesLabel, danger) {
  if (!confirm || confirm.id !== id) return '';
  return '<div class="confirm' + (danger ? ' danger' : '') + '"><span>' + esc(text) + '</span><button class="btn small ' + (danger ? 'danger' : 'primary') + '" type="button" data-act="confirm-yes">' + ico(btnIcon(yesLabel, 'check')) + esc(yesLabel) + '</button><button class="btn small" type="button" data-act="confirm-no">' + ico('close') + 'Отмена</button></div>';
}
function resultBox(id) {
  if (!actionResult || actionResult.id !== id) return '';
  // One short line: the details are in «Журналы».
  const t = String(actionResult.text || '').split('\n')[0].slice(0, 160);
  return t ? '<p class="result-note">' + esc(t) + '</p>' : '';
}
function loadError(keys) {
  const errs = keys.map(k => S.errors[k]).filter(Boolean);
  // One short line with a spinner (owner 02.11): it does not grow the page or cover it.
  return errs.length ? '<p class="field-warn retry" title="' + esc(errs[0]) + '"><i class="spin" aria-hidden="true"></i>Часть данных не получена · повторяем…</p>' : '';
}

/* ---------- Обновления других программ ---------- */
const extVer = v => String(v || '—').replace(/^v(?=\d)/, '');
const autoText = on => on ? 'автоматически' : 'вручную';
// Keenetic's check stamp: "Sep 26 18:07:08", no year.
const fwStamp = t => { const m = /^([A-Z][a-z]{2}) +(\d{1,2}) (\d\d:\d\d)/.exec(String(t || '')); return m && MON[m[1]] ? ('0' + m[2]).slice(-2) + '.' + ('0' + MON[m[1]]).slice(-2) + ' ' + m[3] : (t || '—'); };
const fwChannel = c => ({ stable: 'Основной', preview: 'Предварительный', draft: 'Тестовый' })[c] || c;
const EXT_RESULT = { ok: 'установлено', rolled_back: 'не прошло проверку, возвращена прежняя версия', rollback_failed: 'ошибка возврата' };
function extHistory(hist, keep) {
  const h = (hist || []).filter(keep).slice(0, 5);
  return h.length ? panel('Последние установки', kv(h.map(r => [r.name + ' ' + extVer(r.to), EXT_RESULT[r.result] || r.result, r.result === 'ok' ? 'ok' : 'crit', null, '', fmtStamp(r.at) + ' · было ' + extVer(r.from)]))) : '';
}
function extRunNote(run, pkg) {
  if (!run || !run.running || runningId === 'ext') return '';
  if (pkg && run.label !== 'ext-upgrade-' + pkg) return '';
  return '<p class="result-note">Выполняется: ' + esc(run.label === 'ext-check' ? 'проверка' : 'установка') + '…</p>';
}
// While a check runs, its button says so: no separate progress line.
// «Проверить всё» on «Обновления»: VWARD too, not only the packages and the firmware.
const allCheckBtn = () => { const busy = runningId === 'ext' || runningId === 'updates'; return btn('all-check', 'refresh', busy ? 'Проверяем…' : 'Проверить всё', '', busy ? ' disabled' : ''); };
const extCheckBtn = label => btn('ext-check', 'refresh', runningId === 'ext' ? 'Проверяем…' : label, '', runningId === 'ext' ? ' disabled' : '');
const EXT_OK = { check: 'Проверка завершена', upgrade: 'Обновление установлено', 'agh-official': 'AdGuard Home установлен' };
function extOp(op, pkg, token) {
  return runLong('ext', 'ext-update-control', pkg ? { op: op, pkg: pkg, confirm: token } : token ? { op: op, confirm: token } : { op: op }, 'ext-update-data', EXT_OK[op])
    .then(() => load('ext', true)).then(render);
}

/* ---------- Уведомления ---------- */
function notifications() {
  const n = [], s = S.status;
  if (S.errors.status) n.push(/^роутер не ответил/.test(S.errors.status)
    // A timeout is a busy Keenetic, not a lost one (a Viva 2026-10-13: «Нет связи» while it answered slowly).
    ? { sev: 'warn', title: 'Роутер отвечает медленно', text: S.errors.status + ', VWARD повторит сам', to: 'system' }
    : { sev: 'crit', title: /^нет связи/.test(S.errors.status) ? 'Нет связи с роутером' : 'Роутер отвечает с ошибкой', text: S.errors.status, to: 'system' });
  const sdc = ((S.lists && S.lists.lists) || []).filter(l => l.smartdns_conflict);
  if (sdc.length) n.push({ sev: 'warn', title: 'Smart DNS уйдёт в VPN', text: 'Домены Smart DNS есть в списках через VPN: ' + sdc.map(l => l.description || l.name).join(', '), to: 'lists' });
  if (!s) return n;
  // What the owner switched off in «Управление» is not forgotten (owner 2026-10-17).
  const w = s.wan || {}, wg = s.wg || {}, sv = s.services || {}, p = s.platform || {}, stg = s.storage || {};
  if (w.internet === false) n.push({ sev: 'crit', title: 'Нет интернета', text: 'VWARD восстанавливает подключение', to: 'wan' });
  // A tunnel the owner switched off is the owner's choice, not news; one the VPN agent switched off is (below).
  const tunnels = wg.interfaces || [], down = tunnels.filter(t => !isTrue(t.connected) && !tunOff(t) && !tunGuardOff(t) && !tunLost(t)), lostT = tunnels.filter(tunLost);
  // Keenetic takes no two tunnels with one address: the second one never connects.
  tunDupAddresses(tunnels).forEach(d => n.push({ sev: 'warn', title: 'У двух туннелей один адрес', text: d.names.map(tunLabel).join(', ') + ': ' + d.addr + '. Keenetic не соединит второй туннель - замените конфигурацию одного из них.', to: 't-' + d.names[1] }));
  // A VWARD tunnel whose settings went with the old USB drive: one note with what to do, not «не в сети».
  if (lostT.length) { const routed = lostT.filter(t => tunUseExtra(t.name) > 0);
    n.push({ sev: 'warn', title: lostT.length === 1 ? 'Туннель без настроек' : 'Туннели без настроек: ' + lostT.length, text: lostT.map(t => t.description || t.name).join(', ') + (routed.length ? ' - на нём списки и подсети, они идут напрямую: перенесите их' : ' - добавьте заново или удалите'), to: routed.length ? 't-' + routed[0].name : 'vpn' }); }
  if (down.length) n.push({ sev: 'warn', title: down.length === tunnels.length - lostT.length ? 'VPN не в сети' : 'Не все туннели в сети', text: down.map(t => t.description || t.name).join(', '), to: 'vpn' });
  if (S.ai && aiRoom(S.ai.smartdns)) n.push({ sev: 'info', title: 'В Smart DNS освободилось место', text: S.ai.smartdns.waiting.map(aiName).join(', ') + ' можно перевести на Smart DNS', to: 'ai' });
  // A move off a tunnel that no longer exists is not news: there is nothing to come back to.
  const tunExists = t => !t || ((st() && st().wg && st().wg.interfaces) || []).some(x => x.name === t);
  if (S.tq && S.tq.fallback_from && tunExists(S.tq.fallback_from)) n.push({ sev: 'warn', title: '«' + tunLabel(S.tq.fallback_from) + '» не отвечает', text: 'маршруты VWARD переведены на «' + tunLabel(prof().tunnel_interface) + '»', to: 'vpn' });
  const lm = ((S.tq && S.tq.lists_moved) || []).filter(m => tunExists(m.from));
  const qa = (S.tq && S.tq.auto) || {};
  if (qa.last_at && qa.last_to && Date.now() / 1000 - qa.last_at < 3600) n.push({ sev: 'news', icon: 'route', title: 'Туннель выбран по качеству', text: 'маршруты VWARD: «' + tunLabel(qa.last_from || '') + '» → «' + tunLabel(qa.last_to) + '», ' + fmtTime(qa.last_at * 1000), to: 'vpn' });
  if (lm.length) n.push({ sev: 'warn', title: lm.length === 1 ? 'Список переведён на другой туннель' : 'Списки переведены на другие туннели', text: lm.map(m => listLabel(m.name) + ': «' + tunLabel(m.from) + '» → «' + tunLabel(m.to) + '»').join(', '), to: 'vpn' });
  if (isTrue(wg.failopen_active)) { const ti = prof().tunnel_interface; n.push({ sev: 'warn', own: true, title: '«' + tunLabel(ti) + '» выключен агентом VPN' + (wg.failopen_at ? ' ' + fmtTime(wg.failopen_at * 1000) : ''), text: (foText(wg) ? 'Причина: ' + foText(wg) + '. ' : '') + 'Сайты из списков идут напрямую. Агент проверяет туннель раз в 5 минут и включит его сам.', to: 't-' + ti }); }
  if (sv.adguard === false && sv.adguard_broken) n.push({ sev: 'crit', title: 'AdGuard Home не запускается', text: 'Она не запускается даже с --version. VWARD сам ставит официальную сборку AdGuard Home, или нажмите «Установить официальную сборку».', to: 'u-agh' });
  // An update stops the jobs for its minute: not news while it runs.
  const updating = ['VERIFIED', 'BACKING_UP', 'INSTALLING', 'VERIFYING', 'COMMIT_PREPARED', 'ROLLING_BACK'].includes(p.phase);
  if (!updating && (sv.crond === false || sv.supervisor === false)) n.push({ sev: 'crit', title: 'Задания по расписанию остановлены', text: 'расписание заданий не работает', to: 'd-cron' });
  const total = num(stg.total_kb), free = num(stg.free_kb);
  if (total && free != null && lowDisk(total, free)) n.push({ sev: 'warn', title: 'Мало места в хранилище', text: 'свободно ' + fmtKB(free), to: 'system' });
  if (['FAILED', 'RECOVERY_REQUIRED'].includes(p.phase)) n.push({ sev: 'crit', title: 'Обновление требует внимания', text: phaseText(p.phase), to: 'u-vward' });
  if (S.update && S.update.pending && S.update.pending.present && S.update.pending.feed !== 'other') n.push({ sev: 'news', icon: 'save', title: 'Вышла новая версия VWARD', text: verHuman(S.update.pending.version, S.update.pending.sequence) + ' - нажмите, чтобы посмотреть и установить', to: 'u-vward' });
  const wc = ((S.wifi && S.wifi.clients) || []).filter(c => c.health === 'WARNING').length;
  if (wc) n.push({ sev: 'warn', title: 'Wi-Fi: ' + wc + ' ' + plural(wc, 'клиент требует', 'клиента требуют', 'клиентов требуют') + ' внимания', text: 'частые переходы между 2.4 и 5 ГГц', to: 'wifi' });
  const offComps = ((S.config && S.config.components) || []).filter(x => x.enabled === false && x.off_with !== 'install');
  if (offComps.length) n.push({ sev: 'warn', title: 'Выключено компонентов: ' + offComps.length, text: offComps.map(x => compName(x.id)).join(', '), to: 'utils' });
  if (S.config && S.config.wan_guard && S.config.wan_guard.enabled === false) n.push({ sev: 'warn', title: 'Восстановление интернета выключено', text: 'при сбое интернет не восстановится автоматически', to: 'wan' });
  if (S.config && S.config.tunnel_guard && S.config.tunnel_guard.enabled === false) n.push({ sev: 'warn', title: 'Агент VPN выключен', text: 'при падении туннеля сайты из списков VPN будут недоступны', to: 'vpn' });
  if (S.ads && S.ads.paused) n.push({ sev: 'warn', title: 'Блокировка рекламы на паузе', text: 'реклама не блокируется', to: 'ads' });
  if (awgLost().length) n.push({ sev: 'warn', title: 'Туннели не подключатся', text: awgLost().map(x => x.description || x.name).join(', ') + ': загрузите их файлы - VWARD поднимет их в модуле', to: 'vpn' });
  return n;
}
// Tunnels that share one address inside the tunnel: [{ addr, names }].
function tunDupAddresses(tunnels) {
  const by = {};
  (tunnels || []).forEach(t => { const a = String(t.address || '').split('/')[0].trim(); if (/^\d+\.\d+\.\d+\.\d+$/.test(a)) (by[a] = by[a] || []).push(t.name); });
  return Object.keys(by).filter(a => by[a].length > 1).map(a => ({ addr: a, names: by[a] }));
}
function plural(n, one, few, many) { const a = n % 10, b = n % 100; return a === 1 && b !== 11 ? one : a >= 2 && a <= 4 && (b < 12 || b > 14) ? few : many; }
function phaseText(p) { return ({ IDLE: 'Ожидание', CHECKING: 'Проверка', AVAILABLE: 'Доступно обновление', VERIFIED: 'Проверено', BACKING_UP: 'Резервная копия', INSTALLING: 'Установка', VERIFYING: 'Проверка установки', COMMIT_PREPARED: 'Завершение', COMMITTED: 'Установлено', ROLLING_BACK: 'Откат', FAILED: 'Ошибка', RECOVERY_REQUIRED: 'Нужно восстановление' })[p] || p || '—'; }

/* ---------- Карточки обзора ---------- */
const viaIs = (l, v) => l.via === v;
// VWARD's routes go direct right now: the default tunnel is off or not connected (Keenetic's «auto» routes skip it).
const vpnDirect = () => { const t = ((st().wg || {}).interfaces || []).find(x => x.name === prof().tunnel_interface); return !!st().wg && (!t || !isTrue(t.connected)); };
// Which Wi-Fi client needs attention and why, in one line; several - how many.
function wifiWarnText(wf) {
  const w = (wf.clients || []).filter(c => c.health === 'WARNING');
  if (w.length > 1) return w.length + ' требуют внимания';
  const c = w[0];
  return wifiName(c.mac) + ': ' + (c.recommendation === 'bind_2g' ? 'лучше 2,4 ГГц' : 'проверить');
}
// Which router answer each card is drawn from.
const CARD_KEY = { system: 'status', updates: 'status', wan: 'status', vpn: 'status', storage: 'status', lists: 'lists', routes: 'route', wifi: 'wifi', ads: 'ads' };
// Little space: under 256 MB, or under a tenth and under 1 GB (a tenth of a big drive is plenty).
const lowDisk = (total, free) => free < 262144 || (free / total < 0.1 && free < 1048576);
// The version for people (owner 01.11.2026, ROADMAP §3): «0.2.0 RC2 #36.1.261111» - the stage, the
// release N.P and the build date (the first digits of the signed build number). Inside, the SemVer
// (VERSION), its comparison and the build number stay as they are; this is only how it is shown.
function verHuman(v, seq) {
  const m = /^(\d+\.\d+\.\d+)(?:-(rc|rp)\.(\d+))?(?:\.fix\.(\d+)(?:\.(\d+))?)?$/.exec(String(v || ''));
  if (!m) return v || '';
  const d = /^20(\d{6})\d*$/.exec(String(seq || ''));
  return m[1] + (m[2] ? ' ' + m[2].toUpperCase() + m[3] : '') + (m[4] ? ' #' + m[4] + '.' + (m[5] || '0') + (d ? '.' + d[1] : '') : '');
}
// ---- VWARD's parts (fix.38): one registry, one name, one state, one switch ----
// Where a part's own page is (a component's is «c-ID»).
const PART_PAGE = { agh: 'd-agh', awg: 'd-awg', vless: 'd-vless', dnsmasq: 'd-dnsmasq', singbox: 'd-singbox', doh: 'd-doh', dnscap: 'd-dnscap', sentinel: 'd-stability', 'routing-core': 'c-route-engine' };
// Parts that run by the clock (their last run's result), not all the time.
const PART_RUNS = ['route-reconciler', 'tunnel-guard', 'wan-guard'];
const partsList = () => (st().parts && st().parts.list) || [];
const partOf = id => partsList().find(p => p.id === id);
const partPage = p => p.kind === 'component' ? 'c-' + p.id : PART_PAGE[p.id] || null;
// The VPN programs work when their tunnels are connected (their page's own facts, when loaded).
function vlessFacts() {
  const known = !!S.status && !S.cached.status, v = (S.awg && S.awg.vless) || {}, vt = v.tunnels || [], ifs = (st().wg || {}).interfaces || [];
  const up = n => { const i = ifs.find(x => x.name === n); return !!(i && isTrue(i.connected)); };
  return { known: known && !!S.awg, installed: !!v.installed || vt.length > 0, enabled: !modOff('vless'), selected: vt.length > 0, running: vt.some(t => t.running), vpn: true,
    works: vt.length ? vt.every(t => t.running && up(t.name)) : null };
}
function awgFacts() {
  const known = !!S.status && !S.cached.status, w = S.awg || {}, wt = w.tunnels || [];
  return { known: known && !!S.awg, installed: !!w.installed, enabled: !modOff('awg'), selected: wt.length > 0, running: wt.length > 0 && wt.every(t => t.running), vpn: true,
    works: wt.length ? !awgLost().length && wt.every(t => t.running && t.handshake != null) : null };
}
// partPill PART: [class, text, why] - the programs from their own facts, the rest from the router's.
function partPill(p) {
  const mode = dnsMode();
  if (p.id === 'agh') return aghState();
  if (p.id === 'vless' && S.awg) return compStatus(vlessFacts());
  if (p.id === 'awg' && S.awg) return compStatus(awgFacts());
  if (p.id === 'dnsmasq') { const f = Object.assign(pkgFacts('dnsmasq-full'), { selected: mode === 'dnsmasq' }); if (f.selected) f.works = f.running ? null : false; return compStatus(f); }
  if (p.id === 'singbox') return compStatus(Object.assign(pkgFacts('sing-box-go'), { selected: false }));
  if (p.enabled === false) return p.kind === 'extra' ? ['off', 'Выключено'] : CS.off;
  // The two agents with a switch of their own besides the component's: off when that one is.
  if ((p.id === 'tunnel-guard' && (cfg().tunnel_guard || {}).enabled === false) || (p.id === 'wan-guard' && (cfg().wan_guard || {}).enabled === false)) return CS.off;
  if (p.installed === false) return CS.none;
  if (p.running === true) return CS.works;
  // A job that runs by the clock ended its last run with an error; a service that should run does not.
  if (p.running === false) return PART_RUNS.includes(p.id) ? ['warn', 'С ошибкой', 'последний запуск закончился ошибкой'] :
    p.kind === 'component' ? ['crit', 'Не работает'] : ['off', 'Не запущен'];
  return p.kind === 'extra' ? ['ok', 'Включено'] : ['ok', 'Включён'];
}
// partRow PART: a switch where the part has one (state in the line under its name), else its state.
function partRow(p) {
  const pill = partPill(p), page = partPage(p), why = p.why || pill[2] || '';
  if (p.switch === 'component' || p.switch === 'extra') {
    const attr = p.switch === 'component' ? 'data-comp="' + p.id + '"' : 'data-extra="' + p.id + '"';
    // One source for the line and the switch: the router's answer (plus the agent's own switch, which
    // the component's switch turns on with it).
    const own = p.id === 'tunnel-guard' ? (cfg().tunnel_guard || {}).enabled !== false : p.id === 'wan-guard' ? (cfg().wan_guard || {}).enabled !== false : true;
    const on = p.enabled !== false && own;
    const go = page ? '<button class="icon-btn part-go" type="button" data-go="' + page + '" aria-label="' + esc(p.title) + ': подробнее">' + ico('chevron') + '</button>' : '';
    // The state always in sight under the name; what the part does too when the line has room.
    const line = pill[1] + ' · ' + (why || p.desc), sub = line.length <= HINT_MAX ? line : pill[1] + (why && (pill[1] + ' · ' + why).length <= HINT_MAX ? ' · ' + why : '');
    return ctrlRow(p.title, '<span class="part-ctl">' + sw(attr, on, p.title, !cfgOk()) + go + '</span>', sub);
  }
  return kv([[p.title, pill[1], pill[0], page, '', why || p.desc]]).replace(/^<dl class="kv">|<\/dl>$/g, '');
}
function cardData(id) {
  const s = st(), p = plat(), w = s.wan || {}, wg = s.wg || {}, sv = s.services || {}, g = s.storage || {}, r = S.route || {}, wf = S.wifi || {}, a = S.ads || {};
  const tunnels = wg.interfaces || [], up = tunnels.filter(t => isTrue(t.connected)).length;
  const comps = Object.keys(p.components || {}).length;
  const warnWifi = (wf.clients || []).filter(c => c.health === 'WARNING').length;
  switch (id) {
    // «0.2.0 RC2» on the card, «#36.1.261111» under it (owner 01.11.2026).
    case 'system': { const hv = verHuman(p.version, p.last_sequence), vm = /^(.*?) (#.*)$/.exec(hv); return { icon: 'platform', title: 'Система', to: 'system', value: vm ? vm[1] : hv || '—',
      // One short line on a phone: the components are on the System page.
      sub: vm ? vm[2] : comps ? comps + ' ' + plural(comps, 'компонент', 'компонента', 'компонентов') : 'версия VWARD', pill: p.version ? ['ok', 'Работает'] : ['', '—'] }; }
    case 'updates': return { icon: 'refresh', title: 'Обновления', to: 'u-vward', value: ['IDLE', 'COMMITTED', undefined, ''].includes(p.phase) ? 'Новых нет' : phaseText(p.phase), sub: num(p.feed_ok_at) != null ? 'проверено ' + fmtStamp(p.feed_ok_at) : 'канал ' + (p.channel || '—'), pill: ['FAILED', 'RECOVERY_REQUIRED'].includes(p.phase) ? ['crit', 'Ошибка'] : ['', ''] };
    case 'wan': return { icon: 'globe', title: 'Интернет', to: 'wan', value: w.internet ? 'В сети' : w.internet === false ? 'Нет связи' : s.wan ? 'Роутер отвечает медленно' : '—', sub: w.speed ? 'порт ' + fmtSpeed(w.speed) : w.address || 'адрес не получен', pill: w.internet ? ['ok', 'Работает'] : w.internet === false ? ['crit', 'Не работает'] : s.wan ? ['warn', 'Нет ответа'] : ['', '—'] };
    // Only switched-on tunnels count: one the owner switched off is not a fault (owner 2026-10-12).
    case 'vpn': {
      const on = tunnels.filter(t => !tunOff(t)), off = tunnels.length - on.length, upOn = on.filter(t => isTrue(t.connected)).length, gOff = tunnels.find(tunGuardOff);
      if (wg.interfaces_unknown) return { icon: 'shield', title: 'VPN', to: 'vpn', value: '—', sub: 'Keenetic не ответил', pill: ['', 'Нет данных'] };
      return { icon: 'shield', title: 'VPN', to: 'vpn', value: !tunnels.length ? '—' : !on.length ? 'Выключен' : upOn + ' из ' + on.length,
        // One short line (three lines a card, owner 2026-10-12): what is wrong first, then the switched off.
        sub: !tunnels.length ? 'туннелей нет' : !on.length ? 'все туннели выключены' : gOff ? 'выключен агентом: ' + tunLabel(gOff.name)
          : upOn < on.length ? 'не на связи: ' + on.filter(t => !isTrue(t.connected)).map(t => tunLabel(t.name)).join(', ')
          : !on.some(t => t.name === prof().tunnel_interface) ? 'списки идут напрямую' : off ? 'ещё ' + off + ' ' + plural(off, 'выключен', 'выключены', 'выключены') + ' вами' : 'трафик через VPN',
        pill: !tunnels.length ? ['', 'Нет туннелей'] : !on.length ? ['', 'Выключен'] : upOn === on.length ? ['ok', 'Работает'] : ['warn', 'Внимание'] };
    }
    case 'lists': {
      const ls = (S.lists && S.lists.lists) || [], vpn = ls.filter(l => viaIs(l, 'vpn')).length, around = ls.filter(l => viaIs(l, 'bypass')).length, auto = ls.filter(l => l.auto && viaIs(l, 'vpn')).length;
      return { icon: 'list', title: 'Доменные списки', to: 'lists', value: S.lists ? vpn + ' через VPN' : '—', sub: S.lists ? (vpn && vpnDirect() ? 'сейчас напрямую' : around + ' в обход') : 'списки Keenetic', pill: !S.lists ? ['', '—'] : vpn && vpnDirect() ? ['warn', 'Напрямую'] : auto ? ['warn', 'Переведено авто: ' + auto] : ['info', ls.length + ' ' + plural(ls.length, 'список', 'списка', 'списков')] };
    }
    case 'routes': return { icon: 'route', title: 'Маршруты', to: 'routes', value: fmtInt(r.ip && r.ip.managed_routes) + ' ' + plural(num(r.ip && r.ip.managed_routes) || 0, 'подсеть', 'подсети', 'подсетей'), sub: vpnDirect() ? 'сейчас напрямую' : fmtInt(r.ip && r.ip.active_count) + '\u00a0' + plural(num(r.ip && r.ip.active_count) || 0, 'IP\u2011категория', 'IP\u2011категории', 'IP\u2011категорий'), pill: !S.route ? ['', '—'] : vpnDirect() ? ['warn', 'Напрямую'] : ['ok', 'Работает'] };
    case 'wifi': return { icon: 'wifi', title: 'Wi-Fi клиенты', to: 'wifi', value: S.wifi && !wf.enabled ? '—' : fmtInt(wf.count) + ' ' + plural(num(wf.count) || 0, 'клиент', 'клиента', 'клиентов'), sub: wf.enabled ? (warnWifi ? wifiWarnText(wf) : 'без замечаний') : 'сбор данных выключен', pill: !S.wifi ? ['', '—'] : warnWifi ? ['warn', 'Внимание'] : wf.enabled ? ['ok', 'Работает'] : ['', 'Выключен'] };
    // What AdGuard Home blocked today (the domains VWARD itself blocked are a handful and read as
    // «almost nothing blocked»: they are on the Ads page).
    case 'ads': { const q = S.adsstats;
      // The component switched off (the scheduler leaves at its gate): «выключено», not «0 заблокировано».
      if (adsOff()) return { icon: 'block', title: 'Реклама', to: 'ads', value: 'выключено', sub: 'компонент выключен', pill: ['', 'Выключен'] };
      return { icon: 'block', title: 'Реклама', to: 'ads', value: q && q.ok ? fmtInt(q.blocked) : '—',
      // «заблокировано за сутки» was cut on a phone (fix.34): a shorter line.
      sub: q && q.ok ? 'блокировок за сутки' : q ? 'нет статистики' : 'загрузка…', pill: !S.ads ? ['', '—'] : a.paused ? ['warn', 'Пауза'] : ((a.dns_guard || {}).chain_state === 'out') ? ['warn', 'Не фильтруется'] : ['ok', 'Работает'] }; }
    case 'storage': { const t = num(g.total_kb), f = num(g.free_kb), used = t ? Math.round((t - f) / t * 100) : null; return { icon: 'storage', title: 'Хранилище', to: 'system', value: t ? fmtKB(t - f) : '—', sub: t ? 'занято из ' + fmtKB(t) : 'нет данных', pill: used == null ? ['', '—'] : lowDisk(t, f) ? ['warn', used + ' %'] : ['ok', used + ' %'], meter: used }; }
  }
  return null;
}

// The recovery log in words: newest first.
const WAN_ACTIONS = { DHCP_RENEW: 'Новый адрес у провайдера', MANUAL_DHCP_RENEW: 'Новый адрес у провайдера, по кнопке', WAN_BOUNCE: 'Переподключение', MANUAL_WAN_BOUNCE: 'Переподключение, по кнопке',
  WAN_BOUNCE_RECOVERY: 'Интернет включён после прерванного переподключения', MANUAL_BOUNCE_RECOVERY: 'Интернет включён после прерванного переподключения', WAN_BOUNCE_RECOVERY_FAILED: 'Не удалось включить интернет после прерывания', MANUAL_WAN_BOUNCE_INTERRUPTED: 'Переподключение прервано, интернет включён' };
function wanHistory(text) {
  return String(text).split('\n').map(l => {
    const m = /^(\d{4}-\d\d-\d\d) (\d\d:\d\d)\S* action=([A-Z_]+)(.*)$/.exec(l.trim());
    if (!m || !WAN_ACTIONS[m[3]]) return null;
    const rcs = (m[4].match(/\b(?:rc|up_rc|down_rc)=(\d+)/g) || []).map(x => x.split('=')[1]);
    return { when: m[1].slice(8, 10) + '.' + m[1].slice(5, 7) + ' ' + m[2], what: WAN_ACTIONS[m[3]], ok: !/FAILED$/.test(m[3]) && rcs.every(x => x === '0') };
  }).filter(Boolean).reverse().slice(0, 30);
}

// How a Keenetic domain list goes: through which tunnel, around VPN or nowhere.
// fix.38.1 (owner 12.11.2026): the route in technical words - «VPN», «провайдер», «Smart DNS», «авто».
function listRoute(l) {
  const tuns = (st().wg && st().wg.interfaces) || [], tun = tuns.length > 1 && l.route && tuns.some(t => t.name === l.route) ? 'VPN (' + tunLabel(l.route) + ')' : 'VPN';
  return l.dns_mode ? 'Smart DNS' : l.managed && l.watch ? 'авто, сейчас ' + (viaIs(l, 'vpn') ? tun : 'провайдер')
    : viaIs(l, 'vpn') ? tun : l.route && !['vpn', 'bypass', 'none'].includes(l.via) ? l.route : viaIs(l, 'bypass') ? 'провайдер' : 'не задан';
}
function listPath(l) {
  const tuns = (st().wg && st().wg.interfaces) || [];
  return tuns.length > 1 && l.route && tuns.some(t => t.name === l.route) ? 'через ' + tunLabel(l.route) : viaIs(l, 'vpn') ? 'через VPN' : viaIs(l, 'bypass') ? 'в обход VPN' + (l.doh.length ? ', Smart DNS: ' + l.doh.join(', ') : '') : viaIs(l, 'none') ? 'без маршрута' : 'через ' + l.route;
}
let listWant = '';
// r-lists: «Авто» - VWARD's policy decides (watch); otherwise the route the list has now.
// Four explicit paths; DNS requires the configured responding Smart DNS server.
const LIST_MODES = [['auto', 'Авто'], ['vpn', 'VPN'], ['dns', 'DNS'], ['bypass', 'Провайдер']];
const listMode = l => l.dns_mode ? 'dns' : l.watch ? 'auto' : viaIs(l, 'vpn') ? 'vpn' : viaIs(l, 'bypass') ? 'bypass' : '';
function listDnsWhy(l) {
  const d = S.lists || {}, state = d.smartdns_state;
  if (state !== 'ready') return state === 'off' ? 'Smart DNS выключен' : state === 'not_configured' ? 'Smart DNS-сервер не настроен' : state === 'dead' ? 'Smart DNS-сервер не отвечает' : 'Ответ Smart DNS-сервера не подтверждён';
  const rows = (d.smartdns_sources && d.smartdns_sources.keenetic) || [], used = num(d.doh_used) || 0, limit = num(d.doh_limit) || 8;
  const need = (l.domains || []).filter(x => rows.indexOf(x) < 0).length;
  return l.count > limit || used + need > limit ? 'Недоступно: лимит ' + used + ' из ' + limit + ', списку нужно ещё ' + need : '';
}
function listModes(l) { const why = listDnsWhy(l); return LIST_MODES.filter(o => !(o[0] === 'dns' && (S.lists || {}).smartdns_state === 'off' && !l.dns_mode)).map(o => [o[0], o[1], !!LISTBULK.busy || o[0] === 'dns' && !!why]); }
function listAllModes(ls) { const d = S.lists || {}, rows = (d.smartdns_sources && d.smartdns_sources.keenetic) || [], needed = new Set(); ls.forEach(l => (l.domains || []).forEach(x => { if (rows.indexOf(x) < 0) needed.add(x); })); const why = ls.some(l => !!listDnsWhy(l)) || (num(d.doh_used) || 0) + needed.size > (num(d.doh_limit) || 8); return LIST_MODES.filter(o => !(o[0] === 'dns' && (S.lists || {}).smartdns_state === 'off')).map(o => [o[0], o[1], !!LISTBULK.busy || o[0] === 'dns' && why]); }
const LISTPICK = new Set(), LISTBULK = { busy: '' };
function listDelText(ls) {
  const n = ls.reduce((a, l) => a + (l.count || 0), 0), vpn = ls.filter(l => viaIs(l, 'vpn'));
  return 'Удалить ' + ls.length + ' ' + plural(ls.length, 'список', 'списка', 'списков') + ' (' + ls.map(l => l.description || l.name).join(', ') + ')? ' +
    fmtInt(n) + ' ' + plural(n, 'домен', 'домена', 'доменов') + ' перестанут подбираться' + (vpn.length ? '; ' + vpn.length + (vpn.length === 1 ? ' список сейчас идёт через VPN и пойдёт' : ' из них сейчас идут через VPN и пойдут') + ' напрямую' : '') +
    '. Перед удалением каждого списка сохраняется копия настроек VWARD; вернуть список одной кнопкой нельзя.';
}
// One list after another through the same writer; each is its own transaction. What was
// done and what was refused is said at the end - nothing is undone behind the owner's back.
async function listBulk(fields, names, what) {
  const done = [], bad = [];
  for (const g of names) {
    LISTBULK.busy = what + ': ' + (done.length + bad.length + 1) + ' из ' + names.length; render();
    const x = await (fields.op === 'list-mode' ? listModeWrite(g, fields.value) : apiPost('config', Object.assign({ target: g }, fields))).catch(e => ({ ok: false, error: e.message }));
    (x && x.ok ? done : bad).push(x && x.ok ? g : g + ' - ' + errText(x));
  }
  LISTBULK.busy = '';
  actionResult = { id: 'lists', text: what + ': готово ' + done.length + ' из ' + names.length + (bad.length ? '. Не выполнено: ' + bad.join('; ') : '') };
  await Promise.all(['config', 'lists'].map(k => load(k, true))); render();
}
async function listModeWrite(group, mode) {
  const job = await bgJob({ op: 'list-mode', id: group, tunnel: mode });
  return job.done ? job.x : { ok: false, error: 'operation_still_running' };
}
async function listModeSet(group, mode) {
  if (LISTBULK.busy) return;
  LISTBULK.busy = 'Меняем путь списка…'; render();
  let x;
  try { x = await listModeWrite(group, mode); }
  catch (e) { x = { ok: false, error: e.message }; }
  LISTBULK.busy = '';
  actionResult = { id: 'lists', text: x.ok ? (x.result === 'unchanged' ? 'Уже сохранено' : 'Маршрут списка изменён') : 'Не сохранено: ' + errText(x) };
  await Promise.all(['config', 'lists'].map(k => load(k, true))); render();
}
// One Keenetic domain list: where it goes, its domains and exclusions, all editable here.
// Where routing data comes from (vward-route-hints-update.sh, vward-policy-sync.sh).
const ROUTE_SOURCES = [
  { id: 'itdog', title: 'itdog - списки доменов', url: 'https://github.com/itdoginfo/allow-domains', unit: 'доменов', what: 'Заблокированные в России домены по сервисам и категориям', why: 'Подсказки автоподбору: такой домен при сбое напрямую сразу уходит в VPN' },
  { id: 'v2fly', title: 'v2fly domain-list-community', url: 'https://github.com/v2fly/domain-list-community', unit: 'доменов', what: 'Справочник «домен - сервис»', why: 'Подсказки автоподбору и выбор IP-категорий' },
  { id: 'refilter', title: 'Re:filter community', url: 'https://github.com/1andrevich/Re-filter-lists', unit: 'доменов', what: 'Сервисы, которые сами не пускают пользователей из России', why: 'Подсказки автоподбору' },
  { id: 'antifilter', title: 'antifilter community', url: 'https://community.antifilter.download/', unit: 'доменов', what: 'Заблокированные домены, собранные сообществом antifilter', why: 'Подсказки автоподбору' },
  { id: 'itdog-ip', title: 'itdog - подсети', url: 'https://github.com/itdoginfo/allow-domains/tree/main/Subnets', unit: 'подсетей', what: 'Подсети сервисов', why: 'Маршруты IP-категорий' },
  { id: 'loyalsoldier', title: 'Loyalsoldier geoip', url: 'https://github.com/Loyalsoldier/geoip', unit: 'подсетей', what: 'Диапазоны адресов сервисов', why: 'Маршруты IP-категорий' },
  { id: 'official', title: 'Официальные подсети сервисов', url: 'https://core.telegram.org/resources/cidr.txt', unit: 'подсетей', what: 'Подсети, которые публикует сам сервис (Telegram)', why: 'Маршруты IP-категорий - точнее любых сборок' }
];
function routeSourcesRow(r) {
  const got = r.sources || [], bad = got.filter(x => !x.ok).length;
  // The number on the right, the rest under the name: a long value wrapped on a phone.
  return ['Источники', String(ROUTE_SOURCES.length), bad ? 'warn' : '', 'd-rsources', '', bad ? bad + ' ' + plural(bad, 'не скачался', 'не скачались', 'не скачались') : !got.length ? 'обновление в 00:10' : 'все обновлены'];
}
// Addresses Keenetic learned for one list, by domain (list-addrs).
function addrPage(name) {
  const a = S.laddr, fresh = a && a.name === name, l = ((S.lists && S.lists.lists) || []).find(x => x.name === name);
  if (!fresh && !(a && a.error)) return panel(l ? l.description || l.name : 'Список', empty('Загрузка…'));
  if (!a.ok) return panel(l ? l.description || l.name : 'Список', empty(errText(a)));
  const got = a.entries.filter(e => e.v4.length || e.v6.length), none = a.entries.length - got.length;
  const rows = got.map(e => '<li class="row" data-d="' + esc(e.fqdn) + '"><div class="row-main"><b>' + dom(e.fqdn) + '</b><small class="mono">' +
    esc(e.v4.concat(e.v6).join(', ')) + '</small></div></li>').join('');
  return panel(l ? l.description || l.name : name, kv([['IPv4', fmtInt(a.v4)], ['IPv6', fmtInt(a.v6)]])) +
    panel('По доменам', (got.length > 8 ? '<label class="search-field list-filter">' + ico('search') + '<input class="input" type="search" data-list-filter placeholder="Найти домен или адрес" aria-label="Найти домен или адрес" autocomplete="off"></label>' : '') +
      (got.length ? '<ul class="rows" data-list-rows>' + rows + '</ul>' : empty('Адресов пока нет: устройства ещё не открывали эти домены')),
      { desc: none ? 'Доменов без адресов: ' + none + ' - их ещё не открывали.' : 'Адреса обновляются, когда устройства открывают домены.' });
}
// VWARD's own list («Мои домены») is only cleared, never deleted; AdaptiveAuto has its own page.
const listOwn = l => l.name === (cfgRoute().group || prof().policy_group);
// The confirmation for clearing or deleting a list, with the number of its domains; a backup first.
function listConfirm(l) {
  if (!confirm || confirm.name !== l.name || !['list-clear', 'list-del'].includes(confirm.id)) return '';
  const n = fmtInt(l.count) + ' ' + plural(l.count, 'домен', 'домена', 'доменов'), t = '«' + (l.description || l.name) + '»';
  // «Мои домены» live in a Keenetic group with its own domains: clearing takes them all (fix.34).
  if (confirm.id === 'list-clear' && listOwn(l)) return confirmBox('list-clear', 'Будет очищена вся группа ' + t + ', ' + n + ': не только ваши домены, но и все домены этой группы. Группа и её маршрут останутся. Сначала сохранится копия настроек.', 'Очистить', true);
  return confirm.id === 'list-clear' ? confirmBox('list-clear', 'Очистить список ' + t + ' (' + n + ')? Список и его маршрут останутся. Сначала сохранится копия настроек.', 'Очистить', true)
    : confirmBox('list-del', 'Удалить список ' + t + ' (' + n + ')? Из Keenetic уйдут список, его маршрут и исключения. Сначала сохранится копия настроек.' + (l.vward === false ? ' Список создан не VWARD.' : ''), 'Удалить', true);
}
// «Очистить» for VWARD's own list on «Мои домены»; deleting it is not offered (listOwn).
function myListClear(n) {
  const g = cfgRoute().group || prof().policy_group, l = ((S.lists && S.lists.lists) || []).find(x => x.name === g);
  if (!g || !n) return '';
  return (l ? listConfirm(l) : '') + (confirm && confirm.name === g ? '' : '<div class="panel-actions apart">' + btn('ask', 'broom', 'Очистить список', 'warn', ' data-confirm="list-clear" data-name="' + esc(g) + '"' + (cfgOk() && l ? '' : ' disabled')) + '</div>');
}
// A fitting example for an exclusion: a subdomain of the list's own first domain.
const exampleDomain = inc => (inc && inc[0] ? String(inc[0]).replace(/^\*\./, '') : 'example.com');
// fix.38.1 (owner 12.11.2026): one slider «Авто | VPN | Провайдер» on every list's page instead of
// «В обход VPN» and «Следить». A list made outside VWARD is taken under management first (the
// owner confirms), then gets the chosen way. A catalog service's list goes with its service.
function listWayRows(l, tuns, title) {
  const x = svcOf(l.name);
  if (x) return ctrlRow('Маршрут', '<button class="btn small" type="button" data-go="s-' + esc(x.id) + '">Сервис</button>', 'задаётся на странице сервиса');
  const mode = listMode(l), hint = mode === 'auto' ? 'по проверке доступности, сейчас ' + (viaIs(l, 'vpn') ? 'VPN' : 'провайдер')
    : mode === 'vpn' || mode === 'bypass' ? 'фиксированный: ' + listRoute(l) : mode === 'dns' ? 'Smart DNS' : 'сейчас: ' + listRoute(l);
  let rows = ctrlRow('Маршрут', choiceSlider('list-mode:' + l.name, listModes(l), mode, 'Маршрут списка ' + title), hint);
  // Several tunnels: which one carries a list that goes through VPN.
  if (tuns.length > 1 && mode === 'vpn') rows += ctrlRow('Туннель', listTunPick(l, tuns), 'интерфейс маршрута списка');
  return rows;
}
function listTunPick(l, tuns) {
  const cur = tuns.some(t => t.name === l.route) ? l.route : '', label = 'Туннель списка «' + (l.description || l.name) + '»';
  if (tuns.length <= 4) return choiceSlider('list-tun:' + l.name, tuns.map(t => [t.name, tunLabel(t.name), !!LISTBULK.busy]), cur, label);
  return sel('data-list-via="' + esc(l.name) + '"' + (cfgOk() ? '' : ' disabled'), label, (cur ? [] : [['', l.route ? 'через ' + l.route : 'без маршрута', true]]).concat(tuns.map(t => [t.name, tunLabel(t.name)])), cur);
}
function listAdoptBox(l) {
  if (!confirm || confirm.id !== 'list-adopt' || confirm.name !== l.name) return '';
  const m = LIST_MODES.find(o => o[0] === confirm.then);
  return confirmBox('list-adopt', 'Список «' + (l.description || l.name) + '» не под управлением VWARD. Взять под управление и установить маршрут' + (m ? ' «' + m[1] + '»' : '') + '? Домены не изменятся.', 'Взять');
}
// VWARD's own list (was «Мои домены»): the domains VWARD and the owner send through VPN.
// Always through VPN; added and removed through route-domain, a pin keeps a domain in VPN.
function ownListPage(l) {
  const r = cfgRoute(), list = myDomains(), forced = myForced(), title = l.description || l.name;
  const fixed = choiceSlider('list-own', [['auto', 'Авто', true], ['vpn', 'VPN'], ['bypass', 'Провайдер', true]], 'vpn', 'Маршрут списка ' + title);
  return cfgNote() +
    panel(title, '<dl class="kv">' + ctrlRow('Маршрут', fixed, 'фиксированный: ' + listRoute(l) + '; список VWARD - в него добавляют домены автоподбор и «Проверка адреса»') + (policyGroupRow() || '') + '</dl>' +
      kv([['IP-адреса', l.addresses != null ? fmtInt(l.addresses) : '—', '', 'ip-' + l.name, '', 'адреса, которые Keenetic узнал для доменов списка']])) +
    panel('Домены', addForm('route-domain', 'например, claude.ai') +
      (S.config && !r.router_available ? empty('Не удалось прочитать конфигурацию роутера') : myRows(list, forced) || empty('Список пуст')) + myListClear((r.domains || []).length),
      { desc: 'Правило действует на домен и его поддомены; маршрут - ' + (prof().tunnel_interface ? tunLabel(prof().tunnel_interface) : 'VPN') + '. Булавка: автоподбор и сверка маршрутов не снимают домен с VPN.' });
}
function listPage(name) {
  const l = ((S.lists && S.lists.lists) || []).find(x => x.name === name), d = S.listd, ok = cfgOk();
  const tuns = (st().wg && st().wg.interfaces) || [];
  if (!l) return loadError(['lists']) + panel('Список', empty(S.lists ? 'Такого списка нет в Keenetic' : 'Загрузка…'));
  // fix.38.1 (owner 12.11.2026): every list opens its own page, VWARD's own list too.
  if (listOwn(l)) return ownListPage(l);
  if ((!d || d.name !== name) && listWant !== name) { listWant = name; load('listd', true).then(render); }
  const fresh = d && d.name === name, title = l.description || l.name, can = ok && (viaIs(l, 'vpn') || viaIs(l, 'bypass'));
  const editOk = ok && !l.dns_mode;
  const rm = (act, v, label) => '<button class="icon-btn" type="button" data-list-dom="' + act + '" data-dom="' + esc(v) + '" aria-label="' + esc(label) + '" title="' + esc(label) + '"' + (editOk ? '' : ' disabled') + '>' + ico('close') + '</button>';
  const addF = (kind, ph, label) => inputBar({ form: 'list-add', attrs: ' data-kind="' + kind + '"', label: label, name: 'domain', placeholder: ph, aria: 'Домен', off: !editOk, icon: 'plus', btn: 'Добавить' });
  const inc = fresh ? d.include : [], exc = fresh ? d.exclude : [];
  return cfgNote() + (fresh || !d || !d.error ? '' : '<p class="field-warn">' + esc(errText(d)) + '</p>') +
    panel(title, '<dl class="kv">' +
      listWayRows(l, tuns, title) + '</dl>' + listAdoptBox(l) + (LISTBULK.busy ? '<p class="panel-desc">' + esc(LISTBULK.busy) + '</p>' : '') + resultBox('lists') +
      kv([['IP-адреса', l.addresses != null ? fmtInt(l.addresses) : '—', '', 'ip-' + l.name, '', 'адреса, которые Keenetic узнал для доменов списка']]) +
      (l.smartdns_conflict ? '<p class="field-warn">В списке есть домены Smart DNS: их общий адрес уйдёт в VPN, и Smart DNS перестанет работать для всех сервисов. Переведите список в обход VPN или уберите эти домены.</p>' : '') +
      (l.auto && viaIs(l, 'vpn') ? '<p class="field-warn">Переведён на VPN автоматически ' + esc(l.auto.at) + ': не открылся ' + esc(l.auto.host) + '</p>' : '')) +
    panel('Домены', (l.dns_mode ? '<p class="panel-desc">Чтобы изменить домены или удалить список, сначала выберите другой путь.</p>' : '') + addF('add', 'example.com', 'Добавить домен в список') +
      (fresh ? '<p class="panel-desc">' + fmtInt(inc.length) + ' ' + plural(inc.length, 'домен', 'домена', 'доменов') + '</p>' : '') + (inc.length > 8 ? '<label class="search-field list-filter">' + ico('search') + '<input class="input" type="search" data-list-filter placeholder="Найти в списке" aria-label="Найти домен в списке" autocomplete="off"></label>' : '') +
      (!fresh ? empty('Загрузка…') : inc.length ? '<ul class="rows" data-list-rows>' + inc.map(v => '<li class="row dom-row" data-d="' + esc(v) + '"><div class="row-main"><b>' + dom(v) + '</b></div><span class="row-acts">' + rm('remove', v, 'Убрать ' + v + ' из списка') + '</span></li>').join('') + '</ul>' : empty('В списке нет доменов')),
      { desc: fmtInt(inc.length || l.count) + ' ' + plural(inc.length || l.count, 'домен', 'домена', 'доменов') + '. Домен действует вместе с поддоменами. Изменения сразу сохраняются в Keenetic.' }) +
    // «Управление» of a list (owner 02.11): the list's actions in their own section, as on AdGuard Home.
    (l.name === 'AdaptiveAuto' ? '' : panel('Управление', listConfirm(l) || '<div class="panel-actions even">' +
        btn('ask', 'broom', 'Очистить список', '', ' data-confirm="list-clear" data-name="' + esc(l.name) + '"' + (editOk && l.count ? '' : ' disabled')) +
        (listOwn(l) ? '' : btn('ask', 'trash', 'Удалить список', 'danger', ' data-confirm="list-del" data-name="' + esc(l.name) + '"' + (editOk ? '' : ' disabled'))) + '</div>' +
        '',
      { desc: 'Очистить список - убрать все домены, список и маршрут останутся. Удалить список - убрать его из Keenetic полностью. Перед обоими сохраняется копия настроек.' })) +
    panel('Исключения', addF('exclude', 'sub.' + exampleDomain(inc), 'Добавить исключение') +
      (!fresh ? '' : exc.length ? '<ul class="rows">' + exc.map(v => '<li class="row"><div class="row-main"><b>' + dom(v) + '</b></div><span class="row-acts">' + rm('unexclude', v, 'Убрать исключение ' + v) + '</span></li>').join('') + '</ul>' : '<p class="panel-desc">Исключений нет</p>'),
      { desc: 'Поддомены, которые идут мимо этого списка.' });
}

// A card is marked only when something needs attention: «Норма» on every card said nothing.
const cardAlert = p => p && (p[0] === 'warn' || p[0] === 'crit') ? '<span class="pill card-alert ' + p[0] + '">' + ico('alert') + esc(p[1]) + '</span>' : '';

/* ---------- Разделы ---------- */
// AdGuard Home out of Keenetic's DNS chain: said on top, with why and what it means, so nobody
// guesses why ads come back (the internet itself works through the provider's DNS).
const CHAIN_WHY = { update: 'VWARD обновляет его', loop: 'он перезапускается по кругу', silent: 'он не отвечает', fast: 'он перестал отвечать',
  loop_upstream: 'его серверы DNS указывают обратно на роутер (петля)', silent_10min: 'он не отвечал 10 минут подряд', absent: 'на его порту никто не отвечает',
  released: 'он выключен в Панели' };
function chainNotice() {
  const g = (S.ads && S.ads.dns_guard) || {};
  if (g.chain_state !== 'out') return '';
  const since = num(g.chain_since), at = since ? ' с ' + new Date(since * 1000).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) : '';
  return '<p class="field-warn" data-go="d-agh" role="button" tabindex="0">AdGuard Home временно вне цепочки DNS' + at + ': ' + esc(CHAIN_WHY[g.chain_reason] || 'он недоступен') +
    '. Интернет работает через DNS провайдера, реклама сейчас не фильтруется. ' +
    (g.chain_reason === 'loop_upstream' ? 'Исправьте серверы DNS в AdGuard Home.' : 'VWARD вернёт его сам, как только он заработает.') + '</p>';
}
/* ---------- Аварийное отключение ---------- */
// «Отключить VWARD»: VWARD steps aside and the router works as a plain Keenetic, for the day
// VWARD itself misbehaves. Said on top of every page while it is off, with the way back.
const offState = () => (S.off && S.off.state) || 'on';
let offTimer = null;
function offPoll() {
  clearTimeout(offTimer);
  offTimer = setTimeout(() => load('off', true).then(() => {
    render();
    if (offState() === 'working') offPoll(); else Promise.all(DATA_FOR(current).map(k => load(k, true))).then(render, render);
  }, offPoll), 2000);
}
async function vwardPower(op) {
  try {
    const r = await apiPost('vward-off', op === 'off' ? { op: 'off', confirm: 'VWARD_OFF' } : { op: 'on' });
    if (!r.ok) throw new Error(errText(r));
    S.off = r; S.loadedAt.off = Date.now(); render(); offPoll();
    toast(op === 'off' ? 'VWARD отключается' : 'VWARD включается');
  } catch (e) { toast('Не получилось: ' + e.message); render(); }
}
function offNotice() {
  const o = S.off || {};
  if (o.state === 'working') return '<div class="off-banner" role="status">' + ico('refresh', 'spin') + '<div><b>' + (o.op === 'on' ? 'VWARD включается…' : 'VWARD отключается…') + '</b><span>Это может занять несколько минут.</span></div></div>';
  if (o.state !== 'off') return '';
  const since = num(o.since), at = since ? ' с ' + new Date(since * 1000).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }) : '';
  return '<div class="off-banner" role="status">' + ico('power') + '<div><b>VWARD отключён' + esc(at) + '</b><span>Роутер работает как обычный Keenetic: сайты идут напрямую, DNS - через провайдера.' +
    (o.dns_kept ? ' AdGuard Home оставлен в DNS: другого рабочего DNS у роутера нет.' : '') + (o.refused ? ' Роутер не принял ' + fmtInt(o.refused) + ' ' + plural(o.refused, 'изменение', 'изменения', 'изменений') + '.' : '') + '</span></div>' +
    btn('vward-on', 'power', 'Включить VWARD', 'small primary') + '</div>';
}
/* ---------- Хранение журналов ---------- */
// How long and how much of the technical journals the router keeps; nothing goes before that.
const JOURNAL_KEEP = [[1, '1 день'], [3, '3 дня'], [7, 'Неделя'], [30, 'Месяц'], [180, '6 месяцев'], [365, 'Год']];
const JOURNAL_SIZE = [1, 5, 10, 30, 0];
const journalSizeText = mb => mb ? mb + ' МБ' : 'Без ограничений';
function journalPanel() {
  const j = S.journal || {}, a = j.archived || {}, l = j.live || {};
  const keep = j.keep_days || 30, max = j.max_mb != null ? j.max_mb : 30, pos = Math.max(0, JOURNAL_SIZE.indexOf(max));
  const oldest = a.oldest ? new Date(a.oldest).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }) : null;
  return panel('Хранение журналов', (S.journal ? '<dl class="kv">' +
      ctrlRow('Срок хранения', sel('data-journal="keep"', 'Срок хранения журналов', JOURNAL_KEEP, keep)) +
      ctrlRow('Предельный размер', '<span class="range-field"><input class="range" type="range" min="0" max="' + (JOURNAL_SIZE.length - 1) + '" step="1" value="' + pos + '" data-journal-size aria-label="Предельный размер журналов" aria-valuetext="' + esc(journalSizeText(max)) + '"><output id="journalSize">' + esc(journalSizeText(max)) + '</output></span>') +
      '</dl>' + kv([
        ['Сейчас', fmtKB(Math.round(((a.bytes || 0) + (l.bytes || 0)) / 1024))],
        ['Самая старая запись', oldest ? 'с ' + oldest : 'архива пока нет']
      ]) : S.errors.journal ? '<p class="field-warn">Настройки хранения не загружены: ' + esc(S.errors.journal) + '</p><div class="panel-actions">' + btn('journal-reload', 'refresh', 'Повторить', 'small') + '</div>' :
        empty('Загрузка настроек хранения…')) +
    '',
    { desc: 'Журналы не стираются: старые записи сжимаются в архив и хранятся весь срок. Если журналы займут больше заданного размера, первыми уходят самые старые. «Скачать все журналы» - полная история одним архивом.' });
}

/* ---------- Агенты ---------- */
// Four agents, one zone each, so one thing is done by one agent; their state from their own runs.
function jobOk(names) {
  const jobs = ((S.cron && S.cron.jobs) || []).filter(j => names.includes(j.name));
  return jobs.length ? jobs.every(j => j.rc === 0) : null;
}
// The components agent watches the other three (late, hung) and says so; their own runs too.
const AGENT_STATE = { late: ['crit', 'Не запускается'], hung: ['warn', 'Зависал, перезапущен'] };
function agentsPanel() {
  const s = st(), sv = s.services || {}, known = !!s.services, ag = sv.agents || {};
  // A run that ended with an error (busy Keenetic, the last run still going) is not a broken agent:
  // the components agent says «Не запускается» or «Зависал» when it is (a Viva 2026-10-13).
  // Four words only (owner 2026-10-17); a run that ended with an error is a hint, not a state.
  const pill = (seen, ok) => seen === 'late' || seen === 'hung' ? ST.bad.concat(seen === 'hung' ? 'зависал, перезапущен' : 'не запускается вовремя') :
    ok == null ? ['', '—', ''] : ST.on.concat(ok ? '' : 'последний запуск с ошибкой');
  const rows = [
    ['Агент сети', 'интернет, VPN, DNS', pill(ag.network, jobOk(['vward-tunnel-health.sh', 'vward-wan-guard.sh', 'vward-route-reconciler.sh'])), 'wan'],
    ['Агент компонентов', 'программы и модули', pill(null, known ? !!sv.supervisor : null), current === 'utils' ? null : 'utils'],
    ['Агент обновлений', 'обновления программ', pill(ag.updates, known ? !!sv.crond : null), 'u-vward'],
    ['Агент обслуживания', 'журналы и накопитель', pill(ag.maintenance, jobOk(['vward-housekeeping.sh'])), 'logs'],
    // 11.11: the server alive is not enough, the login itself is checked by the components agent.
    ['Вход по SSH', 'проверка входа, не только процесса', ag.ssh === 'broken' ? ST.bad.concat('вход не проходит, см. журналы') :
      ag.ssh === 'ok' ? ST.on.concat('') : ['', 'не проверен', ''], 'logs']
  ];
  // The mode and the proposed actions are on the same page below: no rows leading to it (owner 2026-10-18).
  return panel('Агенты', kv(rows.map(r => [r[0], r[2][1], r[2][0], r[3], '', r[2][2] ? r[1] + ' · ' + r[2][2] : r[1]])),
    { beta: true, desc: 'Каждый агент следит за своей зоной; одно действие делает только один агент.' });
}
// The agents in one line for «Система»: how many work, the mode.
function agentsRow() {
  const sv = st().services || {}, ag = sv.agents || {}, am = agentsMode(), watching = agentList().filter(a => am[a[0]] === 'watch').length;
  const bad = ['network', 'updates', 'maintenance'].filter(k => ag[k] === 'late' || ag[k] === 'hung').length + (st().services && !sv.supervisor ? 1 : 0);
  return ['Агенты', bad ? 'не работает: ' + bad : 'работают: ' + agentList().length, bad ? 'crit' : 'ok', 'd-agents', '', watching ? (watching === agentList().length ? 'все в песочнице' : 'в песочнице ' + watching + ' из ' + agentList().length) : ''];
}

/* ---------- ИИ-сервисы ----------
   Each AI service of the catalog goes through VPN (its list into a tunnel, as in «Сервисы»),
   Smart DNS (its main domains answered by Smart DNS: AdGuard Home, else Keenetic's own lines,
   at most 8) or straight through the provider (owner 2026-10-17). A change is a background job
   like a service's. A server's path may hold a personal token: the Panel shows only its host. */
const AI_VIA = [['vpn', 'VPN'], ['dns', 'Smart DNS'], ['isp', 'Провайдер']];
const aiPrev = {}, AICHK = {};
// Optional prepared DTO only; no runtime API supplies it before live wiring.
// Reading a matching DATA configuration never proves a client packet path.
function routingOutcomeNote(o) {
  if (!o || o.schema !== 2 || o.activation !== 'off' || o.client_verified !== false || o.evidence !== 'configuration') return '';
  const states = { verified: 'совпадает', observed: 'наблюдается', partial: 'частично совпадает', mixed: 'разные пути', unknown: 'не подтверждена' };
  const state = o.configured && states[o.configured.state];
  if (!state) return '';
  return '<p class="seg-note muted">Новый режим не подключён. Конфигурация на тестовых данных: ' + esc(state) + '. Путь устройства не проверен.</p>';
}
// dnsDown: the Smart DNS server does not answer or is not set - its segment is off, with the reason.
// The owner's switch «Smart DNS» (08.11, off by default): its way is not offered while it is off.
const sdFeatureOff = () => !!S.ai && S.ai.smartdns_enabled === false;
function aiSlider(id, cur, label, off, dnsDown, dnsWhy) {
  const VIA = AI_VIA.filter(o => !(o[0] === 'dns' && sdFeatureOff() && cur !== 'dns'));
  if (sdFeatureOff()) { dnsDown = cur === 'dns'; dnsWhy = 'Smart DNS выключен'; }
  const to = Math.max(0, VIA.findIndex(o => o[0] === cur)), on = cfgOk() && !!S.ai && !SVC.busy && !off;
  const from = aiPrev[id] != null ? aiPrev[id] : to; aiPrev[id] = to;
  // The grid follows the ways offered (owner 12.11: two ways in three columns left a gap).
  return '<div class="seg-slider' + (['', '', ' two', '', ' four'][VIA.length] || '') + (on ? '' : ' off') + (cur ? '' : ' none') + '" role="radiogroup" aria-label="' + esc(label) + '" data-i="' + from + '" data-to="' + to + '"><i class="seg-thumb"></i>' +
    VIA.map(o => { const dis = !on || (o[0] === 'dns' && dnsDown && cur !== 'dns');
      return '<button type="button" role="radio" data-ai-via="' + o[0] + '" data-ai="' + esc(id) + '" aria-checked="' + (o[0] === cur) + '"' + (dis ? ' disabled' : '') + (o[0] === 'dns' && dnsDown ? ' title="' + esc(dnsWhy || 'сервер не отвечает') + '"' : '') + '>' + o[1] + '</button>'; }).join('') + '</div>' +
    (dnsDown && !sdFeatureOff() ? '<p class="seg-note">Smart DNS: ' + esc(dnsWhy || 'сервер не отвечает') + '</p>' : '') +
    (!cur && id === 'all' && S.ai ? '<p class="seg-note muted">Разные: у сервисов разный путь</p>' : '') +
    (S.ai && !on && !off && (SVC.busy ? AIBUSY === id : !cfgOk()) ? '<p class="seg-note muted">' + (SVC.busy ? 'Переключается…' : 'Изменение недоступно: нет прав на настройку') + '</p>' : '');
}
/* An unfinished service operation (fix.35.4, 03.11: «service on» refused with
   service_recovery_required again and again, no way out): what it was, since when, its lists, and the
   two exits - «Проверить и завершить» (VWARD compares the router: nothing of it left -> closed; partly
   done -> its own change given back; an owner's edit or Smart DNS rows on the wrong side -> stays,
   with the reason) and «Оставить как есть» (the owner keeps the router as it is, confirmed). */
let SVREC = null, SVREC_ACTION = false;
function actionRecovery(list) {
  return SVREC_ACTION ? recoveryPanel(list) : '';
}
// The reasons in words; «other-change» is a rollback that found the list changed by something other
// than this operation - another operation, the autopick or a hand edit: the marker cannot tell which.
const SVR_WHY = { ai: 'переход сервиса прерван между проверенными шагами; текущее состояние сохранено', list: 'список {g} не такой, как до операции', dns: 'строки Smart DNS списка {g} не на своём месте', 'other-change': 'список {g} изменён не этой операцией', file: 'файл настроек сервисов ({g}) изменён' };
const svrTitles = r => { const m = {}; (r && r.diff || []).forEach(d => { if (d.title) m[d.group] = d.title; }); return m; };
const svrWhy = (w, titles) => String(w || '').split(' ').filter(Boolean).map(t => { const i = t.indexOf(':'), k = t.slice(0, i), g = t.slice(i + 1);
  const name = (titles && titles[g]) ? '«' + titles[g] + '»' : (({ enabled: 'включённые', categories: 'категории', catalog: 'каталог' })[g] || g);
  return (SVR_WHY[k] || t).replace('{g}', name); }).join('; ');
const svrRoute = v => v === 'absent' ? 'списка нет' : v === 'none' || !v ? 'без маршрута' : v.split(' ').map(t => t === 'ISP' ? 'провайдер' : tunLabel(t)).join(', ');
const svrDiff = d => (d.title ? '«' + d.title + '»' : d.group) + ': ' + [d.added ? '+' + d.added + ' ' + plural(d.added, 'домен', 'домена', 'доменов') : '',
  d.removed ? '−' + d.removed + ' ' + plural(d.removed, 'домен', 'домена', 'доменов') : '',
  d.route_before !== d.route_now ? 'маршрут ' + svrRoute(d.route_before) + ' → сейчас ' + svrRoute(d.route_now) : ''].filter(Boolean).join(', ');
function recoveryPanel(list) {
  if (!list || !list.length) return '';
  return panel('Результат предыдущего действия', list.map(r => {
    const cid = 'svrec-accept:' + r.id, rid = 'svrec-restore:' + r.id, busy = SVREC && SVREC.id === r.id && SVREC.busy, titles = svrTitles(r);
    const diffs = (r.diff || []).filter(d => d.added || d.removed || d.route_before !== d.route_now);
    const dnsDiff = (r.dns_diff || []).map(d => (d.action === 'add' ? 'добавлено: ' : 'снято: ') + d.domain + ' (' + (d.store === 'agh' ? 'AdGuard Home' : 'Роутер') + ')');
    const note = r.running ? 'Ещё выполняется: дождитесь конца.' : 'Пока она не закрыта, VWARD не меняет сервисы, чтобы не повторить её поверх неизвестного состояния.' +
      (r.dns ? ' Затрагивает строки Smart DNS.' : '') + (r.why ? ' Сейчас: ' + svrWhy(r.why, titles) + '.' : '');
    const res = SVREC && SVREC.id === r.id && SVREC.text ? '<p class="result-note' + (SVREC.ok ? '' : ' warn') + '">' + esc(SVREC.text) + '</p>' : '';
    const ask = confirm && confirm.id === cid ? confirmBox(cid, 'Оставить роутер как есть и закрыть операцию? Списки останутся как сейчас' + (diffs.length ? ' (' + diffs.map(svrDiff).join('; ') + ')' : '') + (dnsDiff.length ? '. DNS: ' + dnsDiff.join('; ') : '') + '; данные операции сохранятся в резервной папке.', 'Оставить как есть', true) :
      confirm && confirm.id === rid ? confirmBox(rid, 'Вернуть списки операции как до неё? ' + (diffs.length ? 'Изменится: ' + diffs.map(svrDiff).join('; ') + ' - станет как до операции. ' : '') + 'Изменения после операции в этих списках будут отменены; строки Smart DNS не переносятся.', 'Вернуть', true) : '';
    const acts = r.running ? '' : ask || '<div class="panel-actions wrap">' +
      btn('svrec-resolve', 'check', busy ? 'Проверяем…' : 'Проверить и завершить', 'small primary' + (busy ? ' spinning' : ''), ' data-id="' + esc(r.id) + '"' + (busy || !cfgOk() ? ' disabled' : '')) +
      (diffs.length ? btn('ask', 'undo', 'Вернуть как до операции', 'small', ' data-confirm="' + esc(rid) + '"' + (busy || !cfgOk() ? ' disabled' : '')) : '') +
      btn('ask', 'close', 'Оставить как есть', 'small', ' data-confirm="' + esc(cid) + '"' + (busy || !cfgOk() ? ' disabled' : '')) + '</div>';
    return kv([['Операция', r.op || 'сервисы'], ['Отмечена', r.since ? fmtTime(r.since) : '—', '', null, '', 'время отметки о незавершённой операции']]) +
      (diffs.length ? '<ul class="rows">' + diffs.map(d => '<li class="row"><div class="row-main"><b>' + esc(d.title || d.group) + '</b><small>' + esc(svrDiff(d).replace(/^[^:]*: /, '')) + '</small>' +
        (d.title ? '<small class="muted">' + esc(d.group) + '</small>' : '') + '</div></li>').join('') + '</ul>' : '') +
      (dnsDiff.length ? '<p class="panel-desc">DNS: ' + esc(dnsDiff.join('; ')) + '</p>' : '') + '<p class="panel-desc">' + esc(note) + '</p>' + acts + res;
  }).join(''), { desc: 'Операция прервалась (перезапуск, сбой связи или отказ роутера) или её откат не подтвердился. «Проверить и завершить» закрывает её, если всё как до неё, или отменяет только её собственное изменение.' });
}
async function svRecover(id, mode) {
  SVREC = { id: id, busy: true }; render();
  const j = await bgJob(Object.assign({ op: 'recover', id: id, mode: mode }, mode === 'accept' ? { confirm: 'SERVICE_RECOVER_ACCEPT' } : mode === 'restore' ? { confirm: 'SERVICE_RECOVER_RESTORE' } : {}));
  SVREC = { id: id, ok: j.ok, text: j.ok ? (mode === 'accept' ? 'Закрыто: роутер оставлен как есть' : mode === 'restore' ? 'Закрыто: списки операции возвращены как до неё' : 'Завершено: состояние как до операции, сервисы снова можно менять') :
    !j.done ? 'Ещё выполняется, проверьте позже' : 'Не завершено: ' + errText(j.x) + (j.why ? ' (' + svrWhy(j.why) + ')' : '') };
  await Promise.all([load('ai', true), load('services', true)]); render();
}
function aiPage() {
  const a = S.ai, svc = (a && a.services) || [], sd = (a && a.smartdns) || {}, tuns = ((st().wg && st().wg.interfaces) || []).filter(t => !tunOff(t));
  const allVia = svc.length && svc.every(s => s.via === svc[0].via) ? svc[0].via : '';
  // fix.35.5 (A8): a server is a server - AdGuard Home being installed is not one (after the expired
  // server went, «Smart DNS» stayed open with no server to write to).
  const noSd = !(sd.server_rows || []).length && !sd.own;
  // The card's one status line (owner 02.11): the CHOSEN way and its check, a coloured dot; while a
  // check runs, a compact pill with a spinner in the same place (the line keeps its height, the
  // card does not jump; no toast - fix.26). The per-way results open below on demand.
  const sdServerDown = sd.alive !== 'yes' || noSd;
  const sdReason = noSd ? 'сервер не настроен' : sd.alive === 'no' ? 'сервер не отвечает' : sd.alive !== 'yes' ? 'ответ сервера не подтверждён' : sd.store === 'agh' && !(sd.storage && sd.storage.available) ? 'хранилище новых привязок недоступно' : '';
  const sdDown = !!a && !!sdReason;
  const wayName = { vpn: 'VPN', dns: 'Smart DNS', isp: 'Провайдер' };
  const status = s => {
    const c = AICHK[s.id], w = s.via || 'isp';
    if (s.selected === null && !(c && c.busy)) {
      const paths = (s.paths || []).map(l => '«' + (l.title || l.group) + '»: ' + (l.route === 'ISP' ? 'провайдер' : tunLabel(l.route)));
      const partial = s.coverage && s.coverage.routed < s.coverage.catalog;
      return '<span class="stat"><i class="dot warn"></i>' + esc((s.effective === 'mixed' ? partial ? 'Неполное покрытие каталога: ' + s.coverage.routed + ' из ' + s.coverage.catalog : 'Пересекаются маршруты или DNS' : s.effective === 'unknown' ? 'Путь не подтверждён' : 'Маршрут из доменных списков') + (paths.length ? ' · ' + paths.join('; ') : '') + '. Связь сервиса не задана.') + '</span>';
    }
    if (c && c.busy) return '<span class="busy-pill"><i class="spin" aria-hidden="true"></i>проверяется…</span>';
    if (w === 'dns' && sdDown) return '<span class="stat"><i class="dot ' + (sdServerDown ? 'crit' : 'warn') + '"></i>Smart DNS · ' + esc(sdReason) + '</span>';
    const r = c && c.ok ? (c.results || []).find(x => w === 'vpn' ? 'direct' !== x.via : 'direct' === x.via) : null;
    // The chosen way is a policy; a list of the same domains may send them elsewhere (02.11: ChatGPT
    // «Провайдер» while the list «ChatGPT OpenAI (ISP)» went through VPN) - shown, never switched.
    const lst = (s.lists || []).filter(l => w === 'vpn' ? l.route && l.route !== (s.tunnel || prof().tunnel_interface) : l.route && l.route !== 'ISP')[0];
    if (w === 'vpn' && s.coverage && s.coverage.routed < s.coverage.catalog) return '<span class="stat"><i class="dot warn"></i>' + esc('Выбрано: VPN · маршруты для ' + s.coverage.routed + ' из ' + s.coverage.catalog + ' доменов каталога; покрытие неполное') + '</span>';
    if (lst && !(c && c.busy)) return '<span class="stat"><i class="dot warn"></i>' + esc('Выбрано: ' + wayName[w] + ' · домены в списке «' + (l => l.title || l.group)(lst) + '» идут ' + (lst.route === 'ISP' ? 'через провайдера' : 'через «' + tunLabel(lst.route) + '»')) + '</span>';
    const v = r ? r.verdict : '', sdProxy = w !== 'dns' && c && c.smartdns && r && 'direct' === r.via;
    const cls = !c ? '' : !c.ok ? 'warn' : v === 'open' && !sdProxy ? 'ok' : v === 'open' || v === 'answer' ? 'warn' : v ? 'crit' : 'warn';
    const txt = !c ? 'не проверен' : !c.ok ? 'проверка не удалась' + (c.why ? ': ' + c.why : '') : r ? ('direct' === r.via ? 'напрямую ' : '') + (SVC_VERDICT[v] || v) + (r.code && !/\d{3}/.test(SVC_VERDICT[v] || '') ? ' (' + r.code + ')' : '') + (sdProxy ? ', адрес от Smart DNS' : '') : 'нет данных';
    return '<span class="stat"><i class="dot ' + cls + '"></i>' + esc(wayName[w] + ' · ' + txt) + '</span>';
  };
  const detail = s => { const c = AICHK[s.id]; if (!c || c.busy || !c.ok || !(c.results || []).length) return '';
    return '<details class="ai-detail"><summary>Подробнее</summary>' + c.results.map(r => esc(('direct' === r.via ? 'напрямую' : tunLabel(r.via)) + ': ' + (SVC_VERDICT[r.verdict] || r.verdict) + (r.code && !/\d{3}/.test(SVC_VERDICT[r.verdict] || '') ? ' (HTTP ' + r.code + ')' : ''))).join('<br>') +
      (c.ip ? '<br>' + esc(siteSrc(c)) : '') + '<br>' + esc('Проверяется одна страница ' + (c.domain || '') + ' с роутера; это не подтверждает путь трафика устройств и работу всего сервиса.') + '</details>'; };
  const busyBtn = s => AICHK[s.id] && AICHK[s.id].busy;
  const row = s => '<div class="ai-row"><div class="ai-head"><div class="row-main"><b>' + esc(s.title) + '</b></div>' +
      btn('ai-check', 'refresh', 'Проверить', 'small' + (busyBtn(s) ? ' spinning' : ''), ' data-ai="' + esc(s.id) + '" data-dom="' + esc(s.domain) + '"' + (busyBtn(s) ? ' disabled' : '')) +
      '<small class="ai-status">' + status(s) + '</small></div>' +
      aiSlider(s.id, s.selected === null ? '' : s.via, s.title, false, sdDown, sdReason) + (AIRES[s.id] ? '<p class="result-note ai-res">' + esc(AIRES[s.id]) + '</p>' : '') + aiReferenceChoice(s) + ((s.paths || []).length > 1 ? '<details class="ai-detail"><summary>Источники маршрута</summary>' + s.paths.map(p => esc((p.title || p.group) + ' (' + p.group + '): ' + (p.route === 'ISP' ? 'провайдер' : tunLabel(p.route)))).join('<br>') + '</details>' : '') + detail(s) + routingOutcomeNote(s.routing_outcome) +
      (s.tunnel && tuns.length > 1 ? '<dl class="kv">' + ctrlRow('Туннель', sel('data-ai-tunnel="' + esc(s.id) + '"', 'Туннель для ' + s.title, tuns.map(t => [t.name, tunLabel(t.name)]), s.tunnel || prof().tunnel_interface)) + '</dl>' : '') + '</div>';
  // Smart DNS first: the services «через Smart DNS» open only while it works (owner 2026-10-17).
  // The server does not answer (01.11.2026: the subscription ended): its domains do not resolve.
  const sdDead = a && sd.alive === 'no' ? panel('Smart DNS не отвечает', '<p class="result-note warn">Сервер Smart DNS не отвечает на DNS-запросы: сайты, привязанные к нему (' +
    fmtInt((sd.keenetic || 0) + (sd.agh_domains || 0)) + '), не открываются. Уберите сервер кнопкой ниже или переведите сервисы на VPN.</p>') : '';
  return loadError(['ai']) + actionRecovery(a && a.recovery) + sdDead + aiQuestion(sd) + aiRoomPanel(sd) +
    panel('Smart DNS', '<dl class="kv">' + ctrlRow('Smart DNS', sw('data-sd-feature', !!(a && a.smartdns_enabled), 'Smart DNS', !cfgOk() || !a || (!a.smartdns_enabled && !sd.own)),
        a && a.smartdns_enabled ? 'включён: режим «DNS» доступен, пока сервер отвечает; Keenetic - не больше 8 строк' :
          'выключен: VWARD не пишет строки Smart DNS в Keenetic и AdGuard Home и не проверяет сервер; ' +
          (a && !sd.own ? 'включить можно, когда задан свой сервер DoH (ниже)' : 'включается, только если сервер отвечает')) + '</dl>' +
      confirmBox('sd-off', 'Выключить Smart DNS? VWARD снимет свои строки Smart DNS (по адресу своего сервера) из Keenetic и AdGuard Home, с откатом при ошибке. Чужие строки, NextDNS, ваши правила DNS и DNS провайдера не трогаются. Адрес сервера сохранится.', 'Выключить', true) + kv([
        (sd.server_rows || []).length ? null : ['Сервер', !a ? '…' : 'не задан', a && noSd ? 'warn' : ''],
        ['Домены Smart DNS', 'открыть', '', 'd-smartdns', '', 'и агент: держит их мимо VPN']]) + sdStoreRow(a, sd) +
      sdServers(a, sd) +
      inputBar({ form: 'ai-dns-add', label: sd.own ? 'Заменить свой сервер DoH' : 'Свой сервер DoH', name: 'server', mono: true, placeholder: 'https://dns.example/dns-query', aria: 'Адрес DoH', off: !cfgOk(), icon: 'plus', btn: 'Сохранить' }) +
      '<div class="panel-actions">' + (sd.own ? btn('ai-dns-clear', 'close', 'Убрать свой сервер') : '') +
        ((sd.server_rows || []).length ? btn('ai-dns-clear-url', 'close', 'Убрать по адресу', '', cfgOk() ? '' : ' disabled') : '') + '</div>' + resultBox('aidns'),
      { desc: 'Сервер, через который открываются сервисы с путём «Smart DNS». Без AdGuard Home VWARD пишет строки в Keenetic (не больше 8). Адрес хранится только на роутере.' }) +
    panel('Все ИИ-сервисы', aiSlider('all', allVia, 'Все ИИ-сервисы', false, sdDown, sdReason) +
      (SVC.busy && AIBUSY && AIBUSY !== 'all' ? '<p class="seg-note muted">Переключается «' + esc(aiName(AIBUSY)) + '»: остальные сервисы доступны после него</p>' : '') + resultBox('svc'),
      { beta: true, desc: allVia ? 'Одним нажатием переключить все сервисы, например когда Smart DNS сбоит.' : 'Сейчас у сервисов разный путь. Нажмите, чтобы отправить все одним путём.' }) +
    panel('Сервисы', !a ? empty('Загрузка…') : svc.length ? svc.map(row).join('') : empty('В каталоге нет ИИ-сервисов'),
      { desc: 'VPN - через туннель; Smart DNS - через DNS-сервер, который открывает сервис; Провайдер - напрямую.' });
}
// Every server Keenetic's lines and AdGuard Home's rows still use, with what it holds and its own
// «Убрать» (fix.35.3, 02.11: the subscription ended, the own address was already gone, its 35 rows
// stayed and the page offered no button). Removal is the owner's choice, confirmed: only that
// server's domain rows go, the other servers and the general upstreams stay.
// The answer of the one server asked (the own one, else the most used): a whole DNS answer is
// «отвечает на DNS» - it does not show that a service works through it (fix.35.4).
const SD_WHY = { 'dns:rcode5': 'отказывает в ответе', 'dns:rcode2': 'ошибка сервера DNS', 'dns:empty': 'пустой ответ', 'dns:short': 'неполный ответ', 'dns:invalid': 'ответ не DNS', 'curl:28': 'нет ответа за отведённое время' };
function sdAnswer(r, sd) {
  if (r.host !== sd.alive_host) return ['', 'не проверялся'];
  const why = sd.alive_why ? SD_WHY[sd.alive_why] || (/^http:/.test(sd.alive_why) ? 'HTTP ' + sd.alive_why.slice(5) : sd.alive_why) : '';
  return sd.alive === 'yes' ? ['ok', 'отвечает на DNS (работа сервисов не проверена)'] : sd.alive === 'no' ? ['crit', 'не отвечает' + (why ? ': ' + why : '')] :
    sd.alive === 'unknown' ? ['warn', 'ответ не подтверждён'] : ['', 'не проверялся'];
}
function sdServers(a, sd) {
  const rows = (a && sd.server_rows) || [];
  if (!rows.length) return '';
  return '<ul class="rows sd-servers">' + rows.map(r => {
    const what = [r.keenetic ? 'в Keenetic ' + fmtInt(r.keenetic) : '', r.agh ? 'в AdGuard Home ' + fmtInt(r.agh) : ''].filter(Boolean).join(', ') || 'привязок нет';
    const st = sdAnswer(r, sd), cid = 'sd-drop:' + r.host;
    const ctl = confirm && confirm.id === cid ? '' : btn('ask', 'close', 'Убрать', 'small', ' data-confirm="' + esc(cid) + '" aria-label="Убрать сервер ' + esc(r.host) + '"' + (cfgOk() ? '' : ' disabled'));
    return '<li class="row sd-server"><div class="row-main"><b class="sd-host">' + esc(r.host) + (r.own ? ' <small class="muted">свой</small>' : '') + '</b>' +
      '<small>доменов: ' + esc(what) + '</small><small class="stat"><i class="dot ' + st[0] + '"></i>' + esc(st[1]) + '</small></div>' +
      (ctl ? '<span class="row-acts">' + ctl + '</span>' : '') + '</li>' +
      (confirm && confirm.id === cid ? '<li class="row">' + confirmBox(cid, 'Убрать привязки к ' + r.host + ' (' + what + ')? Другие серверы и общий DNS останутся.', 'Убрать', true) + '</li>' : '');
  }).join('') + '</ul>';
}
// Where new Smart DNS domains go, the owner's choice (fix.32); AdGuard Home only while it works.
let SDSTORE_BUSY = false;
function sdStoreRow(a, sd) {
  if (!a) return '';
  const cap = sd.storage || {}, component = cap.component || 'AdGuard Home';
  const reason = ({ not_installed: 'компонент не установлен или не подключён', not_running: 'компонент не запущен', disabled: 'компонент выключен', inactive_handler: 'выбран другой DNS-обработчик', upstream_file_unsupported: 'привязки из внешнего файла не поддерживаются' })[cap.reason] || 'доступность не подтверждена';
  const counts = [(sd.keenetic || 0) ? 'Роутер: ' + fmtInt(sd.keenetic) + ' из ' + fmtInt(sd.keenetic_max || 8) : '', (sd.agh_domains || 0) ? component + ': ' + fmtInt(sd.agh_domains) : ''].filter(Boolean).join(' · ') || 'Привязок пока нет';
  const target = cap.target === 'agh' ? component : cap.target === 'keenetic' ? 'Роутер' : 'недоступно';
  const note = counts + '. ' + (sd.store === 'auto' || !sd.store ? 'Новые привязки: ' + target : 'Выбрано: ' + (sd.store === 'agh' ? component : 'Роутер')) +
    (sd.store === 'agh' && !cap.available ? ' · ' + reason : '') + '. Выбор действует только на новые привязки; существующие не переносятся.';
  // No AdGuard Home on the router (owner 12.11.2026: nothing pushes it): only «Авто» and «Роутер»,
  // unless it is already chosen or holds domains - then its state stays in view.
  const aghOpt = cap.reason !== 'not_installed' || sd.store === 'agh' || (sd.agh_domains || 0) > 0;
  return '<dl class="kv sd-storage">' + ctrlRow('Хранилище Smart DNS', choiceSlider('sd-store',
    [['auto', 'Авто', SDSTORE_BUSY], ['keenetic', 'Роутер', SDSTORE_BUSY]].concat(aghOpt ? [['agh', String(component).replace(/ Home$/, ''), SDSTORE_BUSY]] : []), sd.store || 'auto', 'Хранилище Smart DNS'), note) + '</dl>';
}
async function sdStoreSet(v) {
  if (SDSTORE_BUSY) return;
  SDSTORE_BUSY = true; render();
  let x, confirmed;
  try {
    x = await apiPost('smartdns-server', { op: 'store', store: v });
  } catch (err) { x = { ok: false, error: err.message }; }
  try { confirmed = await apiGet('ai-data'); } catch (_) { confirmed = null; }
  const readable = confirmed && confirmed.ok && Array.isArray(confirmed.services) && confirmed.smartdns && typeof confirmed.smartdns === 'object';
  const verified = readable && confirmed.smartdns.store === v;
  if (readable) S.ai = confirmed;
  actionResult = { id: 'aidns', text: verified ? 'Хранилище сохранено. Существующие привязки не перенесены.' :
    'Выбор не подтверждён: ' + (x && !x.ok ? errText(x) : 'не удалось перечитать настройку') };
  SDSTORE_BUSY = false; render();
}
// host: a server of the list (sdServers); url: an exact address the owner pasted. The result is read
// again from the router: «убран» only when no row of that server is left (an empty own address
// proves nothing, 02.11).
async function smartdnsServer(op, url, host) {
  const body = Object.assign({ op: op, url: url || '' }, host ? { host: host } : {});
  actionResult = { id: 'aidns', text: op === 'set' ? 'Сохраняем…' : 'Убираем привязки…' }; render();
  let x; try { x = await apiPost('smartdns-server', body); } catch (err) { x = { ok: false, error: err.message }; }
  const c = x.cleared || {};
  await load('ai', true);
  const sd = (S.ai && S.ai.smartdns) || {}, left = (sd.server_rows || []).filter(r => host ? r.host === host : r.own);
  const n = r => (r.keenetic || 0) + (r.agh || 0), still = left.reduce((t, r) => t + n(r), 0), other = (sd.server_rows || []).filter(r => !r.own && n(r));
  actionResult = { id: 'aidns', text: !x.ok ? 'Не выполнено: ' + errText(x) : op === 'set' ? 'Сервер сохранён' :
    still ? 'Выполнено не полностью: у сервера осталось привязок ' + fmtInt(still) + ' - повторите или смотрите «Журналы»' :
    x.result === 'unchanged' ? (other.length && !host ? 'У своего сервера привязок нет; ещё используются: ' + other.map(r => r.host).join(', ') + ' - уберите нужный кнопкой «Убрать»' : 'Убирать нечего: привязок к этому серверу нет') :
    'Сервер убран. Очищено: в Keenetic строк ' + (c.keenetic || 0) + ', в AdGuard Home доменов ' + (c.agh || 0) + ', сохранённых состояний списков ' + (c.saved || 0) + '. Сервисы этого сервера теперь идут через провайдера: выберите для них VPN' };
  render();
}
// aiJob ID WAY MSG [KEEP]: KEEP - the answer to «no room in Smart DNS» (the service still waits
// for Smart DNS). No room: the Panel asks which way the services that did not fit go (fix.31).
let AIQ = null;
const AIRES = {}, AIREF = {};
function aiReferenceChoice(s) {
  if (!AIREF[s.id]) return '';
  const candidates = (s.paths || []).filter(p => p.reference), token = S.ai && S.ai.reference_token;
  if (!candidates.length || !token) return '<p class="seg-note">Существующие списки остаются под ручным управлением. Подтверждённой связи VWARD с ними нет; их состав и маршрут показаны выше.</p>';
  return '<div class="ai-reference"><p class="panel-desc">Можно связать сервис с уже применённым маршрутом, оставив список под ручным управлением. VWARD не получит права менять или удалять его.</p>' + candidates.map(p =>
    '<details><summary>' + esc((p.title || p.group) + ' · ' + tunLabel(p.route) + ' · доменов: ' + (p.members || []).length) + '</summary><p class="panel-desc">' + esc((p.members || []).join(', ')) + '</p></details>' +
    btn('ai-reference', 'link', 'Связать без права изменения', 'small', ' data-ai="' + esc(s.id) + '" data-group="' + esc(p.group) + '" data-token="' + esc(token) + '"' + (SVC.busy || !cfgOk() ? ' disabled' : ''))).join('') + '</div>';
}
async function aiReference(id, group, token) {
  SVC.busy = true; render();
  const j = await bgJob({ op: 'reference', id: id, tunnel: group, token: token, confirm: 'SERVICE_REFERENCE_ONLY' });
  SVC.busy = false; AIREF[id] = !j.ok;
  AIRES[id] = j.ok ? 'Связано с текущим маршрутом. Список остаётся ручным; изменение его маршрута и удаление не разрешены.' : 'Связь не подтверждена: ' + errText(j.x);
  await Promise.all([load('ai', true), load('services', true)]); render();
}
// The service being switched now ('all' for every one): only it says «Переключается…», the others
// wait under one line on «Все ИИ-сервисы» (one switch at a time stays).
let AIBUSY = null;
async function aiJob(id, to, msg, keep) {
  const show = text => { if (id === 'all') actionResult = { id: 'svc', text: text }; else { AIRES[id] = text; actionResult = null; } render(); };
  SVC.busy = true; AIBUSY = id; AIQ = null; show(to === 'dns' ? 'Записываем домены Smart DNS…' : 'Переводим…');
  let j = { ok: false, done: true, x: { error: 'helper_failed' } }, confirmed = null;
  try {
    j = await bgJob(Object.assign({ op: 'ai', id: id, tunnel: to }, keep ? { keep: '1' } : {}));
    try { confirmed = await apiGet('ai-data'); } catch (_) { confirmed = null; }
    if (confirmed && confirmed.ok && Array.isArray(confirmed.services) && confirmed.smartdns && typeof confirmed.smartdns === 'object') S.ai = confirmed;
    else confirmed = null;
    await Promise.all([load('services', true), load('lists', true)]);
  } catch (e) { j = { ok: false, done: true, x: { error: e.message || 'helper_failed' } }; }
  finally { SVC.busy = false; AIBUSY = null; }
  SVREC_ACTION = !j.ok && j.done;
  AIREF[id] = !j.ok && j.x && j.x.error === 'service_reference_only';
  if (id === 'all' && AIREF[id]) ((S.ai && S.ai.services) || []).forEach(s => { AIREF[s.id] = (s.paths || []).some(p => p.reference); });
  if (to === 'dns' && (j.left || []).length) AIQ = { ids: j.left };
  const expected = to === 'dns' ? 'dns' : to === 'isp' ? 'isp' : 'vpn';
  const rows = confirmed && confirmed.ok ? (confirmed.services || []).filter(s => (id === 'all' || s.id === id) && !(j.left || []).includes(s.id)) : [];
  const verified = rows.length > 0 && rows.every(s => s.selected === expected);
  const conflict = verified && rows.some(s => s.effective !== expected);
  show(j.ok ? (!verified ? 'Результат переключения не подтверждён перечитыванием; смотри текущий путь и «Журналы».' : conflict ? 'Настройка сервиса применена. Есть пересекающиеся DNS или маршруты: смотри источники ниже.' : AIQ ? 'Часть сервисов переведена; для остальных выбери маршрут' : msg) :
    !j.done ? 'Ещё выполняется; результат появится в «Задания»' : AIQ ? '' : 'Не выполнено: ' + errText(j.x));
}
async function aiAnswer(way) {
  const q = AIQ; AIQ = null;
  if (!q || way === 'cancel') { render(); return; }
  for (const id of q.ids) await aiJob(id, way, aiName(id) + ': ' + (way === 'isp' ? 'напрямую через провайдера' : 'через VPN-туннель'), true);
}
const aiName = id => ((((S.ai || {}).services || []).find(s => s.id === id) || {}).title || id);
// The question when Keenetic's 8 Smart DNS lines are taken, with what the router has now: a
// working tunnel (first), AdGuard Home that does not work, a tunnel that is down (why not).
function aiQuestion(sd) {
  if (!AIQ) return '';
  const tuns = ((st().wg && st().wg.interfaces) || []).filter(t => !tunOff(t) && !tunLost(t)), def = prof().tunnel_interface;
  const up = tuns.find(t => t.name === def && isTrue(t.connected)) || tuns.find(t => isTrue(t.connected));
  const names = AIQ.ids.map(aiName).join(', ');
  const notes = [sd.agh && !sd.agh_running ? 'AdGuard Home не работает, поэтому домены записываются в Keenetic.' : '',
    !tuns.length ? 'VPN-туннеля нет.' : !up ? 'Туннель ' + tunLabel(def || tuns[0].name) + ' не в сети: маршрут через VPN сейчас недоступен.' : ''].filter(Boolean);
  return panel('Нет места', '<p class="panel-desc">' + esc('Лимит Smart DNS в Keenetic исчерпан (' + (sd.keenetic || 8) + ' из ' + (sd.keenetic_max || 8) + ' доменов). Выберите маршрут для ' + names + '.') + '</p>' +
    (notes.length ? '<p class="field-warn">' + esc(notes.join(' ')) + '</p>' : '') +
    '<div class="panel-actions">' + (tuns.length ? btn('ai-answer', 'route', 'Через VPN-туннель', up ? 'primary' : '', ' data-way="auto"' + (up ? '' : ' disabled')) : '') +
    btn('ai-answer', 'globe', 'Напрямую через провайдера', up ? '' : 'primary', ' data-way="isp"') + btn('ai-answer', 'close', 'Отмена', '', ' data-way="cancel"') + '</div>');
}
// Room again (a line went, or AdGuard Home works): the services that waited can go to Smart DNS.
const aiRoom = sd => !!sd && (sd.waiting || []).length > 0 && ((sd.agh && sd.agh_running) || (sd.keenetic || 0) < (sd.keenetic_max || 8));
function aiRoomPanel(sd) {
  if (AIQ || !aiRoom(sd)) return '';
  return panel('Есть место', '<p class="panel-desc">' + esc('В Smart DNS освободилось место: ' + sd.waiting.map(aiName).join(', ') + ' можно перевести на Smart DNS.') + '</p>' +
    '<div class="panel-actions">' + sd.waiting.map(id => btn('ai-room', 'route', sd.waiting.length > 1 ? 'Перевести ' + aiName(id) : 'Перевести', 'primary', ' data-ai="' + esc(id) + '"' + (SVC.busy ? ' disabled' : ''))).join('') + '</div>');
}
let AISEQ = 0;
async function aiCheck(id, dom) {
  const seq = ++AISEQ; AICHK[id] = { busy: true, seq: seq }; render();
  let x; try { x = await apiGet('site-test', { domain: dom }); } catch (e) { x = { ok: false, error: e.message }; }
  // Only the answer of this very check ends it (an older one arriving late is dropped).
  if (!AICHK[id] || AICHK[id].seq !== seq) return;
  AICHK[id] = x && x.ok ? { ok: true, results: x.results || [], ip: x.ip, dns: x.dns, smartdns: !!x.smartdns, domain: x.domain } : { ok: false, why: x && x.error }; render();
}

/* ---------- Очистка ----------
   VWARD's own leftovers by group; the newest copy of every kind always stays (the router's
   helper keeps it), the owner's backups, settings and keys are never here. */
const CLEAN = [['archive', 'Архив журналов', 'сжатые старые журналы'], ['diagnostics', 'Отчёты диагностики', ''],
  ['forensics', 'Разборы сбоев', 'последний остаётся'], ['legacy', 'Файлы прежних версий', ''],
  ['packages', 'Копии пакетов перед обновлением', 'последняя остаётся'], ['settings', 'Копии настроек перед изменением', 'последняя остаётся'],
  ['ads', 'Копии фильтров рекламы', 'последняя каждого вида остаётся']];
function cleanupPanel() {
  const c = S.cleanup, kb = (c && c.kb) || {}, ok = cfgOk();
  // fix.38.1 (owner 12.11.2026): only what takes space; eight «пусто» rows said nothing.
  const rows = CLEAN.filter(g => kb[g[0]]).map(g => '<div class="kv-row" data-key="' + esc(g[1]) + '"><dt>' + esc(g[1]) + (g[2] ? '<span class="hint">' + esc(g[2]) + '</span>' : '') + '</dt><dd><span class="num' + (kb[g[0]] ? '' : ' none') + '">' + (kb[g[0]] ? fmtKB(kb[g[0]]) : 'пусто') + '</span>' +
    (kb[g[0]] ? '<button class="icon-btn" type="button" data-act="ask" data-confirm="cleanup" data-what="' + g[0] + '" aria-label="Очистить: ' + esc(g[1]) + '" title="Очистить"' + (ok ? '' : ' disabled') + '>' + ico('broom') + '</button>' : '') + '</dd></div>').join('');
  const cg = confirm && confirm.id === 'cleanup' ? (confirm.what === 'all' ? [0, 'всё временное'] : CLEAN.find(g => g[0] === confirm.what) || [0, '']) : null;
  const any = CLEAN.some(g => kb[g[0]]);
  return panel('Очистка', !c ? empty('Загрузка…') : (rows ? '' : '<p class="panel-desc">Временных файлов нет.</p>') + '<dl class="kv">' + rows +
      '<div class="kv-row" data-key="Журналы"><dt>Журналы<span class="hint">не удаляются, сжимаются кнопкой</span></dt><dd><span class="num">' + (kb.journals ? fmtKB(kb.journals) : '—') + '</span></dd></div></dl>' +
      (cg ? confirmBox('cleanup', 'Очистить: ' + cg[1].toLowerCase() + '? Это не вернуть.', 'Очистить', true) :
        '<div class="panel-actions even">' + btn('ask', 'broom', 'Очистить временное', '', ' data-confirm="cleanup" data-what="all"' + (ok && any ? '' : ' disabled')) + btn('housekeeping', 'archive', 'Сжать журналы') + '</div>') + resultBox('storage'),
    { desc: 'VWARD сам чистит старое каждый час. Настройки, ключи туннелей и ваши резервные копии здесь не удаляются.' });
}

/* ---------- Сброс настроек ---------- */
function resetPanel() {
  return panel('Сброс настроек', (confirmBox('reset', 'Вернуть переключатели и параметры VWARD как после установки? Туннели, списки, подсети, маршруты и канал обновлений останутся. Сначала сохранится копия настроек.', 'Сбросить', true) ||
      '<div class="panel-actions">' + btn('ask', 'reset', 'Сбросить настройки', '', ' data-confirm="reset"' + (cfgOk() ? '' : ' disabled')) + '</div>') + resultBox('reset'),
    { desc: 'Переключатели и параметры - как после установки; вернуть можно из «Резервных копий». Удалить VWARD целиком - команда удаления из инструкции.' });
}

/* ---------- Управление ----------
   Every switch of VWARD in one place (owner 2026-10-17): the same switches, handlers and
   confirmations as on their own pages, so nothing new runs on the router. */
function controlPage() {
  const ok = cfgOk(), a = S.ads || {}, g = a.dns_guard || {}, L = S.lists, x = S.ext || {}, fw = x.firmware || {};
  // A group with nothing to set is left out (fix.38: no empty cards).
  const group = (title, rows, after) => rows.filter(Boolean).length ? panel(title, '<dl class="kv">' + rows.filter(Boolean).join('') + '</dl>' + (after || '')) : '';
  // fix.38: the parts' own switches (components, agents) live in «Компоненты» only; here the settings.
  return loadError(['config']) + cfgNote() +
    panel('Компоненты и агенты', kv([['Включить или выключить часть VWARD', 'в «Компонентах»', '', 'utils']])) +
    group('Маршруты', [
      ctrlRow('Автоподбор доменов', sw('data-cfg-rt="adaptive-mode"', cfgRoute().adaptive_enabled !== false, 'Автоподбор доменов', !ok), 'отправлять через VPN домены, недоступные напрямую'),
      L ? ctrlRow('Агент Smart DNS', sw('data-smartdns-guard', L.smartdns_guard !== false, 'Агент Smart DNS', !ok), 'не пускать домены Smart DNS в VPN') : ''],
      '') +
    group('Реклама и DNS', [
      a.agh_connected ? ctrlRow('Все устройства через AdGuard Home', sw('data-dnsg="enforce"', g.enforce === '1', 'Все устройства через AdGuard Home', g.upstream !== 'encrypted' && g.enforce !== '1')) : '',
      a.agh_connected ? ctrlRow('Выводить AdGuard Home из DNS при сбое', sw('data-dnsg="chain"', g.chain !== '0', 'Выводить AdGuard Home из DNS при сбое')) : ''],
      '') +
    group('Автоматика', [S.ext ? ctrlRow('Обновлять AdGuard Home', sw('data-ext-auto="agh"', x.auto && x.auto.agh, 'Обновлять AdGuard Home автоматически')) : '',
      S.ext ? ctrlRow('Обновлять Entware', sw('data-ext-auto="entware"', x.auto && x.auto.entware, 'Обновлять пакеты Entware автоматически')) : '',
      S.ext && fw.auto_update != null ? ctrlRow('Обновлять прошивку', sw('data-fw-auto', fw.auto_update, 'Обновлять прошивку автоматически')) : '',
      ''], '') +
    panel('Отключить VWARD целиком', kv([['Аварийное отключение', 'в «Системе»', '', 'system']]), { icon: 'power' });
}

/* ---------- В разработке ----------
   Screens whose router part is not written yet (Управление, ИИ-сервисы, Очистка, Сброс, clearing
   and deleting lists) show here instead of controls that would fail; the drafts are in git history.
   What is planned shows at its place, grey (owner 2026-10-17): what it will be and in which release. */
const SOON = {
  // Release numbers as in ROADMAP; 12.11.2026 (owner, ROADMAP §8): certificates, the Panel's
  // languages and AmneziaWG Premium are not planned any more.
  system: [['Полный сброс', 'fix.39', 'убрать из Keenetic всё, что добавил VWARD, с копией настроек']],
  vless: [['Шапка подписки', 'fix.39', 'трафик, срок, поддержка провайдера'], ['Замер скорости серверов', 'fix.39', 'скорость каждого сервера по кнопке']],
};
function soonPanel(key) {
  const l = SOON[key] || [];
  return l.length ? panel('В разработке', '<dl class="kv soon">' + l.map(x => '<div class="kv-row" data-key="' + esc(x[0]) + '"><dt>' + esc(x[0]) + '<span class="hint">' + esc(x[2]) + '</span></dt><dd><span class="tag soon">скоро</span></dd></div>').join('') + '</dl>', { icon: 'clock' }) : '';
}
// Observation mode (fix.28.2; watch by default since fix.28.6): an agent that only watches writes down what it would do.
// The agents and their names: the parts' registry the router sends (one list of names, 12.11.2026).
const agentList = () => Object.entries((st().parts && st().parts.agents) || {});
const agentName = k => ((st().parts && st().parts.agents) || {})[k] || 'Агент';
function agentsMode() {
  const m = ((S.config && S.config.agents) || {}).mode || {}, all = m.all === 'act' ? 'act' : 'watch';
  return Object.fromEntries([['all', all]].concat(agentList().map(a => [a[0], m[a[0]] === 'watch' || m[a[0]] === 'act' ? m[a[0]] : all])));
}
const modePrev = {};
// «Песочница | Вкл» as one slider, like the Wi-Fi bands (fix.38.1, owner 12.11.2026: one scheme
// «Выкл · Песочница · Вкл» for everything that can change the system; agents always run).
function modeSlider(agent, cur, label) {
  const ops = [['watch', 'Песочница'], ['act', 'Вкл']], to = cur === 'act' ? 1 : 0, from = modePrev[agent] != null ? modePrev[agent] : to, on = cfgOk();
  modePrev[agent] = to;
  return '<div class="seg-slider two' + (on ? '' : ' off') + '" role="radiogroup" aria-label="' + esc(label) + '" data-i="' + from + '" data-to="' + to + '"><i class="seg-thumb"></i>' +
    ops.map(o => '<button type="button" role="radio" data-agent-mode="' + agent + '" data-mode="' + o[0] + '" aria-checked="' + (o[0] === cur) + '"' + (on ? '' : ' disabled') + '>' + o[1] + '</button>').join('') + '</div>';
}
// The agents' protocols: each known case, how the agent sees it and the one safe action it
// takes (or, watching, writes down). The same cases as vward_agent_acts in their scripts.
const AGENT_PROTOCOLS = [
  ['network', 'Туннель не отвечает', 'проверки через туннель не проходят несколько минут', 'выключить туннель, списки - на резервный канал'],
  ['network', 'Туннель снова отвечает', 'резервный канал держится, основной туннель ответил', 'вернуть списки на туннель'],
  ['network', 'Интернет не отвечает', 'провайдер не отвечает подряд несколько проверок', 'заново получить адрес, затем переподключить'],
  ['components', 'Программа занимает много памяти', 'память выше предела несколько проверок подряд', 'перезапустить программу'],
  ['components', 'Запуск завис', 'задание работает дольше своего предела', 'остановить зависший запуск'],
  ['components', 'Программа просит перезапуск', 'другой агент сообщил о сбое', 'перезапустить программу'],
  ['components', 'AdGuard Home не запускается', 'программа падает с «Illegal instruction»', 'поставить официальную сборку той же версии'],
  ['updates', 'Доступно обновление пакета', 'новая версия в Entware или у AdGuard', 'установить с копией и откатом'],
  ['maintenance', 'Программа падает', 'клиент DoH или curl падают при запуске', 'сверить пакеты с Entware и переустановить испорченные'],
  ['maintenance', 'Ошибки на USB-накопителе', 'сверка файлов нашла изменённые без записи программой', 'переустановить испорченные пакеты']
];
// «Предполагаемые действия» (owner 02.11): grouped by agent, the same action folded («× 3, последняя
// …»), a short bold title and the time, the proposal below; tunnels by their Panel names; the
// newest 10 with «Показать ещё»; older than a week folded.
let PROP_ALL = false;
function proposedHtml(pr) {
  if (!pr.length) return empty('Пока нет');
  const names = t => String(t || '').replace(/\b(OpkgTun\d+|Wireguard\d+)\b/g, n => tunLabel(n) !== n ? tunLabel(n) + ' (' + n + ')' : n);
  const groups = [], byKey = {};
  pr.forEach(p => { const k = p.agent + '|' + p.action; if (!byKey[k]) { byKey[k] = { p: p, n: 0, last: p.at }; groups.push(byKey[k]); } byKey[k].n++; });
  const weekAgo = Date.now() / 1000 - 7 * 86400, fresh = groups.filter(g => +g.p.at >= weekAgo), old = groups.filter(g => +g.p.at < weekAgo);
  const shown = PROP_ALL ? fresh : fresh.slice(0, 10);
  const item = g => { const t = names(g.p.text), m = /^([^:]{3,80}):\s*(.*)$/.exec(t), title = m ? m[1] : t, rest = m ? m[2] : '';
    const opts = rest.split(/,\s*|\s+или\s+/).filter(Boolean);
    return '<li class="prop"><div class="prop-head"><b>' + esc(title) + '</b><time>' + esc(fmtStamp(g.last)) + (g.n > 1 ? ' · × ' + g.n : '') + '</time></div>' +
      (opts.length > 1 ? '<p>Предложит одно из ' + opts.length + ':</p><ul>' + opts.map(o => '<li>' + esc(o) + '</li>').join('') + '</ul>' : rest ? '<p>' + esc(rest) + '</p>' : '') + '</li>'; };
  const byAgent = list => agentList().map(a => { const l = list.filter(g => g.p.agent === a[0]); return l.length ? '<h3 class="prop-agent">' + esc(a[1]) + '</h3><ul class="props">' + l.map(item).join('') + '</ul>' : ''; }).join('');
  return (shown.length ? byAgent(shown) : empty('За неделю новых нет')) +
    (fresh.length > 10 && !PROP_ALL ? '<div class="panel-actions"><button class="btn small" type="button" data-act="prop-more">Показать ещё (' + (fresh.length - 10) + ')</button></div>' : '') +
    (old.length ? '<details class="prop-old"><summary>Старше недели (' + old.length + ')</summary>' + byAgent(old) + '</details>' : '');
}
const AGENT_LOCKED = [
  ['Запуск остановленных программ VWARD', 'агент компонентов'], ['Панель VWARD и SSH', 'агент компонентов'],
  ['AdGuard Home вне цепочки DNS, когда он молчит', 'интернет дома не пропадает'], ['Обновления самого VWARD', 'через них приходят исправления'],
  ['Сжатие журналов и место на флешке', 'агент обслуживания']
];

function offPanel() {
  const off = offState() === 'off', busy = offState() === 'working';
  return panel('Аварийное отключение', confirmBox('vward-off', 'Отключить VWARD? Сайты из списков пойдут напрямую, без VPN, реклама не будет фильтроваться. Включить обратно можно здесь же.', 'Отключить', true) +
    '<div class="panel-actions">' + (busy ? '<span class="muted">Выполняется…</span>' : off ? btn('vward-on', 'power', 'Включить VWARD', 'primary') : btn('ask', 'power', 'Отключить VWARD', 'danger', ' data-confirm="vward-off"')) + '</div>',
    { desc: 'На случай, если VWARD работает неправильно. VWARD останавливается и убирает из роутера всё своё: маршруты в VPN, AdGuard Home из DNS, перехват DNS. Роутер работает как обычный Keenetic. Программа и настройки остаются на месте, включается обратно одной кнопкой. Если Панель не открывается: по SSH выполните vward-off.sh (обратно - vward-off.sh on).' });
}

/* ---------- Wi-Fi клиенты ---------- */
// A section page shows a summary: the first few clients (those with a warning first); all of
// them, with a search, on their own page.
const WIFI_TOP = 5;
const wifiTop = list => list.slice().sort((a, b) => (b.health === 'WARNING') - (a.health === 'WARNING')).slice(0, WIFI_TOP);
const wifiClientRow = c => '<li class="row link" role="button" tabindex="0" data-go="w-' + esc(c.mac) + '"><div class="row-main"><b' + (c.host && (c.host.name || c.host.hostname) ? '' : ' class="mono"') + '>' + esc(wifiName(c.mac)) + '</b><small>' + esc(bandText(c.band)) + (c.host && c.host.ip ? ' · ' + esc(c.host.ip) : '') + (c.host && c.host.access === 'deny' ? ' · интернет запрещён' : '') + ' · ' + fmtInt(c.switches) + ' ' + plural(num(c.switches) || 0, 'переход', 'перехода', 'переходов') + (num(c.weak_5g) ? ' · слабый 5 ГГц ' + c.weak_5g + ' раз' : '') + (c.min_5g_rssi && c.min_5g_rssi !== '-' ? ' · мин. ' + esc(c.min_5g_rssi) + ' дБм' : '') + '</small></div><span class="pill ' + (c.health === 'WARNING' ? 'warn' : 'ok') + '">' + esc(recText(c)) + '</span>' + ico('chevron', 'chev') + '</li>';

const RENDER = {
  'd-control'() { return controlPage(); },
  ai() { return aiPage(); },
  overview() {
    const list = cardOrder.filter(id => editing || !hiddenCards.includes(id));
    const at = S.cached.status || S.loadedAt.status, ts = at ? new Date(at).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) : '—', busy = busyOn('overview');
    // While the page loads the icon spins; the text stays short so the bar never overflows.
    const line = busy ? (pageBusy.slow ? 'Роутер отвечает медленно…' : 'Обновление…') : S.errors.status ? (at ? 'Данные на ' + ts + ' · нет ответа роутера' : 'Нет ответа роутера') : 'Обновлено ' + ts;
    let html = '<div class="overview-bar"><span class="ob-time' + (busy && pageBusy.slow ? ' slow' : '') + '">' + line + '</span><button class="icon-btn' + (busy ? ' spinning' : '') + '" type="button" data-act="reload" aria-label="' + (busy ? 'Данные обновляются' : 'Обновить данные') + '">' + ico('refresh') + '</button><span class="spacer"></span>' +
      (editing ? btn('edit', 'check', 'Готово', 'small primary') : btn('edit', 'edit', 'Настроить', 'small')) + '</div>';
    if (editing) html += '<div class="edit-bar"><span>Вид</span><div class="segmented" role="group" aria-label="Вид карточек"><button type="button" data-view="grid" aria-pressed="' + (cardView === 'grid') + '">' + ico('platform') + 'Плитки</button><button type="button" data-view="list" aria-pressed="' + (cardView === 'list') + '">' + ico('logs') + 'Список</button></div><button class="link-btn" type="button" data-act="cards-reset">Сбросить</button></div>';
    html += '<div class="cards' + (editing ? ' editing' : '') + '" data-view="' + cardView + '">' + list.map((id, n) => {
      const c = cardData(id), h = hiddenCards.includes(id), k = CARD_KEY[id];
      // Nothing from the router yet: the card's frame with placeholders, filled in as the answer comes.
      if (!editing && S[k] == null && !S.errors[k]) return '<div class="card skel" data-card="' + id + '" aria-busy="true"><div class="card-icon">' + ico(c.icon) + '</div><div class="card-title">' + esc(c.title) + '</div><div class="sk sk-value"></div><div class="sk sk-sub"></div></div>';
      // The browser's copy from the last visit: shown at once, a little faded until the router answers.
      return '<div class="card' + (h ? ' is-hidden' : '') + (S.cached[k] && busyOn('overview') ? ' stale' : '') + '" data-card="' + id + '"' + (editing ? '' : ' role="button" tabindex="0" data-go="' + c.to + '"') + '><div class="card-icon">' + ico(c.icon) + '</div>' + cardAlert(c.pill) + '<div class="card-title">' + esc(c.title) + '</div><div class="card-value num" title="' + esc(c.value) + '">' + esc(c.value) + '</div><div class="card-sub" title="' + esc(c.sub) + '">' + esc(c.sub) + '</div>' +
        (c.meter != null ? '<div class="meter"><i data-width="' + c.meter + '"></i></div>' : '') +
        (editing ? '<div class="card-edit"><button class="icon-btn" type="button" data-card-move="' + id + ':up" aria-label="Выше"' + (n === 0 ? ' disabled' : '') + '>' + ico('up') + '</button><button class="icon-btn" type="button" data-card-move="' + id + ':down" aria-label="Ниже"' + (n === list.length - 1 ? ' disabled' : '') + '>' + ico('down') + '</button><button class="icon-btn" type="button" data-card-toggle="' + id + '" aria-label="' + (h ? 'Показать' : 'Скрыть') + ' карточку">' + ico(h ? 'eyeOff' : 'eye') + '</button></div>' : '') + '</div>';
    }).join('') + '</div>';
    return loadError(['status']) + chainNotice() + html;
  },

  wan() {
    const w = st().wan || {}, pr = prof(), stage = num(w.recovery_stage) || 0, guardOn = wanOn();
    const STAGE = { 1: 'сбой замечен, проверяем ещё раз', 2: 'запрошен новый адрес у провайдера', 3: 'интернет переподключается' };
    // The address check is the routing's (one place: «Маршрутизация», owner 2026-10-12).
    return loadError(['status']) +
      panel('Подключение', kv([
        ['Интерфейс', (pr.wan_interface || '—') + (pr.wan_device ? ' (' + pr.wan_device + ')' : '')],
        ['Кабель', isTrue(w.carrier) ? 'подключён' + (w.speed ? ' · ' + fmtSpeed(w.speed) : '') : 'нет сигнала'],
        ['IPv4', w.address || '—'],
        ['Шлюз', (w.gateway || '—') + (w.gateway ? (w.gateway_accessible ? ' · доступен' : ' · недоступен') : '')],
        ['DNS', w.dns_accessible ? 'отвечает' : 'не отвечает']
      ]), { right: st().wan && w.internet === false ? headPill('crit', 'Нет связи') : '' }) +
      panel('Домашняя сеть', kv([['Wi-Fi клиенты', !S.wifi ? '—' : !S.wifi.enabled ? 'сбор данных выключен' : fmtInt(((S.wifi.clients) || []).length) + ' ' + plural(((S.wifi.clients) || []).length, 'устройство', 'устройства', 'устройств'), '', 'wifi']])) +
      panel('Восстановление интернета', '<dl class="kv">' +
        ctrlRow('Восстанавливать автоматически', sw('data-cfg-wg', guardOn, 'Восстанавливать интернет автоматически', !cfgOk()), guardOn ? '' : 'выключено: при сбое воспользуйтесь кнопками ниже') +
        (guardOn ? ctrlRow('Проверять', sel('data-cfg-wanp="CHECK_INTERVAL_MIN"' + (cfgOk() ? '' : ' disabled'), 'Как часто проверять интернет', [[1, 'раз в минуту'], [2, 'раз в 2 минуты'], [5, 'раз в 5 минут'], [10, 'раз в 10 минут'], [15, 'раз в 15 минут'], [30, 'раз в 30 минут']], ((cfg().wan_guard || {}).params || {}).CHECK_INTERVAL_MIN || 1), 'при сбое - каждую минуту, пока связь не вернётся') : '') + '</dl>' +
        confirmBox('wg-off', 'Выключить автоматическое восстановление? При сбое интернет придётся восстанавливать кнопками.', 'Выключить', true) +
        (guardOn && stage ? '<p class="field-warn">Сейчас: ' + esc(STAGE[stage] || 'идёт восстановление') + '</p>' : '') +
        // The manual buttons in the same section: two sections of one name were one too many (owner 2026-10-17).
        wanNowRows() +
        kv([['История подключения', '', '', 'a-wan'], ['Дополнительно', '', '', 'd-wanrec', '', 'когда начинать, как часто переподключать, история']]),
        { desc: 'Пропал интернет - VWARD переподключит.' });
  },

  vpn() {
    const wg = st().wg || {}, list = wg.interfaces || [], managed = prof().tunnel_interface || '';
    // The switch: on and off right in the list (off asks first; the default tunnel is not
    // switched off - its lists would go direct).
    const tsw = t => '<span class="row-acts">' + sw('data-tunsw="' + esc(t.name) + '"', TUNBUSY[t.name] ? TUNBUSY[t.name] !== 'down' : !tunOff(t), (tunOff(t) ? 'Включить ' : 'Выключить ') + (t.description || t.name),
      t.name === managed || tunLost(t) || !cfgOk() || !!TUNBUSY[t.name]) + '</span>';
    const row = t => { const up = isTrue(t.connected); return '<li class="row link tun" role="button" tabindex="0" data-go="t-' + esc(t.name) + '"><div class="row-main"><b>' + esc(t.description || t.name) + '</b><small>' + (t.name === managed ? '<span class="st ok">по умолчанию</span>' + (tunSub(t) ? ' · ' : '') : '') + esc(tunSub(t) + (tqShort(t) ? ' · ' + tqShort(t) : '')) + '</small>' + (TUNERR[t.name] ? '<small class="st crit">' + esc(TUNERR[t.name]) + '</small>' : '') + '</div><span class="pill ' + tunPill(t)[0] + '">' + tunPill(t)[1] + '</span>' + tsw(t) + ico('chevron', 'chev') + '</li>'; };
    return loadError(['status']) + awgLostPanel() + nativePanel() +
      panel('Туннели', (list.length ? '<ul class="rows">' + list.map(row).join('') + '</ul>' : empty((st().wg || {}).interfaces_unknown ? 'Keenetic не ответил: список туннелей не загружен. Обновите страницу через несколько секунд.' : 'Туннелей нет')) +
        '<div class="panel-actions">' + btn('tunnel-create', 'plus', 'Добавить туннель', 'primary', cfgOk() ? '' : ' disabled') + '</div>' + resultBox('tunnels')) +
      tunnelsQualityPanel() + vpnGuardPanel();
  },

  routes() {
    const r = S.route || {}, ad = r.adaptive || {}, L = S.lists;
    // fix.38 (owner 12.11.2026, mock-up v2): four rows, one short line under each; «Мои домены»
    // is a list among «Доменные списки»; autopick's switch is on its own page.
    const lists = L ? (L.lists || []).filter(l => !svcOf(l.name)) : null;
    const doms = lists ? lists.reduce((n, l) => n + (num(l.count) || 0), 0) : 0;
    const svc = S.services && S.services.ok ? S.services.enabled || [] : null;
    const svcName = id => { const x = ((S.services && S.services.services) || []).find(c => c.id === id); return (x && x.title) || id; };
    const nAd = (ad.names || []).length || (S.config ? (cfgRoute().adaptive || []).length : num(ad.count) || 0);
    const auto = cfgRoute().adaptive_enabled !== false;
    return loadError(['route']) + sitePanel() +
      panel('Домены через VPN', kv([
        ['Доменные списки', lists ? fmtInt(lists.length) + ' ' + plural(lists.length, 'список', 'списка', 'списков') : '—', '', 'lists', '', lists ? fmtInt(doms) + ' ' + plural(doms, 'домен', 'домена', 'доменов') : ''],
        ['Сервисы', svc ? (svc.length ? fmtInt(svc.length) + ' включено' : 'выбрать') : '—', '', 'd-services', '',
          svc && svc.length ? svc.slice(0, 2).map(e => svcName(e.id || e)).join(', ') + (svc.length > 2 ? ' и другие' : '') : 'YouTube, ChatGPT и другие'],
        ['Автоподбор доменов', auto ? countText(nAd) : 'выключен', auto ? '' : 'warn', 'd-adaptive', '', ''],
        routeSourcesRow(r)
      ])) +
      panel('Подсети через VPN', kv([
        ['IP-категории', r.ip && r.ip.categories === 0 ? 'нет' : r.ip && r.ip.categories != null ? fmtInt(r.ip.active_count) + ' из ' + fmtInt(r.ip.categories) : '—', '', 'd-ipcats', '',
          r.ip && r.ip.managed_routes ? fmtInt(r.ip.managed_routes) + ' ' + plural(num(r.ip.managed_routes) || 0, 'подсеть', 'подсети', 'подсетей') : ''],
        ['Обновление IP-категорий', ipSyncStamp((r.ip || {}).last_sync), '', 'a-policy']
      ])) +
      panel('История', kv([['Сверка маршрутов', '', '', 'a-routing']]));
  },



  'd-wificlients'() {
    const w = S.wifi || {}, clients = w.clients || [];
    return loadError(['wifi']) + panel('Все клиенты', (clients.length > 8 ? '<label class="search-field list-filter">' + ico('search') + '<input class="input" type="search" data-list-filter placeholder="Имя, MAC или адрес" aria-label="Найти клиента" autocomplete="off"></label>' : '') +
      (clients.length ? '<ul class="rows" data-list-rows>' + clients.map(wifiClientRow).join('') + '</ul>' : empty(w.enabled ? WIFI_EMPTY[w.empty_reason] || 'Клиентов пока нет' : 'Сбор данных выключен')),
      { desc: fmtInt(clients.length) + ' ' + plural(clients.length, 'клиент', 'клиента', 'клиентов') + '. Рекомендации не применяются автоматически.' });
  },
  wifi() {
    const w = S.wifi || {}, clients = w.clients || [], sc = w.scheduler || {};
    const wc = Object.assign({ ENABLED: !!w.enabled, CONTROL_ENABLED: !!w.control_enabled, WINDOW_SEC: 86400, BAND_SWITCH_WARN: 20, WEAK_5G_RSSI: -75, WEAK_5G_SAMPLE_WARN: 5 }, cfg().wifi || {});
    return loadError(['wifi']) +
      panel('Wi-Fi клиенты', '<dl class="kv">' +
        ctrlRow('Сбор данных', sw('data-cfg-wifi="ENABLED"', wc.ENABLED, 'Сбор данных о Wi-Fi клиентах', !cfgOk()), 'переходы между 2.4 и 5 ГГц и уровень сигнала') +
        ctrlRow('Ручное управление', sw('data-cfg-wifi="CONTROL_ENABLED"', wc.CONTROL_ENABLED, 'Ручное закрепление диапазона', !cfgOk()), 'закрепление устройства за 2.4 или 5 ГГц по вашей команде') +
        '</dl>' + confirmBox('wifi-ctl-on', 'Разрешить закреплять устройства за диапазоном? Изменение применяется только по вашей команде для выбранного устройства.', 'Разрешить') + kv([
        ['Домашний сегмент', prof().lan_interface || '—'],
        ['Последний сбор', sc.last ? fmtStamp(sc.last) + (num(sc.rc) === 0 ? ' · успешно' : ' · код ' + sc.rc) : '—', '', 'a-wifi']
      ])) +
      // Only the ones worth a look here (warnings first); the full list has its own page.
      panel('Клиенты', clients.length ? '<ul class="rows">' + wifiTop(clients).map(wifiClientRow).join('') + '</ul>' +
        (clients.length > WIFI_TOP ? kv([['Все клиенты', fmtInt(clients.length), '', 'd-wificlients']]) : '') : empty(w.enabled ? WIFI_EMPTY[w.empty_reason] || 'Клиентов пока нет' : 'Сбор данных выключен'), { desc: 'Рекомендации не применяются автоматически.' }) +
      panel('Уведомления', '<dl class="kv">' +
        ctrlRow('Окно анализа', sel('data-cfg-wifi="WINDOW_SEC"', 'Окно анализа', withCur([[21600, '6 часов'], [43200, '12 часов'], [86400, '24 часа'], [172800, '2 суток'], [604800, '7 суток']], wc.WINDOW_SEC, ' с'), wc.WINDOW_SEC), 'за какой период считать переходы') +
        ctrlRow('Переходов между диапазонами', sel('data-cfg-wifi="BAND_SWITCH_WARN"', 'Переходов между диапазонами', withCur([[5, 'от 5'], [10, 'от 10'], [20, 'от 20'], [30, 'от 30'], [50, 'от 50']], wc.BAND_SWITCH_WARN, ''), wc.BAND_SWITCH_WARN)) +
        ctrlRow('Слабый сигнал 5 ГГц', sel('data-cfg-wifi="WEAK_5G_RSSI"', 'Слабый сигнал 5 ГГц', withCur([[-65, '-65 дБм'], [-70, '-70 дБм'], [-75, '-75 дБм'], [-80, '-80 дБм'], [-85, '-85 дБм']], wc.WEAK_5G_RSSI, ' дБм'), wc.WEAK_5G_RSSI), 'и ниже') +
        ctrlRow('Слабых замеров', sel('data-cfg-wifi="WEAK_5G_SAMPLE_WARN"', 'Слабых замеров', withCur([[3, 'от 3'], [5, 'от 5'], [10, 'от 10'], [20, 'от 20']], wc.WEAK_5G_SAMPLE_WARN, ''), wc.WEAK_5G_SAMPLE_WARN), 'за окно анализа') +
        '</dl>', { desc: 'Если устройство скачет между 2.4 и 5 ГГц.' });
  },

  ads() {
    // AdGuard Home first (fix.34): its state and the day's numbers; managing it is on its own page
    // (the reset and delete buttons stay there, not here).
    // The day's numbers are AdGuard Home's counters (slow): the overview's copy, else fetched after
    // the page is shown, not before it (check-ads-page-speed).
    const aghTopPanel = () => { const st1 = S.adsstats;
      if (!st1 && !adsStatsAsked) { adsStatsAsked = true; load('adsstats', true).then(render).catch(() => {}); }
      return panel('AdGuard Home', kv([S.ads ? ['Состояние', aghState()[1], aghState()[0], null, '', aghState()[2]] : null,
        st1 && st1.ok ? ['Запросов за сутки', fmtInt(st1.queries), '', 'd-querylog'] : null,
        st1 && st1.ok ? ['Заблокировано за сутки', fmtInt(st1.blocked) + blockedShare(st1.blocked, st1.queries), '', 'd-querylog', ' data-qfilter="blocked"'] : null,
        ['Управление AdGuard Home', 'Открыть', '', 'd-agh']])); };
    const a = S.ads || {}, c = a.counts || {}, s = a.settings || {}, j = a.jobs || {}, sc = a.scan || {}, ag = (S.security && S.security.external_services && S.security.external_services.adguard) || {};
    const aghHost = ag.address || location.hostname, aghUrl = ag.port ? 'http://' + aghHost + ':' + ag.port + '/' : '';
    const runMode = s.RUN_MODE || 'scheduled', pub = S.adspub || {};
    const pending = (num(pub.added) || 0) + (num(pub.removed) || 0);
    const cur = j.current || {}, busy = cur.state && cur.state !== 'IDLE';
    const off = adsOff();
    // ads-ui (owner 2026-11-01): switched on, waiting, recently checked, paused, failed and no data
    // are different things; green only for a check that finished recently, never for the wait.
    const now = adsNow(a, s, j, sc, off, runMode);
    const where = !pub.ok ? '—' : pub.mode === 'staged' ? 'не отправляются' : isTrue(s.AUTO_PUBLISH) ? 'автоматически' : 'после подтверждения';
    const recent = a.recent || [];
    // Order (owner 2026-11-01): VWARD's own check first, then lists and rules, then the blocking
    // check, AdGuard Home - an external program - last.
    return loadError(['ads']) + chainNotice() +
      panel('Проверка VWARD', (off ? '<p class="field-warn" data-go="c-ads-privacy-guard" role="button" tabindex="0">Компонент «Блокировка рекламы» выключен: проверки не идут. Включить его можно в «Компоненты».</p>'
        : '<dl class="kv">' + ctrlRow('Проверка рекламы и трекеров', sw('data-ads-pause', !a.paused, 'Проверка рекламы и трекеров', !S.ads), a.paused ? 'на паузе: новые домены не проверяются, задания ждут' : 'домены, пропущенные AdGuard Home, проверяются по источникам и признакам рекламы') + '</dl>') +
        kv([['Состояние', now[1], now[0], now[2]],
          ['Последняя проверка', sc.last_run ? fmtStamp(String(sc.last_run).replace(' ', 'T')) : 'ещё не было', '', 'a-ads', '',
            sc.last_run && sc.unique_allowed != null ? fmtInt(sc.unique_allowed) + ' ' + plural(num(sc.unique_allowed) || 0, 'домен', 'домена', 'доменов') + ' из ' + fmtInt(sc.allowed_records) + ' ' + plural(num(sc.allowed_records) || 0, 'запроса', 'запросов', 'запросов') + ', новых ' + fmtInt(sc.candidates) : ''],
          ['Заблокировано', fmtInt(c.blocked), '', 'd-blocked', '', 'признаны рекламой или трекерами'],
          ['На проверке', fmtInt(c.review), num(c.review) ? 'warn' : '', 'd-review', '', 'спорные: решение за вами'],
          ['Разрешено', fmtInt(c.allow), '', 'd-allowed', '', 'признаны безопасными'],
          ['Правила в AdGuard Home', where, pending ? 'warn' : '', 'd-adspub', '', pending ? 'не опубликовано: ' + pending : '']]) +
        '<div class="panel-actions">' + btn('ads-job', 'search', 'Проверить сейчас', 'primary', ' data-job="scan"') + '</div>' + resultBox('ads-job')) +
      panel('Списки и правила', kv([
        ['Последние решения', recent.length ? fmtInt(recent.length) : 'нет', '', 'd-adrecent'],
        ['Журнал запросов', 'последние 100', '', 'd-querylog'],
        ['Категории блокировки', (a.categories || []).filter(x => x.active).length + ' из ' + (a.categories || []).length + ' включены', '', 'd-adcats'],
        ['Мои правила', fmtInt((a.manual_rules || []).length), '', 'd-rules'],
        ['Источники', (a.sources || []).filter(x => x.mode === 'active').length + ' из ' + (a.sources || []).length + ' активны', '', 'd-sources'],
        S.https && S.https.ok ? ['HTTPS-фильтр', S.https.status && isTrue(S.https.status.ENABLED) ? 'включён' : 'выключен', '', 'd-https'] : null,
        ['Настройки проверки', ({ scheduled: 'по расписанию', dynamic: 'по запросам', manual: 'вручную' })[runMode] || '', '', 'd-adsettings']
      ])) + adsCheckPanel() + aghTopPanel() +
      // AdGuard Home is a program of its own: its page lives in «Компоненты» (no «Дополнительно», owner 2026-10-17).
      '';
  },
  'd-adrecent'() {
    const a = S.ads || {}, c = a.counts || {}, s = a.settings || {}, j = a.jobs || {}, sc = a.scan || {}, ag = (S.security && S.security.external_services && S.security.external_services.adguard) || {};
    const aghHost = ag.address || location.hostname, aghUrl = ag.port ? 'http://' + aghHost + ':' + ag.port + '/' : '';
    const runMode = s.RUN_MODE || 'scheduled', st1 = S.adsstats, pub = S.adspub || {}, g = S.agh;
    const pending = (num(pub.added) || 0) + (num(pub.removed) || 0);
    const cur = j.current || {}, busy = cur.state && cur.state !== 'IDLE';
    const now = !S.ads ? ['', 'загрузка…'] : a.paused ? ['warn', 'На паузе'] : !a.agh_connected ? ['warn', 'Нет подключения к AdGuard Home', 'd-agh'] :
      busy ? ['info', cur.type === 'scan' ? 'Проверяет новые домены' : 'Выполняет задание', 'd-jobs'] : num(j.queued) ? ['info', fmtInt(j.queued) + ' в очереди', 'd-jobs'] :
      ['ok', ({ scheduled: 'Ждёт следующей проверки', dynamic: 'Проверяет новые домены сразу', manual: 'Проверка только по кнопке' })[runMode] || 'Работает'];
    const where = !pub.ok ? '—' : pub.mode === 'staged' ? 'не отправляются' : isTrue(s.AUTO_PUBLISH) ? 'автоматически' : 'после подтверждения';
    const recent = a.recent || [];
    return loadError(['ads']) +
      panel('Решения агента', !S.ads ? empty('Загрузка…') : recent.length ? '<ul class="rows">' + recent.map(r => {
        const v = ADS_VERDICT[r.verdict] || ['', r.verdict];
        return '<li class="row"><div class="row-main"><b>' + esc(r.domain) + '</b><small>' + esc(ADS_REASON[r.reason] || r.reason || '') + (r.first_seen ? ' · замечен ' + esc(fmtTime(r.first_seen)) : '') + '</small></div><span class="pill ' + v[0] + '">' + esc(v[1]) + '</span>' +
          adsRuleBtn(r.domain, r.action === 'BLOCK' ? 'allow' : 'block') + '</li>';
      }).join('') + '</ul>' : empty('Проверок ещё не было'), { desc: 'Новые домены и что VWARD с ними сделал.' });
  },
  'd-adspub'() {
    const a = S.ads || {}, c = a.counts || {}, s = a.settings || {}, j = a.jobs || {}, sc = a.scan || {}, ag = (S.security && S.security.external_services && S.security.external_services.adguard) || {};
    const aghHost = ag.address || location.hostname, aghUrl = ag.port ? 'http://' + aghHost + ':' + ag.port + '/' : '';
    const runMode = s.RUN_MODE || 'scheduled', st1 = S.adsstats, pub = S.adspub || {}, g = S.agh;
    const pending = (num(pub.added) || 0) + (num(pub.removed) || 0);
    const cur = j.current || {}, busy = cur.state && cur.state !== 'IDLE';
    const now = !S.ads ? ['', 'загрузка…'] : a.paused ? ['warn', 'На паузе'] : !a.agh_connected ? ['warn', 'Нет подключения к AdGuard Home', 'd-agh'] :
      busy ? ['info', cur.type === 'scan' ? 'Проверяет новые домены' : 'Выполняет задание', 'd-jobs'] : num(j.queued) ? ['info', fmtInt(j.queued) + ' в очереди', 'd-jobs'] :
      ['ok', ({ scheduled: 'Ждёт следующей проверки', dynamic: 'Проверяет новые домены сразу', manual: 'Проверка только по кнопке' })[runMode] || 'Работает'];
    const where = !pub.ok ? '—' : pub.mode === 'staged' ? 'не отправляются' : isTrue(s.AUTO_PUBLISH) ? 'автоматически' : 'после подтверждения';
    const recent = a.recent || [];
    return loadError(['ads']) +
      panel('Применить в AdGuard Home', kv([['Не опубликовано', !pub.ok ? '—' : pending ? pending + ' ' + plural(pending, 'изменение', 'изменения', 'изменений') : 'всё опубликовано', pending ? 'warn' : 'ok', null, '', pub.ok && pub.mode === 'staged' ? 'режим подготовки: правила собираются, но не отправляются' : '']]) +
        '<dl class="kv">' + ctrlRow('Публиковать автоматически', sw('data-ads-autopub', isTrue(s.AUTO_PUBLISH), 'Публиковать автоматически', !S.ads), 'новые правила уходят в AdGuard Home без подтверждения') + '</dl>' +
        (confirmBox('ads-autopub', 'Публиковать правила автоматически? Новые правила будут применяться в AdGuard Home без вашего подтверждения.', 'Включить') ||
         confirmBox('ads-publish', 'Отправить правила в AdGuard Home? Они применятся сразу.', 'Опубликовать') || '<div class="panel-actions">' + btn('ask', 'check', 'Опубликовать правила', 'primary', ' data-confirm="ads-publish"') + '</div>'));
  },
  'd-adprobe'() {
    return panel('Подробности', inputBar({ form: 'ads-probe', label: 'Домен', id: 'adsProbe', value: PROBE ? PROBE.domain : '', placeholder: 'например, mc.yandex.ru', aria: 'Домен', busy: PROBE && !PROBE.done, icon: 'search', btn: 'Проверить' }) + probeResult(), { desc: 'Решение VWARD, источники и запросы по домену.' });
  },
  'd-adsettings'() {
    const a = S.ads || {}, c = a.counts || {}, s = a.settings || {}, j = a.jobs || {}, sc = a.scan || {}, ag = (S.security && S.security.external_services && S.security.external_services.adguard) || {};
    const aghHost = ag.address || location.hostname, aghUrl = ag.port ? 'http://' + aghHost + ':' + ag.port + '/' : '';
    const runMode = s.RUN_MODE || 'scheduled', st1 = S.adsstats, pub = S.adspub || {}, g = S.agh;
    const pending = (num(pub.added) || 0) + (num(pub.removed) || 0);
    const cur = j.current || {}, busy = cur.state && cur.state !== 'IDLE';
    const now = !S.ads ? ['', 'загрузка…'] : a.paused ? ['warn', 'На паузе'] : !a.agh_connected ? ['warn', 'Нет подключения к AdGuard Home', 'd-agh'] :
      busy ? ['info', cur.type === 'scan' ? 'Проверяет новые домены' : 'Выполняет задание', 'd-jobs'] : num(j.queued) ? ['info', fmtInt(j.queued) + ' в очереди', 'd-jobs'] :
      ['ok', ({ scheduled: 'Ждёт следующей проверки', dynamic: 'Проверяет новые домены сразу', manual: 'Проверка только по кнопке' })[runMode] || 'Работает'];
    const where = !pub.ok ? '—' : pub.mode === 'staged' ? 'не отправляются' : isTrue(s.AUTO_PUBLISH) ? 'автоматически' : 'после подтверждения';
    const recent = a.recent || [];
    return loadError(['ads']) +
      panel('Настройки проверки', '<dl class="kv">' +
        ctrlRow('Режим работы', sel('data-ads-set="RUN_MODE"', 'Режим работы', [['scheduled', 'По расписанию'], ['dynamic', 'По запросам'], ['manual', 'Вручную']], runMode), ({ scheduled: 'новые домены проверяются пачкой раз в интервал', dynamic: 'каждый новый домен проверяется сразу', manual: 'проверка только по кнопке' })[runMode]) +
        (runMode === 'scheduled' ? ctrlRow('Интервал', sel('data-ads-set="SCHEDULE_INTERVAL_MIN"', 'Интервал', [['5', '5 минут'], ['10', '10 минут'], ['30', '30 минут'], ['60', '1 час']], s.SCHEDULE_INTERVAL_MIN || '10')) : '') +
        ctrlRow('Обновлять источники автоматически', sw('data-ads-set="AUTO_SOURCE_UPDATE"', isTrue(s.AUTO_SOURCE_UPDATE), 'Обновлять источники автоматически', !S.ads), 'раз в ' + (s.SOURCE_UPDATE_INTERVAL_HOURS || 24) + ' ч') +
        ctrlRow('Новые правила применять к', sel('data-ads-set="AUTO_RULE_SCOPE"', 'Новые правила', [['exact', 'Только домену'], ['suffix', 'Домену и поддоменам']], s.AUTO_RULE_SCOPE || 'exact')) +
        '</dl>' + resultBox('ads'));
  },
  // fix.38 (owner 12.11.2026: «по порядочку, без дублей»): every part of VWARD once, from the
  // registry the router sends (st().parts), in its groups; a part's switch is here and on its own page
  // only; programs open their page (install, on/off with their tunnels).
  utils() {
    const P = st().parts, known = !!S.status && !S.cached.status;
    if (!P || !Array.isArray(P.list)) return (known ? loadError(['status']) : '') + panel('Компоненты', empty(S.status ? 'Роутер не прислал список частей: обновите VWARD' : 'Загрузка…'));
    const missing = [];
    const groups = (P.groups || []).map(g => {
      const rows = P.list.filter(p => p.group === g).map(p => {
        // Programs not installed fold into one line (owner 02.11); VWARD's own core stays in its group.
        if (p.installed === false && (p.kind === 'module' || p.kind === 'service' && p.id !== 'routing-core')) { missing.push(partRow(p)); return ''; }
        return partRow(p);
      }).filter(Boolean);
      const confirms = P.list.filter(p => p.group === g && p.switch === 'component' && comp(p.id)).map(p => compConfirm(comp(p.id))).join('');
      return rows.length ? panel(g, '<dl class="kv">' + rows.join('') + '</dl>' + confirms,
        g === 'Обслуживание' && !P.all_extras ? { desc: 'Облегчённая VWARD: работают VPN и автоподбор доменов, остальное включается по одному.' } : null) : '';
    }).join('');
    return (known ? loadError(['status']) : '') + agentsPanel() + groups +
      (missing.length ? '<details class="block missing-comps"><summary class="block-head"><h2>' + ico('box', 'head-ico') + 'Не установлены (' + missing.length + ')</h2></summary><div class="panel"><dl class="kv">' + missing.join('') + '</dl></div></details>' : '');
  },
  // Cards of the components added on 01.11.2026: what is known, nothing that cannot be done yet.
  'd-dnsmasq'() { return compCard('dnsmasq-full', 'dnsmasq', 'dnsmasq', 'Альтернатива AdGuard Home в DNS-цепочке. После установки остаётся выключенным, пока вы не выберете его в настройках DNS.'); },
  'd-singbox'() { return compCard('sing-box-go', 'sing-box', 'singbox', 'Движок для протоколов, которые он доказанно поддерживает. После установки выключен; туннели остаются на своих движках, пока вы их не переведёте.'); },
  'd-dnscap'() {
    const cp = (st().services || {}).dnscap || {}, c = compStatus(dnscapFacts(cp, !!S.status && !S.cached.status));
    return loadError(['status']) + panel('Захват DNS-запросов', kv([['Состояние', c[1], c[0]],
      ['Программа', cp.installed ? 'vward-dnscap' : 'не найдена'], ['Процесс', cp.running ? 'запущен' : 'не запущен'],
      ['Подтверждение работы', cp.fresh === true ? 'домены обработаны за последние 15 минут' : 'нет данных за 15 минут']]),
      { desc: 'Узнаёт домены из DNS-запросов устройств для автоподбора. «Работает» - только когда за последние 15 минут обработаны домены.' }) +
      mgmtNote('Служба компонента «Маршрутизация»: включается и выключается вместе с ним (Компоненты → Маршрутизация). Удалить отдельно нельзя - без неё не работает автоподбор.');
  },
  'd-doh'() {
    const d = (st().services || {}).doh || {}, c = compStatus(dohFacts(d, !!S.status && !S.cached.status));
    return loadError(['status']) + panel('DoH-клиент', kv([['Состояние', c[1], c[0]], ['Программа', d.installed ? 'https-dns-proxy' : 'не найдена'], ['Процесс', d.running ? 'запущен' : 'не запущен'],
      ['Подтверждение работы', 'проверки ответов пока нет']]), { desc: 'Отправляет запросы своего Smart DNS через DoH.' });
  },
  'd-awg'() {
    const w = S.awg;
    if (!w) return panel('AmneziaWG', empty('Загрузка…'));
    const tl = w.tunnels || [];
    const row = t => '<li class="row link" role="button" tabindex="0" data-go="t-' + esc(t.name) + '"><div class="row-main"><b>' + esc(t.description || t.name) + '</b><small>' +
      esc([t.endpoint, t.handshake != null ? 'рукопожатие ' + agoText(t.handshake) : 'рукопожатия нет', t.rss_kb ? 'память ' + Math.round(t.rss_kb / 1024) + ' МБ' : ''].filter(Boolean).join(' · ')) +
      '</small></div><span class="pill ' + (t.running && t.handshake != null ? 'ok' : 'warn') + '">' + (t.running ? (t.handshake != null ? 'Работает' : 'Нет связи') : 'Не работает') + '</span>' + ico('chevron', 'chev') + '</li>';
    return awgLostPanel() + nativePanel() + panel('AmneziaWG', kv([
        // Not installed: plain text, no link (ROADMAP 5.0a); «Установить» is in «Управление».
        w.installed ? ['Программа', 'vward-awg ' + (w.version || ''), '', 'https://github.com/Ziegfe1d/VWARD/tree/dev/tools/vward-awg', '', 'процессор ' + (w.arch || '—')]
          : ['Программа', 'не установлена', '', null, '', 'кнопка «Установить» ниже или сама при первом туннеле'],
        ['Туннели', fmtInt(tl.length)]]) + (tl.length ? '<ul class="rows">' + tl.map(row).join('') + '</ul>' : ''),
      { desc: 'Держит туннели AmneziaWG 3.x, пока прошивка Keenetic их не умеет (до KeeneticOS 5.2). В Keenetic такой туннель - подключение OpkgTun. Скорость ниже встроенного WireGuard.' }) + compPanel('awg') + soonPanel('awg');
  },
  'd-agents'() {
    const am = agentsMode(), pr = ((S.config && S.config.agents) || {}).proposed || [];
    return loadError(['config']) + agentsPanel() +
      panel('Режим', '<p class="panel-desc">Песочница: агент работает, но только пишет в журнал, что сделал бы. Вкл: сам исправляет.</p>' +
        '<dl class="kv">' + ctrlRow('Все агенты', modeSlider('all', agentList().every(a => am[a[0]] === 'watch') ? 'watch' : 'act', 'Режим всех агентов'), '', 'stack') + '</dl>' +
        // fix.38.1 (owner 12.11.2026): one switch an agent, on - «Вкл», off - «Песочница»; no stack of sliders.
        '<dl class="kv">' + agentList().map(a => ctrlRow(a[1], sw('data-agent-act="' + a[0] + '"', am[a[0]] === 'act', a[1] + ': сам исправляет', !cfgOk()), am[a[0]] === 'act' ? 'вкл: сам исправляет' : 'песочница: записывает, что сделал бы')).join('') + '</dl>' + resultBox('agents')) +
      panel('События и реакции', kv(AGENT_PROTOCOLS.map(r => [r[1], am[r[0]] === 'act' ? 'Вкл' : 'Песочница', am[r[0]] === 'act' ? 'ok' : 'info', null, '', agentName(r[0]) + ': ' + r[2] + ' → ' + r[3]])),
        { desc: 'Что агент замечает и что делает. В песочнице он только записывает это в «Что агент сделал бы».' }) +
      panel('Работают всегда', kv(AGENT_LOCKED.map(r => [r[0], 'Включено', 'ok', null, '', r[1]])),
        { desc: 'Без этого роутер может остаться без интернета или без доступа к Панели, поэтому песочница их не останавливает.' }) +
      panel('Что агент сделал бы', proposedHtml(pr),
        { desc: 'Записи песочницы: что агент сделал бы во «Вкл». Одно и то же действие записывается не чаще раза в час.' }) + soonPanel('d-agents');
  },
  // The VLESS module's programs (Xray), one row a tunnel: moved here from the tunnel's page,
  // which only says so when the program has stopped (owner 2026-10-17).
  'd-vless'() {
    if (!S.awg) return panel('Модуль VLESS', empty('Загрузка…'));
    const tl = (S.awg.vless && S.awg.vless.tunnels) || [];
    const row = t => '<li class="row link" role="button" tabindex="0" data-go="t-' + esc(t.name) + '"><div class="row-main"><b>' + esc(tunLabel(t.name)) + '</b><small>' +
      esc(['Xray', t.rss_kb != null ? 'память ' + fmtKB(t.rss_kb) : ''].filter(Boolean).join(' · ')) + '</small></div><span class="pill ' + (t.running ? 'ok' : 'warn') + '">' +
      (t.running ? 'Работает' : 'Остановлен') + '</span></li>';
    return panel('Модуль VLESS', tl.length ? '<ul class="rows">' + tl.map(row).join('') + '</ul>' : empty('Туннелей VLESS нет'),
      { desc: 'Держит туннели VLESS и Trojan: программа Xray на каждый туннель.' }) +
      (compButtons('vless').length ? compPanel('vless') : mgmtNote('Программа Xray ставится сама при добавлении первого туннеля VLESS или Trojan; отключать пока нечего.'));
  },
  'd-agh'() {
    const a = S.ads || {}, g = S.agh, st1 = S.adsstats, ag = (S.security && S.security.external_services && S.security.external_services.adguard) || {};
    const aghHost = ag.address || location.hostname, aghUrl = ag.port ? 'http://' + aghHost + ':' + ag.port + '/' : '';
    const e = (S.ext && S.ext.agh) || {};
    return loadError(['ads']) +
      // One state, the same as in «Компоненты» (aghState); the link only while AdGuard Home answers.
      panel('AdGuard Home', kv([S.ads ? ['Состояние', aghState()[1], aghState()[0], null, '', aghState()[2]] : null,
          aghUrl && g && g.ok ? ['Веб-интерфейс', aghHost + ':' + ag.port, '', aghUrl] : null,
          g && g.ok && g.protection != null ? ['Фильтрация', g.protection ? 'Включена' : 'Выключена', g.protection ? 'ok' : 'warn'] : null,
          st1 && st1.ok ? ['Запросов за сутки', fmtInt(st1.queries), '', 'd-querylog'] : null,
          st1 && st1.ok ? ['Заблокировано за сутки', fmtInt(st1.blocked) + blockedShare(st1.blocked, st1.queries), '', 'd-querylog', ' data-qfilter="blocked"'] : null,
          // The program's own version (the official build is not the Entware package's number).
          ['Версия', (g && g.version) || ((e.official || {}).installed) || (e.installed ? extVer(e.installed) : '—'), '', 'u-agh', '', e.available ? 'доступна ' + extVer(e.available) : '']]),
        { desc: 'Блокирует рекламу по своим фильтрам; VWARD дочищает пропущенное.' }) +
      compPanel('agh') + aghConnectPanel(a) + aghSettingsPanel(a) + dnsGuardPanel(a) +
      (a.agh_connected ? panel('Связь с Keenetic', aghClientsRows(a) + routeDnsRows(a)) : '');
  },
  'd-dnsex'() {
    const g = (S.ads && S.ads.dns_guard) || {}, ex = (g.exclude || '').split(',').filter(Boolean), hosts = g.hosts || [];
    return loadError(['ads']) + panel('Устройства', !S.ads ? empty('Загрузка…') : hosts.length ? '<dl class="kv">' + hosts.map(h =>
      ctrlRow(h.name || h.mac, sw('data-dnsex="' + esc(h.mac) + '"', ex.includes(h.mac), 'Исключить ' + (h.name || h.mac)), h.mac + (h.online ? '' : ' · не в сети'))).join('') + '</dl>' : empty('Keenetic не вернул список устройств'),
      { desc: 'Эти устройства защита не трогает.' });
  },

  system() {
    const s = st(), r = s.router || {}, g = s.storage || {}, dg = S.diag && S.diag.checks || [], fl = g.flash || null;
    const bad = dg.filter(x => x.status !== 'PASS').length;
    // fix.38.1 (owner 12.11.2026): VWARD first - its updates and state; the router itself below.
    return loadError(['status', 'update', 'ext']) + RENDER.updatesPanel() +
      panel('Состояние', kv([
        (() => { const off = ((S.config && S.config.components) || []).filter(x => x.enabled === false).map(x => compName(x.id));
          // fix.38.1: the number on the right, the names under it (six lines on a phone before).
          return ['Управление', off.length ? 'выключено ' + off.length : 'всё включено', off.length ? 'warn' : '', 'd-control', '', off.length ? off.join(', ') : 'все выключатели VWARD']; })(),
        agentsRow(),
        ['Диагностика', dg.length ? (dg.length - bad) + ' из ' + dg.length + ' в норме' : 'не запускалась', bad ? 'warn' : '', 'd-diag'],
        (() => { const sc = stabScore(stabRows(S.stab, 86400), stabChecks(S.stab)); return ['Стабильность', sc && sc.index != null ? sc.index + '% за сутки' : S.stab ? 'не проверено' : '…', stabCls(sc && sc.index), 'd-stability']; })()
      ])) +
      panel('Хранилище', kv([['Свободно', fmtKB(g.free_kb) + ' из ' + fmtKB(g.total_kb)], ['Файловая система', g.filesystem || '—'],
        (() => { const f = !fl ? ['', '—'] : fl.errors ? ST.bad : ST.on;
          return ['Флешка', f[1], f[0], '', '', !fl ? '' : fl.errors ? 'ошибок: ' + fl.errors + (fl.io ? ', из них чтения и записи: ' + fl.io : '') + (fl.where && fl.where.length ? ' · ' + fl.where.join(', ') : '') : 'ошибок нет']; })(),
        (() => { const it = g.integrity || null;
          // The maintenance agent's daily look at the program files (fix.28.3).
          if (!it || !it.at) return ['Целостность файлов', 'ещё не проверялась', '', 'a-integrity', '', 'раз в сутки, ночью'];
          return ['Целостность файлов', it.spoiled ? 'испорчено: ' + it.spoiled : 'в порядке', it.spoiled ? 'crit' : '', 'a-integrity', '',
            'проверено ' + fmtInt(it.files) + ' ' + plural(it.files, 'файл', 'файла', 'файлов') + ' · ' + fmtStamp(it.at) + (it.unknown ? ' · изменено неизвестно кем: ' + it.unknown : '')]; })(),
        ['Файлы VWARD', 'открыть', '', 'd-files']])) +
      cleanupPanel() +
      backupPanel() +
      panel('Устройство', kv([
        ['Модель', r.model || '—'], ['KeeneticOS', r.version || '—'],
        ['Веб-интерфейс Keenetic', prof().lan_address || location.hostname, '', 'http://' + (prof().lan_address || location.hostname) + '/'],
        ['Время работы', fmtUptime(r.uptime_sec)]
      ])) +
      soonPanel('system') + resetPanel() + offPanel();
  },

  updatesPanel() {
    const p = plat(), u = S.update || {}, pend = u.pending || {}, x = S.ext || {}, fw = x.firmware || {}, agh = x.agh || {};
    const pk = x.packages || [], checked = x.checked_at ? fmtStamp(x.checked_at) : '';
    const pon = pend.present && pend.feed !== 'other', vwardVal = pon ? 'доступна ' + (verHuman(pend.version, pend.sequence) || 'новая версия') : (verHuman(p.version, p.last_sequence) || '—');
    const aghVal = agh.available ? 'доступна ' + extVer(agh.available) : agh.installed ? extVer(agh.installed) : S.ext ? 'не установлен' : '—';
    const fwVal = !x.firmware ? (S.ext ? 'нет данных' : '—') : fw.update_available ? 'доступна новая' : fw.title || fw.release;
    return panel('Обновления', kv([
        ['VWARD', vwardVal, pon ? 'info' : '', 'u-vward', '', pon ? 'установлена ' + (verHuman(p.version, p.last_sequence) || '—') : autoText(isTrue(p.auto_apply))],
        ['AdGuard Home', aghVal, agh.available ? 'info' : '', 'u-agh', '', agh.available ? 'установлена ' + extVer(agh.installed) : autoText(x.auto && x.auto.agh)],
        ['Прошивка Keenetic', fwVal, fw.update_available ? 'info' : '', 'u-fw', '', fw.channel ? 'канал ' + fwChannel(fw.channel) + ' · ' + autoText(fw.auto_update) : ''],
        ['Пакеты Entware', pk.length ? pk.length + ' ' + plural(pk.length, 'обновление', 'обновления', 'обновлений') : S.ext && !x.checked_at ? 'не проверялись' : 'актуальны', pk.length ? 'info' : '', 'u-opkg', '', x.installed_count ? 'установлено ' + x.installed_count + ' · ' + autoText(x.auto && x.auto.entware) : '']
      ]) + '<div class="panel-actions">' + allCheckBtn() + '</div>' + resultBox('ext'),
      { desc: checked ? 'Последняя проверка: ' + checked + '. Проверка идёт сама раз в сутки, во время установки обновлений VWARD.' : 'Проверка идёт сама раз в сутки, во время установки обновлений VWARD.' });
  },

  'u-agh'() {
    const x = S.ext || {}, a = x.agh || {}, run = x.run || {}, o = a.official || {};
    // The official build (Entware's one cannot run on some processors): VWARD installs the version it pins.
    const official = !!o.installed, newer = official && o.pinned && o.pinned !== o.installed;
    const broken = !official && !!(st().services || {}).adguard_broken && o.pinned;
    const conf = confirmBox('ext-upgrade', 'Обновить AdGuard Home до ' + extVer(a.available) + '? DNS прервётся на несколько секунд. Перед установкой сохранится копия, при сбое вернётся прежняя версия.', 'Обновить') ||
      confirmBox('agh-official', (newer ? 'Обновить AdGuard Home до ' + o.pinned : 'Установить официальную сборку AdGuard Home ' + o.pinned) + '? Скачивается с GitHub AdGuard (около 10 МБ), контрольные суммы сверяются. DNS прервётся на минуту. Прежний файл сохранится.', newer ? 'Обновить' : 'Установить');
    const act = official ? (newer ? btn('ask', 'save', 'Обновить', 'primary', ' data-confirm="agh-official"') : '')
      : broken ? btn('ask', 'save', 'Установить официальную сборку', 'primary', ' data-confirm="agh-official"')
      : a.available ? btn('ask', 'save', 'Обновить', 'primary', ' data-confirm="ext-upgrade" data-pkg="adguardhome-go"') : '';
    return loadError(['ext']) +
      panel('AdGuard Home', kv([
        ['Установлена', official ? o.installed + ', официальная сборка' : a.installed ? extVer(a.installed) : 'не установлен', broken ? 'crit' : ''],
        ['Доступна', official ? (newer ? o.pinned : 'новее нет') : a.available ? extVer(a.available) : 'новее нет', (official ? newer : a.available) ? 'info' : '']
      ]) + (conf || (act ? '<div class="panel-actions">' + act + '</div>' : '')) + extRunNote(run, 'adguardhome-go') + resultBox('ext'),
      { desc: official ? 'Сборка AdGuard для процессора этого роутера: сборка Entware на нём не запускается. Новые версии приходят с обновлениями VWARD.'
        : broken ? 'Программа AdGuard Home не запускается на процессоре этого роутера. Официальная сборка AdGuard работает.' : 'AdGuard Home обновляется через Entware.' }) +
      panel('Настройки', '<dl class="kv">' + ctrlRow('Обновлять автоматически', sw('data-ext-auto="agh"', x.auto && x.auto.agh, 'Обновлять AdGuard Home автоматически'), 'раз в сутки, во время установки обновлений VWARD') + '</dl>') +
      extHistory(x.history, h => h.name === 'adguardhome-go');
  },

  'u-fw'() {
    const x = S.ext || {}, f = x.firmware;
    if (!f) return loadError(['ext']) + panel('Прошивка Keenetic', empty(S.ext ? 'Роутер не сообщил данные о прошивке. Нажмите «Проверить всё» в разделе «Система».' : 'Загрузка…'));
    // Keenetic's check-update does not always list the channels (a Viva 2026-10-12: an empty
    // select with a stray frame): the three channels it has are offered anyway.
    const known = (f.channels || []).filter(c => ['stable', 'preview', 'draft'].includes(c.name));
    const chans = known.length ? known : ['stable', 'preview', 'draft'].map(name => ({ name }));
    const cur = (f.channels || []).find(c => c.name === f.channel) || {};
    return loadError(['ext']) +
      panel('Прошивка Keenetic', kv([
        ['Установлена', f.release ? (f.title || '') + ' (' + f.release + ')' : 'роутер пока не сообщил'],
        ['Доступна', f.update_available == null ? 'роутер пока не сообщил' : f.update_available ? (f.available && f.available.release ? (f.available.title || '') + ' (' + f.available.release + ')' : cur.version || 'новая версия') : 'установлена последняя', f.update_available ? 'info' : ''],
        ['Проверена роутером', fwStamp(f.checked)]
      ]), { desc: f.update_available ? 'Прошивку ставит Keenetic, роутер перезагрузится.' : '' }) +
      panel('Настройки', '<dl class="kv">' +
        ctrlRow('Обновлять автоматически', sw('data-fw-auto', f.auto_update, 'Обновлять прошивку автоматически'), 'Keenetic сам установит новую версию канала, роутер перезагрузится') +
        ctrlRow('Канал обновлений', sel('data-fw-channel', 'Канал обновлений', chans.map(c => [c.name, fwChannel(c.name)]), f.channel), (f.channel === 'stable' ? 'проверенные версии' : 'тестовые версии, возможны ошибки') + (cur.version ? ' · ' + cur.version : '')) +
        '</dl>' + confirmBox('fw-channel', 'Перейти на тестовый канал? Тестовые прошивки могут работать с ошибками.', 'Перейти', true),
        { desc: 'Те же настройки, что в Keenetic.' });
  },

  'u-opkg'() {
    const x = S.ext || {}, pk = x.packages || [], run = x.run || {};
    const c = confirm && confirm.id === 'ext-upgrade' ? pk.find(p => p.name === confirm.pkg) : null;
    const rows = pk.map(p => '<div class="kv-row" data-key="' + esc(p.name) + '"><dt>' + esc(p.name) + '<span class="hint">' + esc(extVer(p.installed) + ' → ' + extVer(p.available)) + (p.critical ? ' · системный пакет' : '') + '</span></dt><dd>' +
      btn('ask', 'save', 'Обновить', 'small', ' data-confirm="ext-upgrade" data-pkg="' + esc(p.name) + '"') + '</dd></div>').join('');
    return loadError(['ext']) +
      panel('Пакеты Entware', pk.length ? '<dl class="kv">' + rows + '</dl>' +
        (c ? confirmBox('ext-upgrade', (c.critical ? 'Системный пакет: если он сломается, может пропасть SSH или командная строка. ' : '') + 'Обновить ' + c.name + ' до ' + extVer(c.available) + '? Перед установкой сохранится копия, при сбое вернётся прежняя версия.', 'Обновить', c.critical) : '') +
        extRunNote(run) + resultBox('ext') :
        empty(x.checked_at ? (x.feed_ok === false ? 'Список пакетов Entware не скачался. Повторите проверку позже.' : 'Все пакеты актуальны.') : 'Пакеты ещё не проверялись.') + '<div class="panel-actions">' + extCheckBtn('Проверить') + '</div>' + resultBox('ext'),
        { desc: 'Программы Entware, на которых работает VWARD.' }) +
      panel('Настройки', '<dl class="kv">' + ctrlRow('Обновлять автоматически', sw('data-ext-auto="entware"', x.auto && x.auto.entware, 'Обновлять пакеты Entware автоматически'), 'кроме системных пакетов: их - только вручную') + '</dl>') +
      extHistory(x.history, h => h.name !== 'adguardhome-go');
  },

  'u-vward'() {
    const p = plat(), u = S.update || {}, al = u.allowed || {}, pend = u.pending || {};
    const uc = cfg().update || {}, mode = updModeShown || (!isTrue(p.auto_apply) ? 'manual' : uc.apply_window === 'any' ? 'auto' : 'schedule'), feed = uc.feed;
    const winStart = uc.safe_window_start || String(p.safe_window || '').split(/\s*[-–]\s*/)[0];
    const interval = uc.check_interval_seconds || p.check_interval_seconds;
    const acts = [];
    if (panelVerNew) acts.push(btn('panel-reload', 'refresh', 'Перезагрузить страницу', 'primary'));
    if (al.check || runningId === 'updates') acts.push(btn('update-op', 'refresh', runningId === 'updates' ? 'Проверяем…' : 'Проверить', 'primary', ' data-op="check"' + (runningId === 'updates' ? ' disabled' : '')));
    if (al.apply) acts.push(btn('ask', 'save', 'Установить', 'primary', ' data-confirm="update-apply"'));
    if (al.retry) acts.push(btn('ask', 'refresh', 'Повторить', '', ' data-confirm="update-retry"'));
    if (al.rollback) acts.push(btn('ask', 'undo', 'Откатить', 'danger', ' data-confirm="update-rollback"'));
    if (al.recover) acts.push(btn('ask', 'alert', 'Восстановить', 'danger', ' data-confirm="update-recover"'));
    const conf = confirmBox('update-apply', 'Установить обновление ' + verHuman(pend.version, pend.sequence) + '? Компоненты перезапустятся.', 'Установить') ||
      confirmBox('update-retry', 'Повторить установку обновления?', 'Повторить') ||
      confirmBox('update-rollback', 'Вернуть предыдущую версию? Компоненты перезапустятся.', 'Откатить', true) ||
      confirmBox('update-recover', 'Восстановить прерванное обновление?', 'Восстановить', true);
    return loadError(['update', 'status']) +
      panel('Состояние', kv([
        ['Версия', verHuman(p.version, p.last_sequence) || '—', '', 'd-notes', '', lastApplyNote(u.last_apply, u.last_method)],
        // Found on the other channel before the switch: the updater will not install it here (owner 2026-11-01).
        pend.present && pend.feed === 'other' ? ['Найдено на другом канале', verHuman(pend.version, pend.sequence) || '—', '', 'd-notes', '', 'не установится, пока выбран текущий канал'] :
        pend.present ? ['Доступно', verHuman(pend.version, pend.sequence) + (pend.priority ? ' · ' + ({ ROUTINE: 'обычное', IMPORTANT: 'важное', CRITICAL: 'критическое' }[String(pend.priority).toUpperCase()] || pend.priority) : ''), 'info', 'd-notes'] : null,
        feedCheckRow(p),
        p.last_health_check ? ['Проверка после установки', fmtStamp(p.last_health_check), '', 'a-updater'] : null
      ]) + (conf || (acts.length ? '<div class="panel-actions even">' + acts.join('') + '</div>' : '')) + resultBox('updates'),
      { right: ['FAILED', 'RECOVERY_REQUIRED'].includes(u.phase || p.phase) ? headPill('crit', phaseText(u.phase || p.phase)) : '' }) +
      panel('Настройки обновлений', '<dl class="kv">' +
        ctrlRow('Установка обновлений', choiceSlider('upd-mode', [['auto', 'Сама'], ['schedule', 'По времени'], ['manual', 'Вручную']], mode, 'Установка обновлений'), ({ auto: 'сразу после проверки подписи', schedule: 'критические исправления - сразу', manual: 'только проверка и уведомление' })[mode]) +
        (mode === 'schedule' ? ctrlRow('Время установки', sel('data-cfg-upd="install_time"', 'Время установки', withCur(HOURS, winStart, ''), winStart), 'обновление ставится при первой проверке после этого времени') : '') +
        ctrlRow('Интервал проверки', sel('data-cfg-upd="check_interval_seconds"', 'Интервал проверки', withCur([[900, '15 минут'], [1800, '30 минут'], [3600, '1 час'], [10800, '3 часа'], [21600, '6 часов'], [43200, '12 часов'], [86400, '24 часа']], interval, ' с'), interval)) +
        ctrlRow('Способ обновления', choiceSlider('upd-method', [['full', 'Целиком'], ['files', 'Изменённые файлы']], uc.update_method === 'files' ? 'files' : 'full', 'Способ обновления'),
          uc.update_method === 'files' ? 'скачиваются только изменённые файлы; если не вышло - пакет целиком' : 'скачивается весь пакет; если не вышло - изменённые файлы') +
        (FEED_HINT[feed] ? ctrlRow('Канал', choiceSlider('upd-feed', [['main', 'Стабильная'], ['dev', 'Разработка']], feed, 'Канал обновлений'), FEED_HINT[feed]) : '') +
        '</dl>' + (feed === 'custom' ? kv([['Канал', 'свой адрес манифеста', '', null, '', 'задан в update.conf на роутере']]) : '') +
        confirmBox('feed-dev', 'Перейти на канал «Разработка»? Это сборки в разработке: в них возможны ошибки. Вернуться на «Стабильная» можно в любой момент - обновления придут, когда стабильный выпуск догонит установленную версию.', 'Перейти', true) +
        confirmBox('feed-main', 'Перейти на канал «Стабильная»? Установленная версия останется. Обновление придёт, когда выйдет стабильный выпуск новее неё; более старые сборки не ставятся.', 'Перейти'));
  },

  settings() {
    const sec = S.security || {}, l = sec.listener || {}, au = S.auth || {};
    return loadError(['security']) +
      // Four short choices: a slider like the Wi-Fi bands (owner 2026-10-17).
      panel('Оформление', '<p class="panel-desc" data-key="Тема">Тема' + (theme === 'time' ? ': светлая с 07:00 до 20:00, тёмная ночью' : '') + '</p>' + themeSlider() +
        '<div class="panel-actions">' + btn('view-reset', 'reset', 'Вид Панели по умолчанию') + '</div>',
        { desc: 'Тема, меню и порядок карточек хранятся в этом браузере.' }) +
      panel('Вход в Панель', '<dl class="kv">' + ctrlRow('Вход по учётной записи Keenetic', sw('data-auth', !!(au.enabled || authForm), 'Вход по учётной записи Keenetic', !S.auth),
          au.enabled ? (au.logged_in ? 'вы вошли как ' + au.login + ' · сессия ' + au.session_hours + ' ч' : 'нужен вход') : 'выключен: Панель открыта всем в домашней сети') +
        (S.auth && au.devices_only != null ? ctrlRow('Только зарегистрированные устройства', sw('data-auth-devices', !!au.devices_only, 'Только зарегистрированные устройства', !au.devices_only && (au.device || {}).state !== 'registered'), devicesHint(au)) : '') + '</dl>' +
        (authForm && !au.enabled ? '<form class="inline-form multi" data-form="auth-enable">' + formLabel('Логин и пароль от Keenetic') + '<input class="input" name="login" placeholder="логин Keenetic" aria-label="Логин" autocomplete="username"><input class="input" name="password" type="password" placeholder="пароль" aria-label="Пароль" autocomplete="current-password"><button class="btn primary" type="submit">' + ico('check') + 'Включить вход</button></form><p class="panel-desc">Введите логин и пароль от веб-интерфейса роутера: вход включится, только если роутер их примет.</p>' : '') +
        confirmBox('auth-off', 'Выключить вход? Панель снова будет открыта любому устройству в домашней сети.', 'Выключить', true) +
        kv([['Адрес Панели', (l.address || location.hostname) + ':' + (l.port || location.port || '80')]]) +
        (au.enabled && au.logged_in ? '<div class="panel-actions">' + btn('logout', 'logout', 'Выйти') + '</div>' : ''),
      { desc: au.enabled ? 'Сессия действует ' + (au.session_hours || 12) + ' ч. После 5 неверных попыток вход блокируется на 5 минут.' + (au.devices_only ? ' Устройства вне списка Keenetic входят логином и паролем Keenetic. Если доступ потерян: по SSH выполните /opt/bin/vward-console-config.sh console-devices 0.' : '') : '' }) +
      panel('Меню', '<div class="tabbar preview" data-key="Разделы на панели">' + tabsHtml() + '</div><dl class="kv">' + PAGES.map(p => {
        const on = tabIds.includes(p.id), i = tabIds.indexOf(p.id);
        return ctrlRow(p.title, (on ? '<span class="order-btns"><button class="icon-btn" type="button" data-move="' + p.id + ':up" aria-label="Выше"' + (i === 0 ? ' disabled' : '') + '>' + ico('up') + '</button><button class="icon-btn" type="button" data-move="' + p.id + ':down" aria-label="Ниже"' + (i === tabIds.length - 1 ? ' disabled' : '') + '>' + ico('down') + '</button></span>' : '') + sw('data-tabpick="' + p.id + '"', on, 'Показывать «' + p.title + '» на панели'));
      }).join('') + '</dl>', { desc: 'До ' + TAB_MAX + ' разделов и их порядок. Остальные разделы - в меню «Ещё».' }) +
      soonPanel('settings');
  },

  logs() {
    // owner 12.11.2026: nothing loads by itself; «Показать журнал» asks for the last N entries in one
    // request, «Показать ещё» for more; the filters sit under the button by the search, the
    // actions are buttons with words under the journal.
    const shown = !!logShown[logTab], text = shown ? S.logs[logTab] : null, busy = !!LOGRUN[logTab];
    const set = logTab !== 'all' || !logImportant || logN !== 50 || !logNewest || !logWrap;
    const fbtn = '<button class="icon-btn filter-btn' + (set ? ' on' : '') + '" type="button" data-act="log-filters" aria-expanded="' + logFilters + '" aria-label="Фильтр" title="Фильтр">' + ico('sliders') + '</button>';
    const chips = (label, attr, opts, cur) => '<p class="chips-label">' + label + '</p><div class="chips" role="group" aria-label="' + label + '">' +
      opts.map(o => '<button type="button" ' + attr + ' data-v="' + o[0] + '" aria-pressed="' + (String(o[0]) === String(cur)) + '">' + esc(o[1]) + '</button>').join('') + '</div>';
    const sum = [logLabel(logTab) === 'Все' ? 'Все источники' : logLabel(logTab), logImportant ? 'важное' : 'все записи', 'по ' + logN].concat(logTab === 'all' && !logNewest ? ['сначала старые'] : []).join(' · ');
    const name = logTab === 'all' ? 'все журналы' : 'журнал «' + logLabel(logTab) + '»';
    return '<section class="block" aria-label="Журналы"><div class="panel">' + searchBar('log-search', logQuery, 'Найти в журнале', fbtn) +
      (logFilters ? '<p class="chips-label">Источник</p><div class="chips" role="group" aria-label="Источник журнала">' + LOG_VIEW.map(t => '<button type="button" data-log="' + t.id + '" aria-pressed="' + (t.id === logTab) + '">' + esc(t.label) + '</button>').join('') + '</div>' +
        chips('Важность', 'data-act="log-view"', [['important', 'Важное'], ['all', 'Все']], logImportant ? 'important' : 'all') +
        chips('Записей за раз', 'data-act="log-n"', LOG_STEPS.map(n => [n, String(n)]), logN) +
        (logTab === 'all' ? chips('Порядок', 'data-act="log-order"', [['newest', 'Сначала новые'], ['oldest', 'Сначала старые']], logNewest ? 'newest' : 'oldest') : '') +
        chips('Длинные строки', 'data-act="log-wrap"', [['1', 'Переносить'], ['0', 'В одну строку']], logWrap ? '1' : '0') +
        (logTab === 'all' && shown ? '<div id="logSrc">' + logSources() + '</div>' : '')
        : '<p class="panel-desc log-sum">' + esc(sum) + '</p>') +
      (shown ? '<div class="logfeed' + (logWrap ? '' : ' nowrap') + '" id="logBox">' + logFeed(logPick(text, logQuery)) + '</div>' +
          (LOGMORE[logTab] && !logQuery ? '<div class="panel-actions log-more-row">' + btn('log-more', '', 'Показать ещё ' + logN, 'small') + '</div>' : '')
        : '<div class="empty" id="logBox">' + (busy ? 'Загрузка записей…' : 'Журнал не загружен. «Показать журнал» принесёт последние ' + logN + ' ' + plural(logN, 'запись', 'записи', 'записей') + ' одним запросом.') + '</div>') +
      '<p class="field-warn" id="logWarn"' + (shown && LOGWARN[logTab] ? '' : ' hidden') + '>' + esc(LOGWARN[logTab] || '') + '</p>' +
      (shown ? '<p class="log-at" id="logAt">' + esc(logStamp(logTab)) + '</p>' : '') +
      '<div class="panel-actions"><button class="btn primary log-show' + (busy ? ' spinning' : '') + '" type="button" data-act="log-show"' + (busy ? ' disabled aria-busy="true"' : '') + '>' + ico(shown ? 'refresh' : 'logs') + (shown ? 'Обновить журнал' : 'Показать журнал') + '</button></div>' +
      '<div class="panel-actions even log-acts">' + btn('log-save', 'download', 'Скачать') + btn('log-share', 'share', 'Поделиться') + btn('log-save-all', 'archive', 'Архивировать') +
        btn('ask', 'trash', 'Очистить', 'danger', ' data-confirm="log-clear" data-what="' + esc(logTab) + '"') + '</div>' +
      confirmBox('log-clear', 'Очистить ' + name + '? Записи удалятся с роутера, архивы останутся.', 'Очистить', true) +
      '</div></section>' + journalPanel();
  },

  'd-diag'() {
    const d = S.diag, map = { 'console-api': 'settings', opt: 'system', lighttpd: 'c-console', crond: 'd-cron', supervisor: 'd-cron', adguard: 'ads', adaptive: 'c-route-engine', updater: 'u-vward', config: 'u-vward', wan: 'wan', wg: 'vpn', smartdns: 'lists' };
    const sv = st().services || {};
    return panel('Задания по расписанию', kv([['Задания по расписанию', sv.crond && sv.supervisor ? 'Работают' : sv.crond ? 'Агент компонентов остановлен' : 'расписание не работает', sv.crond && sv.supervisor ? 'ok' : 'crit', 'd-cron']]),
        { desc: 'Нажмите, чтобы открыть задания.' }) +
      panel('Диагностика', (d && d.checks ? '<ul class="rows">' + d.checks.map(x => { const to = x.id === 'smartdns' && /IP-категория/.test(x.detail || '') ? 'd-ipcats' : map[x.id]; return '<li class="row' + (to ? ' link" role="button" tabindex="0" data-go="' + to + '"' : '"') + '><div class="row-main"><b>' + esc(x.label) + '</b><small>' + esc(x.detail || '') + '</small></div><span class="pill ' + (x.status === 'PASS' ? 'ok' : x.status === 'FAIL' ? 'crit' : 'warn') + '">' + (x.status === 'PASS' ? 'Работает' : x.status === 'FAIL' ? 'Не работает' : x.status === 'FOREIGN' ? 'Чужой маршрут' : 'Внимание') + '</span>' + (to ? ico('chevron', 'chev') : '') + '</li>'; }).join('') + '</ul>' : empty(S.errors.diag ? 'Диагностика не выполнена: ' + S.errors.diag : 'Загрузка…')) +
      diagRunNote() + '<div class="panel-actions">' + btn('diag-run', 'check', DIAG_RUN && DIAG_RUN.busy ? 'Проверка выполняется…' : 'Запустить проверку', 'primary', DIAG_RUN && DIAG_RUN.busy ? ' disabled aria-busy="true"' : '') + '</div>') +
      panel('Журналы', kv([['Технические журналы', 'для сохранения и отправки', '', 'logs']]), { desc: 'Журналы как есть, для диагностики.' });
  },
  'd-stability'() {
    const d = S.stab;
    if (!d) return loadError(['stab']) + panel('Стабильность', empty('Загрузка…'));
    if (!d.ok) return panel('Стабильность', empty(errText(d)));
    const st = d.state || {}, chk = stabChecks(d), day = stabScore(stabRows(d, 86400), chk), week = stabScore(stabRows(d, 7 * 86400));
    const sen = d.sentinel || {};
    const senText = sen.running ? 'работает' : sen.installed ? 'остановлен' : 'ещё не установлен';
    const idx = sc => sc && sc.index != null ? sc.index + '%' : 'не проверено';
    const times = (n, one, few, many) => n + ' ' + plural(n, one, few, many);
    const watch = (st.watch || []).map(w => [STAB_WATCH(w.name), w.pid ? fmtKB(w.rss_kb) : 'не запущен',
      w.pid ? (w.limit_kb && w.rss_kb > w.limit_kb ? 'crit' : 'ok') : '', '', '',
      [w.pid && w.base_kb > 0 ? 'обычно ' + fmtKB(w.base_kb) : '', w.pid ? 'процессор ' + (w.cpu_x100 / 100).toFixed(1).replace('.', ',') + '%' : '',
       'предел ' + fmtKB(w.limit_kb), w.downs ? 'пропадал ' + times(w.downs, 'раз', 'раза', 'раз') : '', w.leaks ? times(w.leaks, 'утечка', 'утечки', 'утечек') : ''].filter(Boolean).join(' · ')]);
    // Load (owner 02.11): the total in hours and minutes, the average of one run and the share of
    // the router's uptime; a run of 5 s and more is marked.
    const up = num((st().router || {}).uptime_sec);
    const cpu = (d.cpu || []).slice().sort((a, b) => b.cs - a.cs).map(c => { const sec = c.cs / 100, per = c.runs ? sec / c.runs : 0;
      return [STAB_JOB[c.component] || c.component, fmtDur(sec), per >= 5 ? 'warn' : '', '', '',
        [times(c.runs, 'запуск', 'запуска', 'запусков'), c.runs ? '≈ ' + fmtDur(per) + ' за запуск' : '', up ? (Math.round(sec / up * 1000) / 10).toString().replace('.', ',') + ' % времени работы' : ''].filter(Boolean).join(' · ')]; });
    // Memory (owner 02.11): every running program of VWARD and AdGuard Home, resident and in swap.
    const mem = d.mem || {}, progs = (d.progs || []).slice().sort((a, b) => (b.rss_kb + b.swap_kb) - (a.rss_kb + a.swap_kb));
    const memRow = mem.MemTotal ? ['Память роутера', 'свободно ' + fmtKB(mem.MemAvailable) + ' из ' + fmtKB(mem.MemTotal), mem.MemAvailable < mem.MemTotal * 0.15 ? 'warn' : '', '', '',
      mem.SwapTotal ? 'swap занят ' + fmtKB(mem.SwapTotal - mem.SwapFree) + ' из ' + fmtKB(mem.SwapTotal) : 'swap нет'] : null;
    const progRows = progs.map(p => [PROG_NAME[p.name] || p.name, fmtKB(p.rss_kb), '', '', '', p.swap_kb ? 'ещё ' + fmtKB(p.swap_kb) + ' в swap' : '']);
    const ev = (d.events || []).map(e => '<li class="row"><div class="row-main"><b>' + esc(stabEvent(e.what)) + '</b><small>' + esc(e.at) + '</small></div></li>').join('');
    return panel('Итог', kv([
      ['За сутки', idx(day), stabCls(day && day.index)], ['За неделю', idx(week), stabCls(week && week.index)],
      ['DNS отвечал', day && day.dns != null ? pct(day.dns) : 'не проверено', day && day.dns != null && day.dns < 0.99 ? 'warn' : '', '', '', day ? (day.dnsOk + day.dnsFail) + ' проверок' + (st.dns_ms_avg >= 0 ? ' · в среднем ' + st.dns_ms_avg + ' мс' : '') : ''],
      ['Починки', day ? (day.ok + day.bad ? day.ok + ' из ' + (day.ok + day.bad) + ' помогли' : 'не понадобились') : '—', day && day.bad ? 'warn' : ''],
      ['Сбои программ VWARD', day ? (day.downs + day.leaks ? [day.downs ? times(day.downs, 'пропадание', 'пропадания', 'пропаданий') : '', day.leaks ? times(day.leaks, 'утечка', 'утечки', 'утечек') : ''].filter(Boolean).join(', ') : 'не было') : '—', day && (day.downs || day.leaks) ? 'warn' : ''],
      ['Часов с нехваткой памяти', day ? String(day.low) : '—', day && day.low ? 'warn' : ''],
      ...stabCheckRows(chk)
    ]), { desc: 'Индекс за сутки: DNS отвечал 28%, программы VWARD не падали 14%, починки помогли 14%, памяти хватало 14%, туннель передавал трафик 10%, обновления скачивались 10%, HTTPS работал 5%, Keenetic отвечал вовремя 5%. Что не проверено, в индекс не входит; проверено меньше половины - «не проверено». За неделю - только данные агента реального времени. 95% и выше — норма.' }) +
      panel('Агент реального времени', kv([
        ['Состояние', senText, sen.running ? 'ok' : 'warn'],
        ['Память роутера', st.mem_kb >= 0 ? 'свободно ' + fmtKB(st.mem_kb) : '—', st.mem_low ? 'crit' : '', '', '', st.mem_min_kb >= 0 ? 'меньше всего было ' + fmtKB(st.mem_min_kb) : ''],
        ['Нагрузка', st.load_x100 != null ? (st.load_x100 / 100).toFixed(2).replace('.', ',') : '—', st.busy ? 'warn' : '', '', '', st.busy ? 'роутер занят: необязательная работа VWARD ждёт' : st.load_max_x100 ? 'больше всего ' + (st.load_max_x100 / 100).toFixed(2).replace('.', ',') : ''],
        ['Событий обработано', String(st.events || 0), '', '', '', (st.link_events || 0) + ' от интерфейсов']
      ]), { desc: sen.running ? 'Следит за памятью и нагрузкой каждые 2 секунды, за интерфейсами — мгновенно, за DNS — каждые 30 секунд.' : 'Агент ставится сам в течение часа; пока его нет, проверки идут раз в минуту.' }) +
      (progRows.length || memRow ? panel('Программы VWARD', kv([memRow].concat(progRows)), { desc: 'Память каждой работающей программы VWARD и AdGuard Home (резидентная и в swap), одним способом.' }) : '') +
      (watch.length ? panel('Под наблюдением агента', kv(watch)) : '') +
      (cpu.length ? panel('Нагрузка', kv(cpu), { desc: 'Суммарное время работы процессора каждого задания VWARD с загрузки роутера' + (up ? ' (роутер работает ' + fmtUptime(up) + ')' : '') + '. Отмечены задания дольше 5 с за запуск.' }) : '') +
      panel('Последние события', ev ? '<ul class="rows">' + ev + '</ul>' : empty('Событий пока нет'));
  },
  'd-cron'() {
    const sv = st().services || {}, cr = S.cron;
    const jobs = cr && cr.ok ? cr.jobs : [];
    // A job without its component (someone else's line in VWARD's crontab) is not a link.
    const row = x => { const comp = JOB_COMPONENT[x.name] || x.component, on = !comp || compOn(comp), ok = x.rc === 0;
      return '<li class="row' + (comp ? ' link" role="button" tabindex="0" data-go="c-' + esc(comp) : '') + '"><div class="row-main"><b>' + esc(JOB_TAGS[x.tag] || JOB_NAMES[x.name] || x.name) + '</b><small>' + esc(cronText(x.schedule)) + ' · ' + esc(fmtStamp(x.last) || 'ещё не запускалось') + '</small></div>' +
        '<span class="pill ' + (!on ? 'warn' : x.rc == null ? '' : ok ? 'ok' : 'crit') + '">' + (!on ? 'Выключен' : x.rc == null ? 'Нет данных' : ok ? 'Успешно' : 'Ошибка, код ' + x.rc) + '</span>' + (comp ? ico('chevron', 'chev') : '') + '</li>'; };
    return panel('Планировщик', kv([['Планировщик заданий', sv.crond ? 'Работает' : 'Не работает', sv.crond ? 'ok' : 'crit'], ['Агент компонентов', sv.supervisor ? 'Работает' : 'Не работает', sv.supervisor ? 'ok' : 'crit']])) +
      panel('Задания', !cr ? empty('Загрузка…') : !cr.ok ? empty(errText(cr)) : jobs.length ? '<ul class="rows">' + jobs.map(row).join('') + '</ul>' : empty('Задания не найдены'),
        { desc: 'Задания VWARD по расписанию.' });
  },
  // fix.38.1: «Мои домены» is VWARD's own list's page; old addresses land there.
  'd-mydomains'() { setTimeout(() => go(myListId(), null, 'replace'), 0); return ''; },
  'd-force'() { setTimeout(() => go(myListId(), null, 'replace'), 0); return ''; },
  lists() {
    if (!S.lists) return loadError(['lists']) + panel('Доменные списки', empty('Загрузка…'));
    const L = S.lists, items = (L.lists || []).filter(l => !svcOf(l.name)), own = cfgRoute().group || prof().policy_group;
    // fix.38 (owner 12.11.2026, mock-up v3): the Panel's own look, the way each list goes in words
    // (no «авто», «мои» badges), one search over every list's domains; «Мои домены» is the list
    // VWARD adds found domains to; the path is chosen on a list's own page.
    // fix.38.1 (owner 12.11.2026): technical words - «маршрут: VPN», «список VWARD», «не под управлением VWARD».
    const words = l => fmtInt(l.count) + ' ' + plural(l.count, 'домен', 'домена', 'доменов') + ' · маршрут: ' + listRoute(l) +
      (l.name === own ? ' · список VWARD' : !l.managed ? ' · не под управлением VWARD' : '');
    const row = l => '<li class="row link" role="button" tabindex="0" data-go="l-' + esc(l.name) + '" data-find="' + esc((l.domains || []).join(' ').toLowerCase()) + '">' +
      '<div class="row-main"><b>' + esc(l.description || l.name) + '</b><small>' + esc(words(l)) + '</small>' +
      (l.smartdns_conflict || (l.auto && viaIs(l, 'vpn')) ? '<small class="st warn">' + (l.smartdns_conflict ? 'конфликт со Smart DNS' : 'переведён на VPN автоматически') + '</small>' : '') + '</div>' +
      ico('chevron', 'chev') + '</li>';
    if (!items.length) return cfgNote() + panel('Доменные списки', empty('Доменных списков пока нет') +
      '<p class="panel-desc">VWARD сам чужих списков не переносит. Список появляется, когда вы включаете сервис или отправляете домен через VPN в «Проверке адреса».</p>' +
      '<div class="panel-actions"><button class="btn small" type="button" data-go="d-services">' + ico('plus') + 'Сервисы</button></div>') + soonPanel('lists');
    const mine = items.filter(l => l.managed && l.name !== own), modes = mine.map(listMode), common = modes.length && modes.every(m => m === modes[0]) ? modes[0] : '';
    const ordered = items.filter(l => l.name === own).concat(items.filter(l => l.name !== own));
    const pick = !cfgRoute().group && policyGroupRow();
    return cfgNote() + listDupPanel(items) + listEmptyPanel(items) + (pick ? panel('Список VWARD', '<dl class="kv">' + pick + '</dl>', { desc: 'Список Keenetic, в который VWARD добавляет найденные домены.' }) : '') +
      panel('Доменные списки', '<label class="search-field list-filter">' + ico('search') + '<input class="input" type="search" data-list-filter placeholder="Найти домен" aria-label="Найти домен во всех списках" autocomplete="off"></label>' +
        '<ul class="rows" data-list-rows>' + ordered.map(row).join('') + '</ul>' +
        (mine.length > 1 ? '<dl class="kv">' + ctrlRow('Все списки VWARD', choiceSlider('list-mode-all', listAllModes(mine), common, 'Маршрут всех списков VWARD'), common ? '' : 'у списков разные маршруты', 'stack') + '</dl>' : '') +
        (LISTBULK.busy ? '<p class="panel-desc">' + esc(LISTBULK.busy) + '</p>' : '') + resultBox('lists'),
        { desc: 'Доменные списки Keenetic (object-group fqdn) и маршрут каждого.' }) + soonPanel('lists');
  },

  'd-wanrec'() {
    const gp = Object.assign({ CONFIRM_FAILURES: 3, RENEW_COOLDOWN: 600, BOUNCE_COOLDOWN: 1800, MAX_RENEW_HOUR: 3, MAX_BOUNCE_HOUR: 2, MAX_BOUNCE_DAY: 6 }, (cfg().wan_guard || {}).params);
    const gsel = (key, label, opts, unit) => sel('data-cfg-wanp="' + key + '"' + (cfgOk() ? '' : ' disabled'), label, withCur(opts, gp[key], unit || ''), gp[key]);
    const counts = n => Array.from({ length: n }, (x, i) => [i + 1, String(i + 1)]);
    const hist = wanHistory((S.wanhist && S.wanhist.text) || '');
    return cfgNote() +
      panel('Расписание', '<dl class="kv">' + ctrlRow('Неудачных проверок подряд', gsel('CONFIRM_FAILURES', 'Неудачных проверок подряд', counts(10)), 'столько раз подряд интернет не отвечает, прежде чем VWARD вмешается') + '</dl>') +
      panel('Смена адреса', '<dl class="kv">' +
        ctrlRow('Не чаще раза в', gsel('RENEW_COOLDOWN', 'Пауза между запросами адреса', [[60, '1 минуту'], [300, '5 минут'], [600, '10 минут'], [1800, '30 минут'], [3600, 'час']], ' с')) +
        ctrlRow('Не больше в час', gsel('MAX_RENEW_HOUR', 'Запросов адреса в час', counts(10))) + '</dl>',
        { desc: 'Первый шаг, связь почти не прерывается.' }) +
      panel('Переподключение', '<dl class="kv">' +
        ctrlRow('Не чаще раза в', gsel('BOUNCE_COOLDOWN', 'Пауза между переподключениями', [[300, '5 минут'], [900, '15 минут'], [1800, '30 минут'], [3600, 'час'], [7200, '2 часа']], ' с')) +
        ctrlRow('Не больше в час', gsel('MAX_BOUNCE_HOUR', 'Переподключений в час', counts(6))) +
        ctrlRow('Не больше в сутки', gsel('MAX_BOUNCE_DAY', 'Переподключений в сутки', counts(24))) + '</dl>',
        { desc: 'Второй шаг: интернет пропадёт секунд на 10.' }) +
      panel('История', !S.wanhist ? empty('Загрузка…') : hist.length ? '<ul class="rows">' + hist.map(h => '<li class="row"><div class="row-main"><b>' + esc(h.what) + '</b><small>' + esc(h.when) + '</small></div><span class="st ' + (h.ok ? 'ok' : 'crit') + '">' + (h.ok ? 'выполнено' : 'не удалось') + '</span></li>').join('') + '</ul>' : empty('Восстановлений ещё не было'),
        { desc: 'Последние действия.' });
  },
  'd-smartdns'() {
    const L = S.lists;
    if (!L) return loadError(['lists']) + panel('Smart DNS', empty('Загрузка…'));
    const sd = L.smartdns_domains || [], src = L.smartdns_sources || {}, ok = cfgOk();
    const from = d => ((src.adguard || []).includes(d) ? 'AdGuard Home' : '') + ((src.keenetic || []).includes(d) ? ((src.adguard || []).includes(d) ? ' и ' : '') + 'Keenetic' : '');
    return cfgNote() +
      panel('Агент Smart DNS', '<dl class="kv">' + ctrlRow('Агент Smart DNS', sw('data-smartdns-guard', L.smartdns_guard !== false, 'Агент Smart DNS', !ok), 'Автоподбор не отправляет эти домены в VPN') + '</dl>' +
        (L.doh_limit ? kv([['Строк DNS-over-HTTPS в Keenetic', fmtInt(L.doh_used || 0) + ' из ' + fmtInt(L.doh_limit), L.doh_used >= L.doh_limit ? 'warn' : '']]) : ''),
        { desc: 'Домены Smart DNS должны идти мимо VPN.' }) +
      panel('Домены Smart DNS', sd.length ? '<ul class="rows">' + sd.map(d => '<li class="row"><div class="row-main"><b>' + dom(d) + '</b><small>' + esc(from(d) || smartdnsWhere(L)) + '</small></div></li>').join('') + '</ul>' : empty('Smart DNS не настроен'),
        { desc: (src.adguard || []).length ? 'Заданы в AdGuard Home (Upstream DNS), VWARD их не меняет.' : 'Заданы в Keenetic (DNS-over-HTTPS), VWARD их не меняет.' });
  },
  'd-services'() {
    const V = S.services;
    if (!V) return loadError(['services']) + panel('Сервисы', empty('Загрузка…'));
    if (!V.ok) return panel('Сервисы', empty(errText(V)));
    const on = V.enabled || [], cats = V.categories || [], all = V.services || [], ok = cfgOk() && !SVC.busy;
    const shown = all.filter(x => SVC.cat === 'on' ? on.some(e => e.id === x.id) : !SVC.cat || x.category === SVC.cat);
    const chips = [['on', 'Включённые']].concat(cats.map(c => [c.id, c.title]));
    const row = x => {
      const e = on.find(v => v.id === x.id), n = x.count + ' ' + plural(x.count, 'домен', 'домена', 'доменов');
      return '<li class="row"><div class="row-main"><b>' + esc(x.title) + '</b><small>' + (e ? esc(svcVia(e)) + ' · ' : '') + esc(x.too_big ? 'слишком много доменов для Keenetic' : n) + '</small></div>' +
        '<span class="row-acts">' + sw('data-svc="' + esc(x.id) + '"', !!e, (e ? 'Выключить ' : 'Включить ') + x.title, !ok || x.too_big) +
        (e ? '<button class="icon-btn" type="button" data-go="s-' + esc(x.id) + '" aria-label="Настройки ' + esc(x.title) + '" title="Настройки">' + ico('chevron') + '</button>' : '') + '</span></li>';
    };
    const tuns = (st().wg && st().wg.interfaces) || [], catObj = cats.find(c => c.id === SVC.cat);
    const catPin = catObj && tuns.length >= 2 ? panel('Туннель', '<dl class="kv">' + ctrlRow(catObj.title, sel('data-svc-cat="' + esc(catObj.id) + '"' + (ok ? '' : ' disabled'), 'Туннель категории ' + catObj.title,
      [['auto', 'Автоматически']].concat(tuns.map(t => [t.name, tunLabel(t.name)])), svcCatTunnel(catObj.id) || 'auto'),
      svcCatTunnel(catObj.id) ? 'сервисы категории на «Автоматически» идут через этот туннель' : 'VWARD проверяет каждый сервис через туннели сам') + '</dl>',
      { desc: 'Сервис с закреплённым туннелем остаётся на своём.' }) : '';
    return cfgNote() + actionRecovery(V.recovery) + catPin + panel('Сервисы', '<label class="search-field list-filter">' + ico('search') + '<input class="input" type="search" data-list-filter placeholder="Найти сервис" aria-label="Найти сервис" autocomplete="off"></label>' +
      '<div class="chips" role="group" aria-label="Категория">' + chips.map(c => '<button type="button" data-act="svc-cat" data-cat="' + esc(c[0]) + '" aria-pressed="' + (SVC.cat === c[0]) + '">' + esc(c[1]) + '</button>').join('') + '</div>' +
      resultBox('svc') + (shown.length ? '<ul class="rows" data-list-rows>' + shown.map(row).join('') + '</ul>' : empty(SVC.cat === 'on' ? 'Пока ничего не включено' : 'Нет сервисов')),
      { desc: 'Включённый сервис идёт через VPN. В Keenetic он появится доменным списком со своим названием.' });
  },
  'd-rsources'() {
    const got = ((S.route && S.route.sources) || []).reduce((m, x) => (m[x.id] = x, m), {});
    const row = x => {
      const g = got[x.id], state = !g ? 'ещё не обновлялся' : g.ok ? 'обновлён ' + fmtStamp(g.ts) + ' · ' + fmtInt(g.count) + ' ' + x.unit
        : 'не скачался ' + fmtStamp(g.ts) + (g.count ? ' · работает прошлая копия: ' + fmtInt(g.count) + ' ' + x.unit : '');
      return '<li class="row"><div class="row-main"><b>' + esc(x.title) + '</b><small>' + esc(x.what) + '</small><small>' + esc(x.why) + '</small>' +
        '<small class="st' + (g && !g.ok ? ' warn' : '') + '">' + (g && !g.ok ? ico('alert') : '') + esc(state) + '</small></div>' +
        '<span class="row-acts"><a class="icon-btn" href="' + esc(x.url) + '" target="_blank" rel="noopener" aria-label="Открыть источник ' + esc(x.title) + '" title="Открыть источник">' + ico('external') + '</a></span></li>';
    };
    const V = S.services, svcRow = V && V.ok ? '<li class="row"><div class="row-main"><b>Каталог сервисов iplist</b><small>Домены сервисов для страницы «Сервисы», по категориям.</small>' +
        '<small class="st">' + esc((V.from === 'daily' ? 'обновлён ' + fmtStamp(V.checked) : 'копия из обновления VWARD') + ' · ' + fmtInt((V.services || []).length) + ' сервисов') + '</small></div>' +
        '<span class="row-acts"><a class="icon-btn" href="' + esc(V.source_url || 'https://github.com/rekryt/iplist') + '" target="_blank" rel="noopener" aria-label="Открыть источник iplist" title="Открыть источник">' + ico('external') + '</a></span></li>' : '';
    return loadError(['route']) + panel('Источники', '<ul class="rows">' + ROUTE_SOURCES.map(row).join('') + svcRow + '</ul>' +
      kv([['Каталог обновлён', catalogStamp(((S.route && S.route.domains) || {}).last_update)]]) +
      '<div class="panel-actions">' + btn('refresh-hints', 'refresh', 'Обновить сейчас') + '</div>' + resultBox('routes'),
      { desc: 'Подсказки для автоподбора; каталог обновляется ежедневно в 04:25. Решение по домену принимает автоподбор.' });
  },
  'd-adaptive'() {
    // fix.38 (owner 12.11.2026, mock-up v3/v4): the switch; «Сейчас» - what autopick does, live while
    // the page is open; the domains with search, filter and order; a tap - its way «Авто | VPN |
    // Провайдер» and «Проверить». The Panel's own look, words instead of badges.
    const ad = (S.route && S.route.adaptive) || {}, raw = ad.names || [];
    const names = raw.length ? raw : (cfgRoute().adaptive || []).map(d => ({ d: typeof d === 'string' ? d : d.domain || '' }));
    const on = cfgRoute().adaptive_enabled !== false, day = Date.now() - 86400000;
    const when = n => { const t = Date.parse(n.added || ''); return isNaN(t) ? '' : new Date(t).toDateString() === new Date().toDateString() ? 'с сегодня ' + adHm(t) : 'с ' + new Date(t).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }); };
    const sub = n => n.streak > 0 ? 'через VPN · <span class="st ok">скоро вернётся напрямую</span>' : esc(('через VPN ' + when(n)).trim());
    let shown = names.filter(n => (ADV.show === 'all' || (ADV.show === 'back' ? n.streak > 0 : Date.parse(n.added || '') > day)));
    if (ADV.order === 'az') shown = shown.slice().sort((a, b) => a.d.localeCompare(b.d));
    const lim = shown.slice(0, ADV.lim);
    const row = n => { const open = ADV.open === n.d;
      return '<li class="row link' + (open ? ' open' : '') + '" role="button" tabindex="0" data-act="ad-open" data-dom="' + esc(n.d) + '"><div class="row-main"><b>' + dom(n.d) + '</b><small>' + sub(n) + '</small></div>' + ico(open ? 'down' : 'chevron', 'chev') +
        (open ? '<div class="row-x">' + choiceSlider('ad-way', [['auto', 'Авто'], ['vpn', 'VPN'], ['direct', 'Провайдер']], 'auto', 'Как открывать ' + n.d) +
          '<p class="panel-desc">Авто: VWARD проверяет, открывается ли домен напрямую, и сам вернёт его. VPN - всегда через VPN. Провайдер - напрямую, автоподбор его больше не берёт.</p>' +
          '<div class="panel-actions"><button class="btn small" type="button" data-act="ad-probe" data-dom="' + esc(n.d) + '">' + ico('search') + 'Проверить и адреса</button></div></div>' : '') + '</li>'; };
    const chips = (k, opts) => '<div class="chips" role="group">' + opts.map(o => '<button type="button" data-act="ad-chip" data-k="' + k + '" data-v="' + o[0] + '" aria-pressed="' + (ADV[k] === o[0]) + '">' + o[1] + '</button>').join('') + '</div>';
    const fopen = ADV.filters, fset = ADV.show !== 'all' || ADV.order !== 'new';
    // Opened by its address too (not only through go()): the feed is read once on the first draw.
    if (!ADV.feed && !ADV.busy && !ADV.tried) { ADV.tried = true; setTimeout(adFeedLoad, 0); }
    return cfgNote() +
      panel('Автоподбор доменов', '<dl class="kv">' + ctrlRow('Автоподбор доменов', sw('data-cfg-rt="adaptive-mode"', on, 'Автоподбор доменов', !cfgOk()), 'не открылся напрямую - идёт через VPN') + '</dl>') +
      panel('Сейчас', '<div id="adFeed">' + adFeedHtml() + '</div>' +
        '<div class="panel-actions"><button class="btn small" type="button" data-act="ad-pause">' + ico(ADV.paused ? 'refresh' : 'power') + (ADV.paused ? 'Продолжить' : 'Пауза') + '</button>' +
        '<button class="btn small" type="button" data-go="a-adaptive">' + ico('clock') + 'Вся история</button></div>') +
      panel('Домены', '<div class="search-bar"><label class="search-field">' + ico('search') + '<input class="input" type="search" data-list-filter placeholder="Найти домен" aria-label="Найти домен" autocomplete="off"></label>' +
          '<button class="icon-btn filter-btn' + (fset ? ' on' : '') + '" type="button" data-act="ad-filters" aria-expanded="' + !!fopen + '" aria-label="Фильтр" title="Фильтр">' + ico('sliders') + '</button></div>' +
        (fopen ? '<p class="chips-label">Показать</p>' + chips('show', [['all', 'Все'], ['back', 'Скоро вернутся напрямую'], ['new', 'Новые за сутки']]) +
          '<p class="chips-label">Порядок</p>' + chips('order', [['new', 'Сначала новые'], ['az', 'По алфавиту']]) : '') +
        (lim.length ? '<ul class="rows" data-list-rows>' + lim.map(row).join('') + '</ul>' : empty(names.length ? 'Ничего не найдено' : 'Пока пусто')) +
        (shown.length > lim.length ? '<div class="panel-actions"><button class="btn small" type="button" data-act="ad-more">Показать ещё</button></div>' : ''),
        { right: '<span class="num">' + fmtInt(names.length) + '</span>' });
  },

  'd-ipcats'() {
    const ip = (S.route && S.route.ip) || {}, act = ip.active || [], idx = (ip.index || []).slice().sort((a, b) => (act.includes(b.name) - act.includes(a.name)) || a.name.localeCompare(b.name)), off = cfgRoute().ip_excluded || [], held = {};
    (ip.smartdns_held || []).forEach(h => { held[h.category] = held[h.category] || h.domain; });
    return cfgNote() + panel('IP-категории', idx.length ? '<dl class="kv">' + idx.map(x => ctrlRow(x.name, sw('data-ipcat="' + esc(x.name) + '"', !off.includes(x.name), 'IP-категория ' + x.name, !cfgOk()), fmtInt(x.cidr) + ' ' + plural(x.cidr, 'сеть', 'сети', 'сетей') + (act.includes(x.name) ? ' · сейчас через VPN' : held[x.name] ? ' · не включена: в ней адрес Smart DNS (' + esc(held[x.name]) + ')' : ''))).join('') + '</dl>' : empty('Каталог IP-категорий ещё не загружен'),
      { desc: 'Подсети сервисов, которые идут через VPN.' });
  },
  'd-querylog'() {
    const q = S.qlog, f = [['all', 'Все'], ['blocked', 'Заблокированные'], ['allowed', 'Разрешённые'], ['review', 'На проверке']];
    const set = ADSV.filter !== 'all', open = ADSV.filtersOpen || set;
    const fbtn = '<button class="icon-btn filter-btn' + (set ? ' on' : '') + '" type="button" data-act="qfilters" aria-expanded="' + open + '" aria-label="Фильтр" title="Фильтр">' + ico('sliders') + '</button>';
    return panel('Журнал запросов', searchBar('ads-qsearch', ADSV.search, 'Найти домен', fbtn) +
      (open ? '<div class="chips" role="group" aria-label="Фильтр">' + f.map(x => '<button type="button" data-qfilter="' + x[0] + '" aria-pressed="' + (ADSV.filter === x[0]) + '">' + x[1] + '</button>').join('') + '</div>' : '') +
      (!q ? empty('Загрузка…') : !q.ok ? empty(errText(q)) : q.entries.length ? '<ul class="rows">' + q.entries.map(e => '<li class="row"><div class="row-main"><b>' + dom(e.domain) + '</b><small><span class="st ' + (e.blocked ? 'crit' : 'ok') + '">' + (e.blocked ? 'заблокирован' : 'разрешён') + '</span>' + (e.verdict === 'SUSPECT' ? ' · на проверке' : '') + ' · ' + esc(fmtTime(e.time)) + ' · ' + esc(e.client) + '</small></div><span class="row-acts">' + adsRuleBtn(e.domain, e.blocked ? 'allow' : 'block') + '</span></li>').join('') + '</ul>' : empty('Запросов не найдено')),
      { desc: 'Последние запросы устройств.' });
  },
  'd-review'() {
    const r = S.review;
    return panel('На проверке', !r ? empty('Загрузка…') : !r.ok ? empty(errText(r)) : r.entries.length ? '<ul class="rows">' + r.entries.map(e => '<li class="row"><div class="row-main"><b>' + dom(e.domain) + '</b><small>' + esc(reasonText(e.reason)) + (e.action === 'BLOCK' ? ' · <span class="st crit">пока заблокирован</span>' : '') + '</small></div><span class="row-acts">' + adsRuleBtn(e.domain, 'allow') + adsRuleBtn(e.domain, 'block') + '</span></li>').join('') + '</ul>' : empty('Нечего проверять'),
      { desc: 'Спорные домены: решите сами.' });
  },
  'd-blocked'() {
    const r = S.blocked;
    return panel('Заблокировано', searchBar('ads-bsearch', ADSV.blockedSearch, 'Найти домен') +
      (!r ? empty('Загрузка…') : !r.ok ? empty(errText(r)) : r.entries.length ? '<ul class="rows">' + r.entries.map(e => '<li class="row"><div class="row-main"><b>' + dom(e.domain) + '</b><small>' + esc(reasonText(e.reason)) + '</small></div><span class="row-acts">' + adsRuleBtn(e.domain, 'allow') + '</span></li>').join('') + '</ul>' + (r.total > r.entries.length ? '<p class="panel-desc">Показаны ' + r.entries.length + ' из ' + fmtInt(r.total) + ' - уточните поиск.</p>' : '') : empty('Ничего не найдено')),
      { desc: 'Домены, которые VWARD заблокировал автоматически.' });
  },
  'd-allowed'() {
    const r = S.allowed;
    return panel('Разрешено', searchBar('ads-asearch', ADSV.allowedSearch, 'Найти домен') +
      (!r ? empty('Загрузка…') : !r.ok ? empty(errText(r)) : r.entries.length ? '<ul class="rows">' + r.entries.map(e => '<li class="row"><div class="row-main"><b>' + dom(e.domain) + '</b><small>' + esc(reasonText(e.reason)) + '</small></div><span class="row-acts">' + adsRuleBtn(e.domain, 'block') + '</span></li>').join('') + '</ul>' + (r.total > r.entries.length ? '<p class="panel-desc">Показаны ' + r.entries.length + ' из ' + fmtInt(r.total) + ': уточните поиск.</p>' : '') : empty('Ничего не найдено')),
      { desc: 'Домены, которые VWARD проверил и признал безопасными. Любой можно заблокировать вручную.' });
  },
  'd-adcats'() {
    const cats = (S.ads && S.ads.categories) || [];
    return panel('Категории блокировки', cats.length ? '<dl class="kv">' + cats.map(c => ctrlRow(catText(c.id), sw('data-ads-cat="' + esc(c.id) + '"', c.active > 0, 'Категория ' + catText(c.id), !S.ads), c.active + ' из ' + c.total + ' ' + plural(c.total, 'источника', 'источников', 'источников') + ' включены')).join('') + '</dl>' : empty('Категории не найдены'),
      { desc: 'Категория включает и выключает свои источники.' });
  },
  'd-rules'() {
    const rules = (S.ads && S.ads.manual_rules) || [];
    return panel('Добавить правило', '<form class="inline-form multi" data-form="ads-rule">' + formLabel('Домен и что с ним делать') + '<input class="input" id="adsRuleDomain" placeholder="домен, например example.com" aria-label="Домен" autocomplete="off"><select class="input compact" id="adsRuleType" aria-label="Действие"><option value="block">Блокировать</option><option value="allow">Разрешить</option></select><select class="input compact" id="adsRuleScope" aria-label="Область"><option value="exact">Только домен</option><option value="suffix">С поддоменами</option></select><button class="btn primary" type="submit">' + ico('plus') + 'Добавить</button></form>' + resultBox('ads-rule')) +
      panel('Мои правила', rules.length ? '<ul class="rows">' + rules.map(r => '<li class="row"><div class="row-main"><b>' + dom(r.domain) + '</b><small><span class="st ' + (r.type === 'allow' ? 'ok' : 'crit') + '">' + (r.type === 'allow' ? 'разрешён' : 'заблокирован') + '</span> · ' + (r.scope === 'suffix' ? 'домен и поддомены' : 'только домен') + '</small></div><button class="icon-btn" type="button" title="Удалить правило" data-ads-remove="' + esc(r.domain) + '" data-scope="' + esc(r.scope || 'exact') + '" aria-label="Удалить правило ' + esc(r.domain) + '">' + ico('close') + '</button></li>').join('') + '</ul>' : empty('Правил пока нет'), { desc: 'Ваши правила важнее автоматики.' });
  },
  'd-sources'() {
    const src = (S.ads && S.ads.sources) || [];
    return panel('Источники списков', src.length ? '<ul class="rows">' + src.map(x => '<li class="row"><div class="row-main"><b>' + esc(x.name || x.id) + '</b><small>' + esc(catText(x.purpose)) + (x.cached ? ' · загружен' : ' · ещё не загружен') + '</small></div>' + sel('data-ads-source="' + esc(x.id) + '"', 'Режим ' + (x.name || x.id), [['off', 'Выключен'], ['check', 'Проверка'], ['active', 'Активен']], x.mode) + (x.custom ? '<button class="icon-btn" type="button" data-ads-srcdel="' + esc(x.id) + '" aria-label="Удалить источник" title="Удалить источник">' + ico('close') + '</button>' : '') + '</li>').join('') + '</ul>' : empty('Источники не найдены'), { desc: '«Активен» блокирует, «Проверка» только подсказывает.' }) +
      panel('Добавить свой источник', '<form class="inline-form multi" data-form="ads-srcadd">' + formLabel('Адрес списка и его формат') + '<input class="input" name="url" placeholder="https://example.org/list.txt" aria-label="Адрес списка" autocomplete="off" inputmode="url"><select class="input compact" name="format" aria-label="Формат"><option value="adblock">Adblock</option><option value="hosts">hosts</option><option value="domains">Список доменов</option></select><button class="btn primary" type="submit">' + ico('plus') + 'Добавить</button></form>' + resultBox('ads-src'),
        { desc: 'Список по https, до 10 своих источников.' });
  },
  'd-files'() {
    if (!FILES.root) return panel('Папки VWARD', '<ul class="rows">' + FILE_ROOTS.map(r => '<li class="row link" role="button" tabindex="0" data-files-root="' + r[0] + '"><div class="row-main"><b>' + esc(r[1]) + '</b><small>' + esc(r[2]) + '</small></div>' + ico('chevron', 'chev') + '</li>').join('') + '</ul>',
      { desc: 'Только просмотр, ключи и пароли скрыты.' });
    const x = S.files, here = x && x.ok && x.root === FILES.root && x.path === FILES.path ? x : null;
    const title = [FILE_ROOTS.find(r => r[0] === FILES.root)[1]].concat(FILES.path ? FILES.path.split('/') : []).join(' / ');
    const up = '<li class="row link" role="button" tabindex="0" data-files-up="1"><div class="row-main"><b>..</b><small>' + (FILES.path ? 'на уровень выше' : 'к списку папок') + '</small></div>' + ico('up', 'chev') + '</li>';
    return panel(title, !here ? (x && !x.ok && !S.errors.files ? '<ul class="rows">' + up + '</ul>' + empty(errText(x)) : empty('Загрузка…')) : '<ul class="rows">' + up + here.entries.map(e => {
      const dir = e.kind === 'dir', open = !e.closed && (dir || e.kind === 'file');
      return '<li class="row' + (open ? ' link" role="button" tabindex="0" data-files-' + (dir ? 'dir' : 'open') + '="' + esc(e.name) + '"' : '"') + '><div class="row-main"><b>' + esc(e.name) + (dir ? '/' : '') + '</b><small>' + (dir ? 'папка' : fmtBytes(e.size)) + (e.time ? ' · ' + esc(e.time) : '') + '</small></div>' +
        (e.closed ? '<span class="pill">закрыт</span>' : ico(dir ? 'chevron' : 'eye', 'chev')) + '</li>';
    }).join('') + '</ul>' + (here.entries.length ? '' : empty('Папка пуста')));
  },
  'd-notes'() {
    const p = plat(), pend = (S.update && S.update.pending) || {};
    return (pend.present && pend.version ? panel('Доступно: ' + pend.version, notesHtml(pend.version)) : '') +
      panel('Установлено: ' + (verHuman(p.version, p.last_sequence) || '—'), notesHtml(p.version));
  },
  'd-jobs'() {
    const a = S.ads || {}, j = a.jobs || {}, cur = j.current || {}, last = j.last || {}, queue = j.queue || [];
    const busy = cur.state && cur.state !== 'IDLE', n = num(j.queued) || 0;
    const since = t => t ? fmtTime(new Date(t * 1000).toISOString()) : '';
    const status = !S.ads ? ['', 'загрузка…'] : a.paused ? ['warn', 'пауза'] : busy ? ['info', 'выполняется'] :
      n ? ['warn', 'ожидает запуска'] : ['ok', 'очередь пуста'];
    const rows = queue.map((q, i) => '<li class="row"><div class="row-main"><b>' + esc((i + 1) + '. ' + jobText(q)) + '</b><small>поставлено ' + esc(since(q.created) || '—') + '</small></div>' +
      '<span class="row-acts"><button class="icon-btn" type="button" data-act="ads-job-cancel" data-id="' + esc(q.id) + '" aria-label="Отменить задание" title="Отменить"' + (S.ads ? '' : ' disabled') + '>' + ico('close') + '</button></span></li>').join('');
    return panel('Очередь', '<dl class="kv">' +
        ctrlRow('Обработка заданий', sw('data-ads-pause', !a.paused, 'Обработка заданий', !S.ads), a.paused ? 'на паузе: задания ждут' : 'задания выполняются по одному при свободном процессоре') + '</dl>' +
        kv([['Состояние', status[1], status[0]],
          busy ? ['Текущее задание', jobText(cur) + (cur.since ? ' · с ' + since(cur.since) : '')] : null,
          ['В очереди', fmtInt(n)],
          ['Последнее выполненное', !last.type || last.state === 'NONE' ? 'нет данных' : jobText(last) + ' · ' + (JOB_STATE[last.state] || last.state) + (last.ts ? ' · ' + fmtTime(String(last.ts).replace(' ', 'T')) : ''), last.state === 'FAILED' ? 'crit' : '']]) +
        (rows ? '<ul class="rows">' + rows + '</ul>' + (n > queue.length ? '<p class="panel-desc">Показаны первые ' + queue.length + ' из ' + fmtInt(n) + '.</p>' : '') : '') +
        (n && !a.paused ? '<div class="panel-actions">' + btn('ads-job-run', 'refresh', 'Выполнить очередь сейчас', 'primary', busy ? ' disabled' : '') + '</div>' : '') + resultBox('ads-job-run'),
        { desc: 'Задания выполняются последовательно, при низкой нагрузке на роутер.' }) +
      panel('Новое задание', '<div class="panel-actions even">' + btn('ads-job', 'search', 'Проверить новые домены', '', ' data-job="scan"') + btn('ads-job', 'refresh', 'Обновить источники', '', ' data-job="sources-update"') + btn('ads-job', 'check', 'Пересобрать правила', '', ' data-job="rules-rebuild"') + '</div>' +
        resultBox('ads-job'), { desc: 'Задание добавляется в конец очереди.' });
  },
  'd-aghfilters'() {
    const g = S.agh, fl = (g && g.filtering && g.filtering.filters) || [];
    const rm = confirm && confirm.id === 'agh-filter-remove' ? confirm.url : '';
    return panel('Фильтры AdGuard Home', !g ? empty('Загрузка…') : !g.ok ? empty(errText(g)) : (fl.length ? '<ul class="rows">' + fl.map(f => '<li class="row"><div class="row-main"><b>' + esc(f.name || f.url) + '</b><small>' + fmtInt(f.rules) + ' ' + plural(f.rules, 'правило', 'правила', 'правил') + (f.updated ? ' · обновлён ' + esc(fmtTime(f.updated)) : '') + '</small>' +
        '</div>' +
        '<span class="row-acts">' + sw('data-agh-filter="' + esc(f.url) + '"', f.enabled, 'Список ' + (f.name || f.url)) + '<button class="icon-btn" type="button" data-agh-filter-rm="' + esc(f.url) + '" aria-label="Удалить ' + esc(f.name || f.url) + '" title="Удалить">' + ico('close') + '</button></span>' +
        (rm === f.url ? '<div class="confirm danger"><span>Удалить список из AdGuard Home?</span><button class="btn small danger" type="button" data-act="confirm-yes">Удалить</button><button class="btn small" type="button" data-act="confirm-no">Отмена</button></div>' : '') + '</li>').join('') + '</ul>' : empty('Списков нет')) +
      '<form class="inline-form multi" data-form="agh-filter-add">' + formLabel('Адрес и название списка') + '<input class="input" name="url" placeholder="https://… адрес списка" aria-label="Адрес списка" autocomplete="off"><input class="input" name="name" placeholder="Название" aria-label="Название списка" maxlength="64"><button class="btn primary" type="submit">' + ico('plus') + 'Добавить</button></form>' +
      '<div class="panel-actions">' + btn('agh-filters-refresh', 'refresh', 'Обновить списки сейчас') + '</div>' + resultBox('agh'),
      { desc: 'Списки блокировки AdGuard Home.' });
  },
  'd-aghservices'() {
    const g = S.agh, sv = g && g.services, bl = (sv && sv.blocked) || [];
    const list = sv ? sv.available.slice().sort((a, b) => (bl.includes(b.id) - bl.includes(a.id)) || a.name.localeCompare(b.name)) : [];
    return panel('Блокировка сервисов', !g ? empty('Загрузка…') : !g.ok ? empty(errText(g)) : !sv ? empty('Эта версия AdGuard Home не отдаёт список сервисов') :
      '<dl class="kv">' + list.map(x => ctrlRow(x.name, sw('data-agh-service="' + esc(x.id) + '"', bl.includes(x.id), 'Блокировать ' + x.name))).join('') + '</dl>',
      { desc: 'Включённый сервис закрыт для всех устройств.' });
  },
  'd-https'() {
    const h = S.https;
    if (!h || !h.ok) return panel('HTTPS-фильтр', empty(h && h.error === 'https_backend_missing' ? 'HTTPS-фильтр не установлен на этом роутере' : 'Состояние недоступно'));
    const s = h.status || {};
    return panel('HTTPS-фильтр', kv(Object.keys(s).slice(0, 12).map(k => [k, s[k]])) +
      (confirmBox('https-start', 'Запустить HTTPS-фильтр? Устройства, использующие прокси, пойдут через него.', 'Запустить') || confirmBox('https-ca', 'Создать собственный сертификат для HTTPS-фильтра?', 'Создать') ||
        '<div class="panel-actions even">' + btn('https-op', 'check', 'Проверить настройки', '', ' data-op="validate"') + btn('ask', 'refresh', 'Запустить', '', ' data-confirm="https-start"') + btn('https-op', 'close', 'Остановить', '', ' data-op="stop"') + btn('ask', 'lock', 'Создать сертификат', '', ' data-confirm="https-ca"') + '</div>') + resultBox('https'),
      { desc: 'Экспериментально, по умолчанию выключено.' });
  }
};
const HOURS = Array.from({ length: 24 }, (x, i) => { const h = (i < 10 ? '0' : '') + i + ':00'; return [h, h]; });
function withCur(opts, v, unit) { return v == null || v === '' || opts.some(o => String(o[0]) === String(v)) ? opts : opts.concat([[v, v + unit]]); }
function countText(n) { return n + ' ' + plural(n, 'домен', 'домена', 'доменов'); }
function cfgNote() { return !S.config ? '' : !S.config.writable ? '<p class="field-warn">Изменение настроек из VWARD недоступно: на роутере нет программы настроек VWARD. Установите обновление VWARD.</p>' : ''; }
// A search: one field with a magnifier inside, Enter searches; an optional button beside it.
function searchBar(form, value, placeholder, extra) {
  return '<form class="search-bar" data-form="' + form + '"><label class="search-field">' + ico('search') + '<input class="input" type="search" name="q" value="' + esc(value) + '" placeholder="' + esc(placeholder) + '" aria-label="' + esc(placeholder) + '" autocomplete="off" enterkeyhint="search"></label>' + (extra || '') + '</form>';
}
function formLabel(text) { return '<span class="form-label">' + esc(text) + '</span>'; }
// One field with its button inside the field's right edge: every form that takes one value.
// o: form, attrs (more form attributes), label, name/id, value, placeholder, aria, mono,
//    maxlength, off (disabled), busy, icon, btn (the button's word; a phone shows only the icon).
function inputBar(o) {
  return '<form class="input-bar" data-form="' + o.form + '"' + (o.attrs || '') + '>' + (o.label ? formLabel(o.label) : '') +
    '<div class="input-bar-box"><input class="input' + (o.mono ? ' mono' : '') + '"' + (o.name ? ' name="' + o.name + '"' : '') + (o.id ? ' id="' + o.id + '"' : '') +
    (o.value != null && o.value !== '' ? ' value="' + esc(o.value) + '"' : '') + ' placeholder="' + esc(o.placeholder || '') + '" aria-label="' + esc(o.aria || o.label || o.placeholder || '') + '"' +
    (o.maxlength ? ' maxlength="' + o.maxlength + '"' : '') + ' autocomplete="off" spellcheck="false" enterkeyhint="go"' + (o.off ? ' disabled' : '') + '>' +
    '<button class="input-bar-btn' + (o.busy ? ' busy' : '') + '" type="submit" aria-label="' + esc(o.btn) + '"' + (o.off || o.busy ? ' disabled' : '') + '>' + ico(o.busy ? 'refresh' : o.icon || 'search') + '<span>' + esc(o.btn) + '</span></button></div></form>';
}
function addForm(op, placeholder, label) { return inputBar({ form: 'cfg-add', attrs: ' data-op="' + op + '"', label: label || 'Новый домен', name: 'domain', placeholder: placeholder, aria: 'Домен', off: !cfgOk(), icon: 'plus', btn: 'Добавить' }); }
const myListId = () => { const own = cfgRoute().group || prof().policy_group; return own && ((S.lists && S.lists.lists) || []).some(l => l.name === own) ? 'l-' + own : 'lists'; };
// «Мои домены» and «Всегда через VPN» are one list: a domain of either, pinned when always through VPN.
const dname = d => typeof d === 'string' ? d : d && d.domain;
const myForced = () => (cfgRoute().force_vpn || []).map(dname).filter(Boolean);
const myDomains = () => { const own = (cfgRoute().domains || []).map(dname).filter(Boolean); return own.concat(myForced().filter(d => !own.includes(d))); };
function myRows(list, forced) {
  const ok = cfgOk() ? '' : ' disabled';
  return list.length ? '<ul class="rows">' + list.map(d => { const f = forced.includes(d);
    return '<li class="row"><div class="row-main"><b>' + dom(d) + '</b>' + (f ? '<small>всегда через VPN</small>' : '') + '</div><span class="row-acts">' +
      '<button class="icon-btn pin" type="button" data-my-pin="' + esc(d) + '" aria-pressed="' + f + '" aria-label="' + (f ? 'Снять «всегда через VPN» с ' : 'Всегда через VPN: ') + esc(d) + '" title="' + (f ? 'Снять «всегда через VPN»' : 'Всегда через VPN') + '"' + ok + '>' + ico('pin') + '</button>' +
      '<button class="icon-btn" type="button" data-my-rm="' + esc(d) + '" aria-label="Убрать ' + esc(d) + ' из VPN" title="Убрать из VPN"' + ok + '>' + ico('close') + '</button></span></li>'; }).join('') + '</ul>' : '';
}
async function myRemove(d) {
  const r = cfgRoute(), own = (r.domains || []).map(dname).includes(d), f = myForced().includes(d);
  if (f && !own) { await cfgSet({ op: 'force-vpn', action: 'remove', target: d }, d + ' убран из VPN', ['route']); return; }
  // Both: the pin quietly first, one message for the whole removal.
  if (f) { const x = await apiPost('config', { op: 'force-vpn', action: 'remove', target: d }).catch(e => ({ ok: false, error: e.message })); if (!x.ok) { toast('Не сохранено: ' + errText(x)); await load('config', true); render(); return; } }
  if (own) await cfgSet({ op: 'route-domain', action: 'remove', target: d }, d + ' убран из VPN', ['route']);
}
function rowBtn(op, action, d, icon, label) { return '<button class="icon-btn" type="button" data-cfg-op="' + op + '" data-cfg-action="' + action + '" data-cfg-target="' + esc(d) + '" aria-label="' + esc(label) + '" title="' + esc(label) + '"' + (cfgOk() ? '' : ' disabled') + '>' + ico(icon) + '</button>'; }
// The autopick page (fix.38): its view and its live feed from the core's journal.
const adHm = t => new Date(t).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
const ADV = { q: '', show: 'all', order: 'new', open: '', lim: 50, filters: false, paused: false, feed: null, at: 0, busy: false };
const AD_EV = {
  ADDED: ['bad', 'напрямую не открылся - добавлен в VPN'], DIRECT_OK: ['ok', 'открывается напрямую'],
  ISP_FAIL_VPN_FAIL: ['warn', 'не открылся ни напрямую, ни через VPN'], ISP_FAIL_VPN_UNSTABLE: ['warn', 'через VPN открывается нестабильно'],
  ISP_UNRELIABLE: ['warn', 'провайдер сейчас не отвечает - не проверялся'], MAINT_DIRECT_CONFIRM: ['ok', 'снова открывается напрямую'],
  MAINT_REMOVE: ['ok', 'вернулся напрямую'], REMOVED: ['ok', 'вернулся напрямую'], MAINT_DIRECT_FAIL: ['', 'проверка: напрямую не открывается, остаётся в VPN']
};
function adFeedParse(text) {
  return String(text || '').split('\n').map(l => l.split('|')).filter(f => f.length >= 3 && (AD_EV[f[1]] || (f[1] === 'PROBE_UNKNOWN' && /dns blocked/.test(f[3] || '')))).map(f => {
    const ev = f[1] === 'PROBE_UNKNOWN' || /dns blocked/.test(f[3] || '') && f[1] === 'MAINT_REMOVE' ? ['warn', f[1] === 'MAINT_REMOVE' ? 'убран: возможно, реклама' : 'возможно, реклама: не добавлен'] : AD_EV[f[1]];
    const streak = /streak=(\d+)\/(\d+)/.exec(f[3] || '');
    return { t: Date.parse(f[0]), host: f[2], code: f[1] === 'PROBE_UNKNOWN' || (f[1] === 'MAINT_REMOVE' && /dns blocked/.test(f[3] || '')) ? 'ad' : f[1], tone: ev[0], text: ev[1] + (f[1] === 'MAINT_DIRECT_CONFIRM' && streak ? ' (' + streak[1] + ' из ' + streak[2] + ')' : '') };
  }).reverse();
}
function adFeedHtml() {
  const f = ADV.feed;
  if (!f) return empty(ADV.busy ? 'Загрузка…' : 'Нет данных');
  const dayAgo = Date.now() - 86400000, recent = f.filter(e => e.t > dayAgo);
  const n = codes => recent.filter(e => codes.includes(e.code)).length;
  const sum = recent.length ? '<p class="panel-desc">За сутки: ' + [n(['ADDED']) + ' добавлено', n(['MAINT_REMOVE', 'REMOVED']) + ' вернулись напрямую', n(['ad']) + ' пропущено как реклама'].join(', ') + '.</p>' : '';
  return sum + (f.length ? '<ul class="events">' + f.slice(0, 20).map(e => '<li class="ev ' + (e.tone || 'info') + '"><span class="ev-dot" aria-hidden="true"></span><span class="ev-text"><b>' + dom(e.host) + '</b> - ' + esc(e.text) + '</span><span class="ev-at">' + esc(isNaN(e.t) ? '' : adHm(e.t)) + '</span></li>').join('') + '</ul>' : empty('Событий пока нет'));
}
// Light: the core's journal tail, about 10 KB, only while the page is open and not paused.
function adFeedLoad() {
  if (ADV.busy) return Promise.resolve();
  ADV.busy = true;
  return apiText('log', { name: 'core', count: 80 }).then(t => { ADV.feed = adFeedParse(t); ADV.at = Date.now(); }, () => {})
    .finally(() => { ADV.busy = false; const b = $('adFeed'); if (b && current === 'd-adaptive') b.innerHTML = adFeedHtml(); });
}
function domainRows(list, acts, sub) { return list.length ? '<ul class="rows">' + list.map(d => '<li class="row"><div class="row-main"><b>' + dom(d) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</div><span class="row-acts">' + acts(d) + '</span></li>').join('') + '</ul>' : ''; }
const CAT_NAMES = { 'ads-tracking-security': 'Реклама, трекеры и угрозы', 'ads-tracking-security-aggressive': 'Усиленная защита', 'popup-ads': 'Всплывающая реклама', 'ads-tracking': 'Реклама и трекеры', ads: 'Реклама', tracking: 'Трекеры', 'ads-malware': 'Реклама и вредоносные сайты', 'mobile-ads': 'Реклама в приложениях', custom: 'Свои источники' };
const catText = id => CAT_NAMES[id] || id || '';
const REASONS = { source_consensus: 'несколько источников согласны', single_source: 'только один источник', block_revalidation_pending: 'ждёт повторной проверки', block_evidence_disappeared_review: 'источники больше не подтверждают', no_block_evidence: 'нет причин блокировать' };
const reasonText = r => REASONS[r] || (r || '').replace(/_/g, ' ');
// Router stamps come from `date` ("Thu Sep 24 18:20:02 MSK 2026"), ISO or epoch seconds.
const MON = { Jan: 1, Feb: 2, Mar: 3, Apr: 4, May: 5, Jun: 6, Jul: 7, Aug: 8, Sep: 9, Oct: 10, Nov: 11, Dec: 12 };
// «Последняя проверка» in «Обновления»: when the update feed was last read (feed.state of the
// watcher), with the error when the last try failed; the check after an installation is its own row.
function feedCheckRow(p) {
  const ok = num(p.feed_ok_at), bad = num(p.feed_fail_at);
  if (bad != null && bad > (ok || 0)) return ['Последняя проверка', 'ошибка ' + fmtStamp(bad), 'warn', 'a-updater', '', ok != null ? 'удачная ' + fmtStamp(ok) : ''];
  return ok != null ? ['Последняя проверка', fmtStamp(ok), '', 'a-updater'] : ['Последняя проверка', 'не было'];
}

function fmtStamp(t) {
  if (t == null || t === '') return '';
  const s = String(t).trim(), m = /^[A-Z][a-z]{2} ([A-Z][a-z]{2}) +(\d{1,2}) (\d\d:\d\d)(?::\d\d)?(?: \S+)? (\d{4})$/.exec(s);
  if (m && MON[m[1]]) return ('0' + m[2]).slice(-2) + '.' + ('0' + MON[m[1]]).slice(-2) + ' ' + m[3];
  if (/^\d{9,10}$/.test(s)) return fmtTime(Number(s) * 1000);
  return fmtTime(s);
}
// A log line "2026-09-27 04:26:52|OK|rows=1|..." or "... SYNC added=3 ...": its time,
// its first bare word (OK, SYNC, FAIL...) and its key=value fields.
function logLine(t) {
  const s = String(t || '').trim(), m = /^(\d{4}-\d\d-\d\d)[ T](\d\d:\d\d(?::\d\d)?)/.exec(s), f = {};
  const rest = m ? s.slice(m[0].length) : s, words = rest.split(/[|\s]+/).filter(Boolean);
  words.forEach(w => { const i = w.indexOf('='); if (i > 0) f[w.slice(0, i)] = w.slice(i + 1); });
  return { at: m ? fmtTime(m[1] + 'T' + m[2]) : '', word: (words.find(w => !w.includes('=')) || '').toUpperCase(), f: f };
}
function catalogStamp(t) {
  if (!t) return '—';
  const l = logLine(t), n = num(l.f.domains), c = num(l.f.categories);
  if (!l.at && !Object.keys(l.f).length) return 'нет данных';
  if (l.word && l.word !== 'OK') return (l.at ? l.at + ' · ' : '') + 'ошибка обновления';
  return [l.at, n != null ? fmtInt(n) + ' ' + plural(n, 'домен', 'домена', 'доменов') : '', c != null ? fmtInt(c) + ' ' + plural(c, 'категория', 'категории', 'категорий') : ''].filter(Boolean).join(' · ') || '—';
}
function ipSyncStamp(t) {
  if (!t) return '—';
  const l = logLine(t), add = num(l.f.added) || 0, del = num(l.f.removed) || 0, err = num(l.f.errors) || 0;
  if (!l.at && !Object.keys(l.f).length) return 'нет данных';
  const what = /FAIL|ERROR/.test(l.word) ? 'ошибка обновления' : err ? fmtInt(err) + ' ' + plural(err, 'ошибка', 'ошибки', 'ошибок') : add || del ? 'добавлено ' + fmtInt(add) + ', убрано ' + fmtInt(del) : 'без изменений';
  return (l.at ? l.at + ' · ' : '') + what;
}
// Where "my domains" go: one of the Keenetic groups routed to the tunnel. Shown as a
// choice while none is chosen or there are several to choose from.
function policyGroupRow() {
  const r = cfgRoute(), gs = r.groups || [], cur = r.group || '';
  if (!S.config || !r.router_available || !gs.length || (cur && gs.length < 2)) return '';
  const opts = (cur ? [] : [['', 'выберите группу', true]]).concat(gs.map(g => [g.name, g.description ? g.description + ' (' + g.name + ')' : g.name]));
  return ctrlRow('Мои домены сохраняются в выбранной группе вместе с её доменами', sel('data-policy-group' + (cfgOk() ? '' : ' disabled'), 'Куда добавлять мои домены', opts, cur), cur ? 'Список Keenetic, идущий через VPN' : 'через VPN идёт несколько списков - выберите один');
}
// Shared by the VPN page and its events page.
// Quality over the last 30 minutes (a ping sample a minute through every tunnel) and what the
// guard does with several tunnels.
const tq = name => ((S.tq && S.tq.tunnels) || []).find(x => x.name === name);
const listLabel = name => { const l = ((S.lists && S.lists.lists) || []).find(x => x.name === name); return (l && l.description) || name; };
// The speed with the time of its measurement; nothing while measuring is switched off (an old
// figure without a date read as today's).
const tqSpeed = q => !q || q.speed_mbps == null || ((S.tq || {}).auto || {}).speed === 'off' ? '' :
  ' · скорость ' + (q.speed_mbps > 0 ? String(q.speed_mbps).replace('.', ',') + ' Мбит/с' + (q.speed_at ? ' (' + fmtTime(q.speed_at * 1000) + ')' : '') : 'не измерена');
// The quality in a tunnel's line of «Туннели»: its answer time and losses of the last 30 minutes
// (not for one switched off or silent: the status says that).
const tqShort = t => { const q = tq(t.name);
  return !q || tunOff(t) || TUNBUSY[t.name] || q.last_loss >= 100 || q.avg_ms == null ? '' : q.avg_ms + ' мс' + (q.loss_pct ? ' · потери ' + q.loss_pct + '%' : ''); };
// A VLESS tunnel is measured by a page's answer through it (Xray answers ping itself).
const tqWhat = q => q && q.name && vlessOf(q.name) ? 'ответ страницы ' : 'пинг ';
const tqText = q => !q ? 'замеров ещё нет' : q.last_loss >= 100 ? 'не отвечает' + (q.up_pct != null ? ' · доступен ' + q.up_pct + '% за 30 мин' : '') :
  tqWhat(q) + (q.avg_ms != null ? q.avg_ms + ' мс' : '—') + ' · потери ' + (q.loss_pct != null ? q.loss_pct : '—') + '%' + (q.jitter_ms != null ? ' · разброс ' + q.jitter_ms + ' мс' : '') + tqSpeed(q);
const TQ_CRITERIA = [['balanced', 'сбалансированно'], ['speed', 'скорости'], ['ping', 'отклику (пингу)']];
const TQ_SPEED = [['night', 'ночью'], ['6h', 'раз в 6 часов'], ['off', 'выключен']];
function tunnelsQualityPanel() {
  const tuns = (st().wg && st().wg.interfaces) || [], x = S.tq || {};
  if (tuns.length < 2) return '';
  const cur = prof().tunnel_interface, a = x.auto || {};
  // Settings only: the tunnels and their quality are in «Туннели» above (owner 2026-10-12: one
  // place to open a tunnel from).
  return panel('Резервный туннель', (x.fallback_from ? '<p class="field-warn">«' + esc(tunLabel(x.fallback_from)) + '» не отвечал' + (x.fallback_at ? ' с ' + esc(fmtTime(x.fallback_at * 1000)) : '') + ': маршруты VWARD переведены на «' + esc(tunLabel(cur)) + '».' + (x.return_home ? ' Вернутся, когда он будет отвечать 3 минуты подряд.' : '') + '</p>' : '') +
    ((x.lists_moved || []).length ? '<p class="field-warn">Списки со своим туннелем на запасном' + (x.return_home ? ': вернутся, когда их туннель будет отвечать 3 минуты подряд' : '') + '.</p>' + kv(x.lists_moved.map(m => [listLabel(m.name), tunLabel(m.to), 'warn', 'l-' + m.name, '', 'свой туннель «' + tunLabel(m.from) + '»' + (m.at ? ', переведён ' + fmtTime(m.at * 1000) : '')])) : '') + '<dl class="kv">' +
    ctrlRow('Запасной туннель', sw('data-cfg-tq="tunnel-fallback"', x.fallback !== false, 'Запасной туннель', !cfgOk()), 'туннель не отвечает - его маршруты и списки переходят на лучший отвечающий туннель; если такого нет - идут напрямую') +
    ctrlRow('Возвращать на основной', sw('data-cfg-tq="tunnel-return"', x.return_home !== false, 'Возвращать на основной', !cfgOk()), 'туннель отвечает 15 минут подряд - маршруты и списки возвращаются на него') +
    ctrlRow('Выбирать лучший туннель', sw('data-cfg-ta="enabled"', a.enabled === true, 'Выбирать лучший туннель', !cfgOk()), 'маршруты VWARD переходят на туннель, который лучше на 30% 15 минут подряд; не чаще раза в 30 минут - переключение рвёт открытые соединения') +
    (a.enabled ? ctrlRow('Выбирать туннель по', sel('data-cfg-ta="criterion"' + (cfgOk() ? '' : ' disabled'), 'Выбирать туннель по', TQ_CRITERIA, a.criterion || 'balanced'),
      a.criterion === 'speed' ? 'по замеру скорости, потери учитываются' : a.criterion === 'ping' ? 'пинг и разброс - для игр и звонков' : 'потери и пинг, скорость - добавкой') : '') +
    ctrlRow('Замер скорости', choiceSlider('tq-speed', [['night', 'Ночью'], ['6h', 'Раз в 6 ч'], ['off', 'Выключен']], a.speed || 'night', 'Замер скорости'), (a.speed === 'off' ? '' : a.speed === '6h' ? '' : 'между 03:00 и 05:00; ') + '10 МБ через каждый туннель по очереди') + '</dl>' +
    (a.enabled ? kv([
      ['Лучше текущего', a.better ? tunLabel(a.better) : 'нет', '', null, '', a.better ? (a.better_since ? 'с ' + fmtTime(a.better_since * 1000) + '; ' : '') + 'переход, если так будет 15 минут подряд' : ''],
      ['Последнее переключение', a.last_at && a.last_to ? tunLabel(a.last_to) : 'не было', '', null, '', a.last_at && a.last_to ? 'с «' + tunLabel(a.last_from || '') + '», ' + fmtTime(a.last_at * 1000) : '']]) : '') +
    '<div class="panel-actions even">' + btn('tunnel-speed', a.speed_running ? 'refresh' : 'runtime', a.speed_running ? 'Идёт замер скорости…' : 'Проверить скорость сейчас', '', a.speed_running || !cfgOk() ? ' disabled' : '') + '</div>',
    { desc: 'Качество туннелей проверяется раз в минуту; оно показано в списке «Туннели» и на странице туннеля.' });
}
// The VPN agent is on when its component runs and its automation is allowed: one switch for both,
// the same state on the VPN page and on the component's page.
const guardOn = () => compOn('tunnel-guard') && (!S.config || (cfg().tunnel_guard || {}).enabled !== false);
// «Восстановление интернета» is on when its component and its own switch are (fix.38: the same on every page).
const wanOn = () => compOn('wan-guard') && (!S.config || !cfg().wan_guard || cfg().wan_guard.enabled !== false);
function vpnGuardPanel() {
  const wg = st().wg || {}, ti = prof().tunnel_interface, dt = (wg.interfaces || []).find(t => t.name === ti);
  // Keenetic's «auto» routes skip a tunnel that is down: the lists then go direct whatever the agent did.
  const direct = isTrue(wg.failopen_active) || (dt && !isTrue(dt.connected)), watch = agentsMode().network === 'watch';
  return panel('Агент VPN', '<dl class="kv">' + ctrlRow('Агент VPN', sw('data-cfg-tg', guardOn(), 'Агент VPN', !cfgOk())) + '</dl>' +
    confirmBox('tg-off', 'Выключить агент VPN? При отказе туннеля маршрутизация списков VPN не переключится на резервный канал.', 'Выключить', true) + kv([
    ['Маршрутизация списков', direct ? 'Напрямую' : 'VPN', direct ? 'warn' : 'ok', null, '', direct && dt && tunLost(dt) ? 'у туннеля по умолчанию нет настроек' : direct && !isTrue(wg.failopen_active) ? 'туннель по умолчанию не в сети' : ''],
    current === 'a-tunnel' ? null : ['История агента VPN', '', '', 'a-tunnel']
  ]) +
    // fix.38.1 (owner 12.11.2026): the mode is chosen here, the row no longer leads to the agents' list.
    '<dl class="kv">' + ctrlRow('Восстановление VPN', modeSlider('network', watch ? 'watch' : 'act', 'Режим агента сети'),
      (watch ? 'песочница: только записывает, что сделал бы' : 'вкл: проверка туннеля каждые 6 минут') + '; это режим агента сети - и для интернета, и для DNS') + '</dl>' +
    // fix.38.1 (owner 12.11.2026): the counter only when the tunnel failed; «0» said nothing.
    (num(wg.down_streak) ? kv([['Отказов подряд', String(num(wg.down_streak))]]) : '') + '<div class="panel-actions even">' + btn('tunnel-health', 'check', 'Проверить') + '</div>' + resultBox('tunnel-health'),
  {});
}
// wanNowRows: the manual repair buttons of «Восстановление интернета».
function wanNowRows() {
  const busy = String(runningId || '').startsWith('wan-') ? runningId : '';
  return '<dl class="kv">' +
        ctrlRow('Обновить адрес', btn('ask', 'refresh', busy === 'wan-renew' ? 'Обновляем…' : 'Обновить', 'small', ' data-confirm="wan-renew"' + (busy ? ' disabled' : '')), 'повторный запрос адреса у провайдера (DHCP), соединение не разрывается') +
        ctrlRow('Переподключить', btn('ask', 'power', busy === 'wan-bounce' ? 'Переподключаем…' : 'Переподключить', 'small', ' data-confirm="wan-bounce"' + (busy ? ' disabled' : '')), 'интерфейс провайдера выключается и включается, интернета нет около 10 с') + '</dl>' +
        (confirmBox('wan-renew', 'Попросить у провайдера новый адрес? Связь может прерваться на несколько секунд.', 'Обновить') ||
         confirmBox('wan-bounce', 'Переподключить интернет? Он пропадёт примерно на 10 секунд, домашняя сеть продолжит работать.', 'Переподключить') || '');
}
/* ---------- Что происходило: события раздела простыми словами ---------- */
// Each section shows what its component did, newest first, on its own page. A
// reader turns a journal line into {tone, text}; routine checks and unknown
// lines are left out, the raw journals stay in «Технические журналы».
const evFields = parts => { const f = {}; parts.forEach(w => { const i = String(w).indexOf('='); if (i > 0) f[w.slice(0, i)] = w.slice(i + 1); }); return f; };
const evFill = (t, f) => t.replace(/\{(\w+)\}/g, (_, k) => f[k] != null && f[k] !== '' ? f[k] : '—');
const toRoute = '{h} напрямую не открывается - теперь через VPN', toDirect = '{h} снова открывается напрямую - убран из VPN';
const ROUTE_ADAPTIVE = {
  AUTO_VPN: ['ok', toRoute], HINT_AUTO_VPN: ['ok', '{h} - через VPN по подсказке каталога'], LIST_AUTO_VPN: ['ok', '{h} из списка не открывается напрямую - через VPN'],
  LIST_AUTO_VPN_SKIP: ['warn', '{h} из списка не открывается, а VPN сейчас не работает'], LIST_BYPASS_FAIL: ['warn', '{h} из списка не открывается напрямую'],
  AUTO_DIRECT: ['info', toDirect], AUTO_DIRECT_MAINT: ['info', toDirect], AUTO_DIRECT_NIGHT: ['info', toDirect],
  ADD_ERROR: ['bad', '{h}: не удалось добавить в VPN'], HINT_ADD_ERROR: ['bad', '{h}: не удалось добавить в VPN'],
  ADD_ABORT_WG_FAIL: ['warn', '{h} не открывается, а VPN сейчас не работает - оставлен как есть'], HINT_WG_UNAVAILABLE: ['warn', '{h} не открывается, а VPN сейчас не работает - оставлен как есть'],
  ADD_ABORT_AGH: ['info', '{h} заблокирован AdGuard Home - VPN не нужен'], ADAPTIVE_AGH_BLOCKED: ['info', '{h} заблокирован AdGuard Home - VPN не нужен'],
  HINT_AGH_BLOCKED: ['info', '{h} заблокирован AdGuard Home - VPN не нужен'], AGH_BLOCKED: ['info', '{h} заблокирован AdGuard Home - VPN не нужен'],
  ADD_ABORT_DIRECT_RECOVERED: ['info', '{h} снова открылся напрямую - VPN не понадобился'],
  BROKEN_ISP_AND_VPN: ['warn', '{h} не открывается ни напрямую, ни через VPN'], ISP_FAIL_WG_FAIL: ['warn', '{h} не открывается ни напрямую, ни через VPN'],
  ISP_FAIL_ALT_OK: ['warn', '{h} не открывается ни напрямую, ни через туннель VWARD, но открывается через «{tunnel}» - добавьте его в список этого туннеля'],
  ISP_FAIL_WG_UNSTABLE: ['warn', '{h} напрямую не открывается, VPN работает с перебоями'], DIRECT_UNSTABLE: ['warn', '{h} напрямую открывается с перебоями'],
  START: ['info', 'Автоподбор запущен'], WATCHDOG_RESTART: ['warn', 'Автоподбор перезапущен после сбоя'],
  PERSIST_RESTORE_OK: ['ok', 'После перезапуска домены автоподбора восстановлены'], PERSIST_RESTORE_PARTIAL: ['warn', 'После перезапуска восстановлены не все домены автоподбора'],
  PERSIST_RESTORE_FAIL: ['bad', 'Не удалось восстановить домены автоподбора'], PERSIST_RESTORE_LOCK_FAIL: ['bad', 'Не удалось восстановить домены автоподбора'],
  PERSIST_RESTORE_CONFIG_FAIL: ['bad', 'Не удалось восстановить домены автоподбора'], PERSIST_BACKUP_ERROR: ['bad', 'Не удалось сохранить домены автоподбора'],
  PERSIST_COMMIT_ROLLBACK: ['bad', 'Не удалось сохранить домены автоподбора - отменено']
};
const ROUTE_MAINT = {
  MAINT_DIRECT_CONFIRM_WAIT: ['info', '{h} открывается напрямую - ждём подтверждения'], MAINT_DIRECT_CONFIRM: ['info', '{h} стабильно открывается напрямую'],
  AUTO_DIRECT_MAINT: ['ok', '{h} убран из VPN - открывается напрямую'], AUTO_DIRECT: ['ok', '{h} убран из VPN - открывается напрямую'], AUTO_DIRECT_NIGHT: ['ok', '{h} убран из VPN - открывается напрямую'],
  MAINT_BROKEN: ['warn', '{h} не открывается ни напрямую, ни через VPN'], MAINT_SAVE_ROLLBACK: ['bad', '{h}: изменение не сохранилось - отменено'],
  MAINT_REMOVE_ERROR: ['bad', '{h}: не удалось убрать из VPN']
};
function routeEvent(rest, map) {
  const p = rest.split('|'), up = x => /^[A-Z][A-Z0-9_]+$/.test(x || '');
  let ev = p[0], host = p[1] || '';
  if (!up(ev) && up(p[1])) { ev = p[1]; host = p[0]; }
  const m = map[ev];
  return m ? { tone: m[0], text: evFill(m[1], Object.assign(evFields(p), { h: host })), host: /\{h\}/.test(m[1]) ? host : '' } : null;
}
const TUNNEL_EV = {
  FAILOPEN_DOWN: ['bad', 'VPN не работает - трафик списков пущен напрямую'], FAILOPEN_DOWN_ERROR: ['bad', 'VPN не работает, а пустить трафик напрямую не удалось'],
  FAILOPEN_RESTORED: ['ok', 'VPN снова работает - трафик списков вернулся в VPN'], ABORT_WG_RECOVERED: ['ok', 'Туннель восстановился, списки не переключались'],
  WAIT_DOWN_CONFIRM: ['warn', 'VPN не отвечает - проверяем ещё раз'], WAIT_RECOVERING: ['warn', 'VPN восстанавливается'], WAIT_DEGRADED: ['warn', 'VPN работает с перебоями'],
  HOLD_WAN_DOWN: ['warn', 'Нет интернета у провайдера - VPN не трогаем'], INTERFACE_DISABLED_EXTERNAL: ['info', 'Туннель выключен вручную'],
  DISABLED_BY_USER: ['info', 'Агент VPN выключен'], HEALTH_STALE: ['warn', 'Проверка туннеля давно не приходила'], NO_HEALTH_STATE: ['warn', 'Проверка туннеля ещё не приходила']
};
const WAN_CLASS = {
  PHY_DOWN: ['bad', 'Нет сигнала в кабеле провайдера'], DHCP_FAILURE: ['bad', 'Провайдер не выдал адрес'], GATEWAY_FAILURE: ['bad', 'Шлюз провайдера не отвечает'],
  DNS_ONLY_FAILURE: ['warn', 'Не работает DNS: сайты не открываются по именам'], INTERNET_FAILURE: ['bad', 'Пропал интернет'], UNKNOWN: ['warn', 'Состояние интернета не удалось определить'],
  WAN_RECOVERY_FAILED: ['bad', 'Восстановить подключение не удалось']
};
const WAN_ACTION = {
  DHCP_RENEW: 'Запросили у провайдера новый адрес', MANUAL_DHCP_RENEW: 'Вы запросили у провайдера новый адрес',
  WAN_BOUNCE: 'Интернет переподключён', MANUAL_WAN_BOUNCE: 'Вы переподключили интернет',
  WAN_BOUNCE_RECOVERY: 'Подключение к провайдеру включено обратно', MANUAL_BOUNCE_RECOVERY: 'Подключение к провайдеру включено обратно',
  WAN_BOUNCE_RECOVERY_FAILED: 'Не удалось включить подключение к провайдеру', MANUAL_WAN_BOUNCE_INTERRUPTED: 'Переподключение прервалось'
};
function wanEvent(rest, log) {
  const f = evFields(rest.split(/\s+/));
  if (log === 'recovery') {
    const t = WAN_ACTION[f.action]; if (!t) return null;
    const bad = /FAILED|INTERRUPTED/.test(f.action) || ['rc', 'up_rc', 'down_rc'].some(k => f[k] != null && f[k] !== '0');
    return { tone: bad ? 'bad' : 'info', text: t + (bad && !/FAILED|INTERRUPTED/.test(f.action) ? ' - не получилось' : '') };
  }
  // Only what happened to the internet: a slow answer of the router to VWARD's own
  // check (UTILITY_DEGRADED) and the first check after a start are not events.
  if (f.class === 'UTILITY_DEGRADED') return null;
  if (f.class === 'BOOT_GRACE') return { tone: 'info', text: 'Роутер перезагрузился' };
  if (f.class === 'HEALTHY') return !f.previous || ['NONE', 'UTILITY_DEGRADED', 'BOOT_GRACE'].includes(f.previous) ? null : { tone: 'ok', text: 'Интернет снова работает' };
  const m = WAN_CLASS[f.class];
  return m ? { tone: m[0], text: m[1] } : null;
}
function wifiEvent(rest) {
  const w = rest.split(/\s+/), level = w[0], msg = w.slice(1).join(' '), f = evFields(w);
  const band = b => /^[\d.]+$/.test(b || '') ? b + ' ГГц' : (b || '—');
  const dev = f.mac ? 'w-' + String(f.mac).toLowerCase() : '';
  if (/^band switch/.test(msg)) return { tone: 'info', text: wifiName(f.mac) + ': перешло с ' + band(f.from) + ' на ' + band(f.to), go: dev };
  if (/^control PASS/.test(msg)) return { tone: 'ok', text: wifiName(f.mac) + ': настройка Wi-Fi применена', go: dev };
  if (level === 'ERROR') return { tone: 'bad', text: 'Настройку Wi-Fi применить не удалось' };
  if (/band discovery unavailable/.test(msg)) return { tone: 'warn', text: 'Роутер не сообщил диапазоны точек доступа - взяты прежние' };
  return null;
}
function policyEvent(rest, log) {
  const f = evFields(rest.split(/[|\s]+/));
  if (log === 'policysync') {
    if (!/\bSYNC\b/.test(rest) || f.added == null) return null;
    const add = num(f.added) || 0, del = num(f.removed) || 0, err = num(f.errors) || 0;
    return err ? { tone: 'bad', text: 'IP-категории обновлены с ошибками: ' + fmtInt(err) }
      : { tone: 'ok', text: add || del ? 'IP-категории обновлены: добавлено ' + fmtInt(add) + ', убрано ' + fmtInt(del) : 'IP-категории проверены - без изменений' };
  }
  if (f.checked == null) return null;
  const fail = num(f.fail) || 0;
  return { tone: fail ? 'warn' : 'ok', text: 'Проверено адресов: ' + fmtInt(f.checked) + (fail ? ', напрямую не открываются: ' + fmtInt(fail) : ' - все открываются') };
}
const UPDATER_EV = [
  [/^Update (\S+) committed/, 'ok', m => 'Установлено обновление ' + m[1]], [/^Rollback completed/, 'warn', () => 'Обновление откатили к прежней версии'],
  [/^Update engine (\S+) -> (\S+)/, 'info', m => 'Модуль обновлений обновлён до ' + m[2]], [/^(Manifest unchanged|Feed matches already installed)/, 'info', () => 'Проверка: обновлений нет'],
  [/^Pending \S+ update is waiting for its window/, 'info', () => 'Есть обновление - ждёт времени установки'],
  [/^Pending \S+ update is not enabled for automatic apply/, 'info', () => 'Есть обновление - установка по кнопке'],
  [/^Pending \S+ update is quarantined/, 'warn', () => 'Обновление отложено после неудачной попытки'],
  [/^Manifest HTTP status/, 'warn', () => 'Сервер обновлений не ответил'], [/^New engine failed its self-test/, 'bad', () => 'Новый модуль обновлений не прошёл самопроверку - оставлен прежний'],
  [/^Runtime resume failed/, 'bad', () => 'VWARD не запустился после обновления']
];
function updaterEvent(rest) {
  const m = /^\[(\w+)\]\s*(.*)$/.exec(rest); if (!m) return null;
  for (const u of UPDATER_EV) { const x = u[0].exec(m[2]); if (x) return { tone: u[1], text: u[2](x) }; }
  return m[1] === 'ERROR' ? { tone: 'bad', text: 'Ошибка при обновлении' } : null;
}
const ADS_EV = {
  SOURCES_UPDATE_OK: ['ok', 'Источники списков обновлены', 'd-sources'], SOURCES_UPDATE_FAIL: ['warn', 'Часть источников списков не обновилась', 'd-sources'],
  SOURCE_FAIL: ['warn', 'Источник списка не скачался', 'd-sources'], PUBLISH_OK: ['ok', 'Правила переданы в AdGuard Home', 'd-rules'], PUBLISH_RECORD_FAILED: ['bad', 'Правила не удалось передать в AdGuard Home', 'ads'],
  SCAN_DEGRADED: ['warn', 'Проверка новых доменов прошла не полностью', 'd-jobs'], DNS_GUARD: ['info', 'Фильтрация для всех устройств применена', 'ads']
};
function adsEvent(rest) {
  const p = rest.split('|'), f = evFields(p);
  if (p[0] === 'CONTROL' && (p[1] === 'pause' || p[1] === 'resume')) return { tone: 'info', text: p[1] === 'pause' ? 'Проверка рекламы приостановлена' : 'Проверка рекламы возобновлена' };
  if (p[0] === 'SCHEDULER' && /failed/.test(p[1] || '')) return { tone: 'warn', text: 'Плановое обновление источников не удалось', go: 'd-sources' };
  if (p[0] === 'CLIENTS' && p[1] === 'clients/add') return { tone: 'info', text: 'Устройство добавлено в AdGuard Home: ' + (p[2] || '—'), go: 'd-agh' };
  if (p[0] === 'ROUTE_DNS') return ({ rows_set: { tone: 'ok', text: 'Домены маршрутов идут через DNS Keenetic: ' + fmtInt(f.domains), go: 'd-agh' },
    rows_removed: { tone: 'info', text: 'Домены маршрутов снова идут напрямую в AdGuard Home', go: 'd-agh' }, chain_failed: { tone: 'warn', text: 'DNS Keenetic не ответил - домены маршрутов не переданы', go: 'd-agh' } })[p[1]] || null;
  const m = ADS_EV[p[0]];
  return m ? { tone: m[0], text: m[1], go: m[2] } : null;
}
// The file integrity journal (fix.28.3): SPOILED|path|pkg=…, WRITTEN|path|by=…, REPAIR|…, SUMMARY|…
function integrityEvent(rest) {
  const p = rest.split('|'), f = evFields(p);
  const by = b => b === 'vward-update' ? 'обновление VWARD' : /^opkg:/.test(b || '') ? 'opkg, пакет ' + b.slice(5) : 'неизвестно кто';
  if (p[0] === 'SPOILED') return { tone: 'bad', text: 'Испорчен флешкой: ' + p[1] + (f.pkg && f.pkg !== 'vward' ? ' (пакет ' + f.pkg + ')' : ' (файл VWARD)') };
  if (p[0] === 'WRITTEN') return { tone: f.by === 'unknown' ? 'warn' : 'info', text: 'Изменён: ' + p[1] + ' - ' + by(f.by) };
  if (p[0] === 'REPAIR') return { tone: f.reinstalled ? 'ok' : 'warn', text: (f.reinstalled ? 'Переустановлено из Entware: ' + f.reinstalled.replace(/,/g, ', ') : 'Не переустановлено') + (f.held ? '; оставлено, чтобы не повторять по кругу: ' + f.held.replace(/,/g, ', ') : '') };
  if (p[0] === 'SUMMARY') return { tone: +f.spoiled ? 'bad' : 'ok', text: f.first ? 'Первая проверка: запомнено ' + fmtInt(f.files) + ' файлов' : 'Проверено ' + fmtInt(f.files) + ' файлов: испорчено ' + (f.spoiled || 0) + ', изменено ' + (f.written || 0) + (+f.unknown ? ', из них неизвестно кем ' + f.unknown : '') };
  return null;
}
const ACTIVITY = {
  adaptive: { title: 'История автоподбора', parent: 'routes', logs: ['adaptive'], read: l => routeEvent(l, ROUTE_ADAPTIVE), desc: 'Что автоподбор отправил в VPN или вернул.', data: ['config', 'route'] },
  routing: { title: 'История сверки маршрутов', parent: 'routes', logs: ['adaptive', 'routing'], read: (l, n) => n === 'adaptive' ? routeEvent(l, ROUTE_MAINT) : null, desc: 'Проверка, какие домены можно вернуть напрямую.', data: ['config', 'route'],
    top: () => cfgNote() + (confirmBox('route-reconcile', 'Сверить маршруты роутера с каталогом сейчас?', 'Выполнить') || '<div class="panel-actions">' + btn('ask', 'check', 'Сверить сейчас', '', ' data-confirm="route-reconcile"') + '</div>') + resultBox('routes') },
  policy: { title: 'История IP-категорий', parent: 'vpn', logs: ['policysync', 'policy'], read: policyEvent, desc: 'Обновление подсетей сервисов.', data: ['config', 'route'],
    top: () => (confirmBox('policy-refresh', 'Скачать IP-категории заново и пересобрать маршруты? Это займёт 1-2 минуты.', 'Выполнить') || '<div class="panel-actions">' + btn('ask', 'refresh', 'Обновить сейчас', '', ' data-confirm="policy-refresh"') + '</div>') + resultBox('routes') },
  tunnel: { title: 'История агента VPN', parent: 'vpn', logs: ['tunnel'], read: l => { const p = l.split('|'), m = TUNNEL_EV[p[0]]; return m ? { tone: m[0], text: m[1] } : null; }, desc: 'Что делала агент VPN.', data: ['status', 'config'] },
  wan: { title: 'История подключения', parent: 'wan', logs: ['wan', 'recovery'], read: wanEvent, desc: 'Когда пропадал интернет и что сделал VWARD.', data: ['status', 'config'] },
  wifi: { title: 'История Wi-Fi', parent: 'wifi', logs: ['wifi'], read: wifiEvent, desc: 'Переходы устройств между 2.4 и 5 ГГц.', data: ['wifi'] },
  updater: { title: 'История обновлений', parent: 'u-vward', logs: ['updater'], read: updaterEvent, desc: 'Когда VWARD проверял и ставил обновления.', data: ['status', 'update', 'config'] },
  ads: { title: 'История блокировки рекламы', parent: 'ads', logs: ['ads'], read: adsEvent, desc: 'Что VWARD делал с рекламой.', data: ['ads'] },
  integrity: { title: 'Целостность файлов', parent: 'system', logs: ['integrity'], read: integrityEvent, desc: 'Раз в сутки агент обслуживания сверяет файлы программ со вчерашними: испорченные флешкой и кем изменённые.', data: ['status'] }
};
// What can be done with a domain from its event, by where it is now.
function domainActs(h) {
  if (!h || !S.config || !DOMAIN.test(h)) return '';
  const r = cfgRoute(), has = (l, x) => (l || []).some(d => (typeof d === 'string' ? d : d.domain) === x);
  if (has(r.force_vpn, h)) return '<small class="ev-state">всегда через VPN</small>' + rowBtn('force-vpn', 'remove', h, 'close', 'Снять с ' + h + ' «всегда через VPN»');
  if (has(r.domains, h)) return '<small class="ev-state">в моих доменах</small>';
  if (has(r.adaptive, h)) return rowBtn('adaptive', 'pin', h, 'lock', 'Закрепить ' + h + ' в моих доменах') + rowBtn('adaptive', 'remove', h, 'close', 'Вернуть ' + h + ' на прямой маршрут');
  return rowBtn('force-vpn', 'add', h, 'shield', 'Всегда пускать ' + h + ' через VPN');
}
// "2026-09-27 04:26:52", "2026-09-27T04:26:52+0300", "2026-09-27T01:26:52Z" -> ms and the rest of the line.
function evTime(line) {
  const m = /^(\d{4}-\d\d-\d\d)[ T](\d\d:\d\d:\d\d)(Z|[+-]\d\d:?\d\d)?/.exec(line); if (!m) return null;
  const d = new Date(m[1] + 'T' + m[2] + (m[3] ? (m[3] === 'Z' ? 'Z' : m[3].replace(/^([+-]\d\d):?(\d\d)$/, '$1:$2')) : ''));
  return isNaN(d) ? null : { ts: d.getTime(), rest: line.slice(m[0].length).replace(/^[|\s]+/, '') };
}
function evAt(ts) {
  const d = new Date(ts), now = new Date(), hm = d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  return d.toDateString() === now.toDateString() ? hm : d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }) + ' ' + hm;
}
// Events of a section, newest first; the same event in a row is shown once with a count.
function activityEvents(k) {
  const a = ACTIVITY[k], out = [];
  a.logs.forEach(n => String(S.act[n] || '').split('\n').forEach(line => {
    const t = evTime(line.trim()); if (!t) return;
    let e = null; try { e = a.read(t.rest, n); } catch (x) { e = null; }
    if (e) out.push(Object.assign(e, { ts: t.ts }));
  }));
  out.sort((x, y) => y.ts - x.ts);
  return out.reduce((acc, e) => { const last = acc[acc.length - 1]; if (last && last.text === e.text) last.n = (last.n || 1) + 1; else acc.push(e); return acc; }, []);
}
// owner 12.11.2026: a history reads the last ACT_LINES lines of its journals (it read 1000 every
// 15 s), shows the last 50 events, «Показать ещё» shows 50 more (reading further back when its
// lines run out), «Обновить» reads again; nothing by itself.
const ACT_LINES = 200, ACT_STEP = 50, ACTLINES = {}, ACTSHOW = {}, ACTAT = {}, ACTFULL = {}, ACTRUN = {};
async function loadActivity(k) {
  const a = ACTIVITY[k]; if (!a || ACTRUN[k]) return;
  const lines = ACTLINES[k] || ACT_LINES; ACTRUN[k] = true;
  let full = false;
  try {
    await Promise.all(a.logs.map(async n => {
      try { const x = await apiText('log', { name: n, count: lines }); S.act[n] = x; if (x.split('\n').filter(Boolean).length >= lines) full = true; }
      catch (e) { if (S.act[n] == null) S.act[n] = ''; }
    }));
  } finally { ACTRUN[k] = false; }
  ACTFULL[k] = full && lines < LOG_MAX; ACTAT[k] = Date.now();
  if (current === 'a-' + k && !editing) render();
}
// «Показать ещё»: 50 more events; when the lines read hold no more, read twice as far back.
function activityMore(k) {
  const have = activityEvents(k).length;
  ACTSHOW[k] = (ACTSHOW[k] || ACT_STEP) + ACT_STEP;
  if (have < ACTSHOW[k] && ACTFULL[k]) { ACTLINES[k] = Math.min(LOG_MAX, (ACTLINES[k] || ACT_LINES) * 2); loadActivity(k); }
  render();
}
function activityPage(k) {
  const a = ACTIVITY[k];
  if (a.logs.some(n => S.act[n] == null)) return panel(a.title, empty('Загрузка…'), { desc: a.desc });
  const all = activityEvents(k), show = ACTSHOW[k] || ACT_STEP, ev = all.slice(0, show);
  let head = '';
  if (k === 'routing') {
    const m = /Checked=(\d+)\s+Total=(\d+)/.exec(S.act.routing || '');
    if (m) head = kv([['Последняя сверка', 'проверено ' + fmtInt(m[1]) + ' из ' + fmtInt(m[2]) + ' ' + plural(num(m[2]) || 0, 'домена', 'доменов', 'доменов')]]);
  }
  const t = ACTAT[k] || 0;
  const top = a.top ? a.top() : '', seen = new Set();
  const row = e => {
    // A domain's controls sit on its newest event only.
    const acts = e.host && !seen.has(e.host) ? (seen.add(e.host), domainActs(e.host)) : '';
    return '<li class="ev ' + (e.tone || 'info') + (e.go && page(e.go) ? ' link" role="button" tabindex="0" data-go="' + esc(e.go) + '"' : '"') + '><span class="ev-dot" aria-hidden="true"></span><span class="ev-text">' + esc(e.text) + (e.n > 1 ? ' <span class="ev-n">×' + e.n + '</span>' : '') + '</span>' +
      (acts ? '<span class="row-acts ev-acts">' + acts + '</span>' : '') + '<span class="ev-at">' + esc(evAt(e.ts)) + '</span></li>';
  };
  const more = all.length > show || ACTFULL[k];
  return (a.topOwn ? top : '') + panel(a.title, (a.topOwn ? '' : top) + head + (ev.length ? '<ul class="events">' + ev.map(row).join('') + '</ul>'
    : empty('Пока ничего не происходило')) +
    '<div class="panel-actions even">' + (more ? btn('act-more', '', 'Показать ещё ' + ACT_STEP, '', ' data-k="' + k + '"') : '') +
      btn('act-reload', 'refresh', 'Обновить', '', ' data-k="' + k + '"' + (ACTRUN[k] ? ' disabled' : '')) + '</div>', { desc: a.desc });
}
Object.keys(ACTIVITY).forEach(k => {
  DETAILS['a-' + k] = { title: ACTIVITY[k].title, parent: ACTIVITY[k].parent, data: ACTIVITY[k].data || [] };
  RENDER['a-' + k] = () => activityPage(k);
});
// A component's own events page, by the journal it writes.
const activityOf = log => log === 'recovery' ? 'wan' : ACTIVITY[log] ? log : null;
function fmtTime(t) { const d = new Date(t); return isNaN(d) ? (t || '') : d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); }
const FILE_ROOTS = [['etc', 'Настройки', '/opt/etc/vward'], ['state', 'Состояние', '/opt/var/lib/vward'], ['logs', 'Журналы', '/opt/var/log/vward'], ['share', 'Программа', '/opt/share/vward']];
const filePath = name => (FILES.path ? FILES.path + '/' : '') + name;
function filesGo(root, path) { FILES.root = root; FILES.path = path; S.files = null; render(); load('files', true).then(render); }
async function fileOpen(name) {
  const path = filePath(name), dl = '/cgi-bin/api.cgi?action=files&op=download&root=' + encodeURIComponent(FILES.root) + '&path=' + encodeURIComponent(path);
  openSheet(name, '<div class="sheet-body">' + empty('Загрузка…') + '</div>', 'wide');
  let x; try { x = await apiGet('files', { op: 'read', root: FILES.root, path: path }); } catch (e) { x = { ok: false, error: e.message }; }
  const note = !x.ok ? errText(x) : x.binary ? 'Двоичный или сжатый файл: можно только скачать.' : x.truncated ? (x.from_end ? 'Показан конец файла - последние 64 КБ.' : 'Показано начало файла - первые 64 КБ.') : '';
  const body = '<div class="sheet-body"><p class="panel-desc">' + esc(fmtBytes(x.size)) + (note ? ' · ' + esc(note) : '') + '</p>' +
    (x.ok ? '<div class="panel-actions"><a class="btn" href="' + esc(dl) + '" download>' + ico('save') + 'Скачать</a></div>' : '') + (x.ok && !x.binary ? '<pre class="logbox">' + esc(x.text) + '</pre>' : '') + '</div>';
  const sh = document.querySelector('#layer .sheet');
  if (!sh || sh.getAttribute('aria-label') !== name) return;
  sh.querySelector('.sheet-body').outerHTML = body;
  // A log is read from its end: show the newest lines first.
  if (FILES.root === 'logs') { const b = sh.querySelector('.sheet-body'); b.scrollTop = b.scrollHeight; }
}
// Domain check: queued as a job; the page waits for its report and sums it up.
const JOB_TEXT = { scan: 'Проверка новых доменов', 'sources-update': 'Обновление источников', 'rules-rebuild': 'Пересборка правил', publish: 'Публикация правил в AdGuard Home', probe: 'Анализ домена' };
const JOB_STATE = { DONE: 'выполнено', PASS: 'выполнено', FAILED: 'ошибка', RUNNING: 'выполняется', QUEUED: 'в очереди' };
const jobText = q => (JOB_TEXT[q.type] || q.type || 'задание') + (q.arg ? ' ' + q.arg : '');
let PROBE = null;
async function adsProbe(domain) {
  PROBE = { domain: domain, text: 'в очереди…' }; render();
  let x;
  try { x = await apiPost('ads-control', { op: 'enqueue', job: 'probe', domain: domain }); } catch (e) { x = { ok: false, error: e.message }; }
  const id = x.ok && (/JOB_ID=(\S+)/.exec(x.result || '') || [])[1];
  if (!id) { PROBE = { domain: domain, done: true, error: errText(x) }; render(); return; }
  for (let i = 0; i < 60 && PROBE && PROBE.domain === domain; i++) {
    await new Promise(r => setTimeout(r, 3000));
    await load('ads', true);
    const j = (S.ads && S.ads.jobs) || {}, l = j.last || {};
    if (l.id === id) { PROBE = { domain: domain, done: true, failed: l.state === 'FAILED', out: l.output || '' }; render(); return; }
    PROBE.text = j.current && j.current.type === 'probe' ? 'проверяется…' : 'в очереди…'; render();
  }
  if (PROBE && PROBE.domain === domain && !PROBE.done) { PROBE = { domain: domain, done: true, error: 'проверка ещё в очереди - результат появится в «Задания»' }; render(); }
}
function probeResult() {
  const p = PROBE;
  if (!p) return '';
  if (!p.done) return '<p class="result-note">' + esc(p.domain) + ': ' + esc(p.text) + '</p>';
  if (p.error || p.failed) return '<p class="result-note">' + esc(p.domain) + ': ' + esc(p.error || 'проверка не удалась, подробности в «Журналах»') + '</p>';
  const o = p.out, has = k => new RegExp('^' + k + '=MATCH$', 'm').test(o);
  const sec2 = (o.split('=== 2.')[1] || '').split('\n').map(x => x.trim()).filter(Boolean)[1] || '';
  const vr = sec2.split('|'), known = vr.length >= 8 && vr[0] === p.domain;
  const v = known ? (ADS_VERDICT[vr[1]] || ['', vr[1]]) : null;
  const names = (o.match(/^[^|\n]+\|mode=[a-z]+\|match=[^\n]*$/gm) || []).map(l => (/\|name=(.*)$/.exec(l) || [])[1]).filter(Boolean);
  const q = num((/^QUERY_COUNT=(\d+)/m.exec(o) || [])[1]);
  return kv([
    ['Решение VWARD', v ? v[1] : 'ещё не проверялся', v ? v[0] : '', null, '', known ? ADS_REASON[vr[7]] || vr[7] : ''],
    has('ALLOWLIST') ? ['Ваше правило', 'Разрешить', 'ok'] : has('DENYLIST') ? ['Ваше правило', 'Блокировать', 'crit'] : null,
    has('TRUST') ? ['Доверенный сервис', 'Да', 'ok'] : null,
    ['Найден в источниках', names.length ? fmtInt(names.length) + ' ' + plural(names.length, 'источник', 'источника', 'источников') : 'нет', '', null, '', names.slice(0, 3).join(', ')],
    ['Запросов в журнале', q != null ? fmtInt(q) : '—']
  ]) + '<div class="panel-actions">' + adsRuleBtn(p.domain, 'allow') + adsRuleBtn(p.domain, 'block') + btn('probe-report', 'logs', 'Полный отчёт', 'small') + '</div>';
}
// A short choice of 2-4 options as one slider, like the Wi-Fi bands (owner 2026-10-17).
// OPTS: [value, label, disabled]; a click goes to segPick(KEY, value).
const choicePrev = {};
function choiceSlider(key, opts, cur, label, local) {
  // A value none of the choices names (a retired channel) selects nothing: no thumb.
  const at = opts.findIndex(o => o[0] === cur), to = Math.max(0, at), from = choicePrev[key] != null ? choicePrev[key] : to, on = local || cfgOk();
  choicePrev[key] = to;
  // A long last label (`Авто | VPN | DNS | Провайдер`, owner 02.11: «Провай…») gets a wider segment.
  const wide = opts.length === 4 && String(opts[3][1]).length >= 8 ? ' last-wide' : '';
  return '<div class="seg-slider' + (['', '', ' two', '', ' four'][opts.length] || '') + wide + (on ? '' : ' off') + (at < 0 ? ' none' : '') + '" role="radiogroup" aria-label="' + esc(label) + '" data-i="' + from + '" data-to="' + to + '"><i class="seg-thumb"></i>' +
    opts.map(o => '<button type="button" role="radio" data-seg="' + key + '" data-v="' + esc(o[0]) + '" aria-checked="' + (o[0] === cur) + '"' + (on && !o[2] ? '' : ' disabled') + '>' + esc(o[1]) + '</button>').join('') + '</div>';
}
function segPick(key, v) {
  if (key === 'ad-way') { const d = ADV.open; if (!d || v === 'auto') return; ADV.open = '';
    cfgSet({ op: 'adaptive', action: v === 'vpn' ? 'pin' : 'remove', target: d }, v === 'vpn' ? d + ': всегда через VPN' : d + ': напрямую, автоподбор его больше не берёт', ['route', 'config']); return; }
  if (key === 'site-do') { if (v === 'block') { confirm = { id: 'site-block', dom: SITEDOM }; render(); } else siteDo(v, SITEDOM); return; }
  if (key === 'vsrv-sort') { VVIEW.sort = v; vViewSave(); render(); }
  else if (key === 'sd-store') sdStoreSet(v);
  else if (key === 'upd-mode') updateMode(v);
  else if (key === 'upd-method') cfgSet({ op: 'update', target: 'update_method', value: v }, v === 'files' ? 'Способ: изменённые файлы' : 'Способ: целиком', ['status']);
  else if (key === 'tq-speed') cfgSet({ op: 'tunnel-auto', target: 'speed', value: v }, 'Замер скорости: ' + (TQ_SPEED.find(o => o[0] === v) || [, v])[1], ['tq']);
  else if (key === 'upd-feed') feedPick(v);
  else if (key === 'list-mode-all') { const ls = ((S.lists && S.lists.lists) || []).filter(l => l.managed && !svcOf(l.name) && l.name !== (cfgRoute().group || prof().policy_group) && listMode(l) !== v);
    if (ls.length) listBulk({ op: 'list-mode', value: v }, ls.map(l => l.name), 'Все списки: ' + LIST_MODES.find(m => m[0] === v)[1]); }
  else if (key.startsWith('list-mode:')) { const g = key.slice(10), l = ((S.lists && S.lists.lists) || []).find(x => x.name === g);
    if (l && !l.managed && !l.dns_mode) { confirm = { id: 'list-adopt', name: g, then: v }; render(); } else listModeSet(g, v); }
  else if (key.startsWith('list-tun:')) cfgSet({ op: 'domain-list', target: key.slice(9), value: v }, 'Маршрут списка: ' + tunLabel(v), ['lists']);
  else if (key.startsWith('svc-tun:')) { if (!SVC.busy) serviceJob({ op: 'tunnel', id: key.slice(8), tunnel: v }, v === 'auto' ? 'Туннель выбирается автоматически' : 'Закреплён за ' + tunLabel(v)); }
}
// Update channels (owner 2026-11-01): «Стабильная» = branch main, «Разработка» = branch dev.
// beta is the retired channel: an install that follows it is shown as such and is never
// moved by itself; the owner picks one of the two (the settings are kept either way).
const FEED_HINT = {
  main: 'проверенные выпуски; обновление придёт, когда выйдет выпуск новее установленного',
  dev: 'сборки в разработке, возможны ошибки',
  beta: 'прежний канал «Бета»: новые сборки в нём не выходят. Выберите канал - настройки сохранятся'
};
function feedPick(v) {
  const cur = (cfg().update || {}).feed;
  if (v === cur || !(v in FEED_HINT) || v === 'beta') return;
  confirm = { id: v === 'dev' ? 'feed-dev' : 'feed-main' }; render();
}
// The blocked share of AdGuard Home's queries with sense for small numbers: 191 of 38 232 is
// «≈ 0,5 %», not «0%»; a non-zero share under 0,1 % is «< 0,1 %»; no queries - no share.
function blockedShare(blocked, queries) {
  const b = Number(blocked) || 0, q = Number(queries) || 0;
  if (!q) return '';
  const p = 100 * b / q, t = !b ? '0' : p < 0.1 ? '< 0,1' : p < 10 ? (Math.round(p * 10) / 10).toFixed(1).replace('.', ',').replace(',0', '') : String(Math.round(p));
  return ' · ' + (!b || p < 0.1 ? '' : '≈ ') + t + '\u00a0%';
}
// The state of VWARD's own check (ads-ui): [class, text, link]. «Ожидает следующей проверки» is
// grey; green only when the last check finished within a day; no answer - «Нет данных».
function adsNow(a, s, j, sc, off, runMode) {
  const cur = j.current || {}, busy = cur.state && cur.state !== 'IDLE', last = j.last || {};
  if (!S.ads) return ['', 'Нет данных'];
  if (S.cached.ads) return ['', 'Нет данных', '', 'роутер ещё не ответил'];
  if (off) return ['warn', 'Компонент выключен', 'c-ads-privacy-guard'];
  if (a.paused) return ['warn', 'На паузе'];
  if (!a.agh_connected) return ['warn', 'Нет подключения к AdGuard Home', 'd-agh'];
  if (busy) return ['info', 'выполняется: ' + jobText(cur).toLowerCase() + (num(j.queued) ? ' · ещё ' + fmtInt(j.queued) + ' в очереди' : ''), 'd-jobs'];
  if (last.state === 'FAILED' && last.type === 'scan') return ['crit', 'последняя проверка с ошибкой', 'd-jobs'];
  if (num(j.queued)) return ['info', fmtInt(j.queued) + ' ' + plural(num(j.queued), 'задание', 'задания', 'заданий') + ' в очереди', 'd-jobs'];
  const at = sc.last_run ? Date.parse(String(sc.last_run).replace(' ', 'T')) : NaN, fresh = !isNaN(at) && Date.now() - at < 26 * 3600e3;
  const how = ({ scheduled: 'ожидает следующей проверки', dynamic: 'проверяет новые домены сразу', manual: 'проверка только по кнопке' })[runMode] || 'включена';
  return fresh ? ['ok', 'работает · ' + how, 'd-jobs'] : ['', how + (sc.last_run ? '' : ' · проверок ещё не было'), 'd-jobs'];
}
const THEME_OPS = [['light', 'Светлая'], ['dark', 'Тёмная'], ['system', 'Система'], ['time', 'По времени']];
let themePrev = null;
function themeSlider() {
  const to = Math.max(0, THEME_OPS.findIndex(o => o[0] === theme)), from = themePrev != null ? themePrev : to; themePrev = to;
  return '<div class="seg-slider four" role="radiogroup" aria-label="Тема оформления" data-i="' + from + '" data-to="' + to + '"><i class="seg-thumb"></i>' +
    THEME_OPS.map(o => '<button type="button" role="radio" data-theme-set="' + o[0] + '" aria-checked="' + (o[0] === theme) + '">' + o[1] + '</button>').join('') + '</div>';
}
function devicesHint(au) {
  const d = au.device || {}, where = d.ip ? ' (' + d.ip + ')' : '';
  if (d.state === 'registered') return 'это устройство зарегистрировано' + where;
  if (d.state === 'unknown') return 'список устройств Keenetic сейчас недоступен';
  return 'это устройство не зарегистрировано' + where + ' - сначала зарегистрируйте его в Keenetic';
}
// Smart DNS rows may sit in Keenetic, in AdGuard Home, or in both.
function smartdnsWhere(L) {
  const src = L.smartdns_sources || {}, k = (src.keenetic || []).length, a = (src.adguard || []).length;
  return k && a ? 'Keenetic и AdGuard Home' : a ? 'AdGuard Home' : k ? 'Keenetic' : 'не найден';
}
// «Что нового»: a version's section of the CHANGELOG, from the router (installed)
// or from the update feed (an update on offer).
const NOTES = {};
function notesVersions() { const p = plat(), pend = (S.update && S.update.pending) || {}; return [pend.present && pend.version, p.version].filter(Boolean); }
async function loadNotes(v) {
  if (NOTES[v] && NOTES[v].ok) return;
  try { NOTES[v] = await apiGet('release-notes', { version: v }); } catch (e) { NOTES[v] = { ok: false, error: e.message }; }
  if (current === 'd-notes') render();
}
function notesHtml(v) {
  if (!v) return empty('Версия неизвестна');
  const n = NOTES[v];
  if (!n) return empty('Загрузка…');
  if (!n.ok) return empty(n.error === 'notes_unavailable' ? 'Описание этой версии не найдено' : errText(n));
  const fmt = t => esc(t).replace(/`([^`]+)`/g, '<code>$1</code>');
  let html = '', items = [], title = '';
  const flush = () => { if (items.length) { html += '<ul class="notes">' + items.map(i => '<li>' + fmt(i) + '</li>').join('') + '</ul>'; items = []; } };
  n.text.split('\n').forEach(l => {
    if (l.startsWith('#title ')) { title = l.slice(7); return; }
    if (!l.trim()) return;
    if (/^- /.test(l)) items.push(l.slice(2));
    else if (/^\s+\S/.test(l) && items.length) items[items.length - 1] += ' ' + l.trim();
    else { flush(); html += '<p class="notes-sub">' + fmt(l.trim()) + '</p>'; }
  });
  flush();
  return (title ? '<p class="panel-desc">' + esc(title) + '</p>' : '') + (html || empty('Без описания'));
}
const ADS_VERDICT = { BLOCK: ['crit', 'Заблокирован'], SUSPECT: ['warn', 'На проверке'], ALLOW: ['ok', 'Разрешён'], TRUST: ['ok', 'Доверенный'] };
const ADS_REASON = { manual_denylist: 'ваше правило', manual_allowlist: 'ваше правило', trusted_registry: 'доверенный сервис', dedicated_block_feed: 'есть в специальном списке рекламы', multi_source_consensus: 'найден в нескольких источниках', external_verifier: 'внешняя проверка', source_catalog_degraded: 'источники недоступны, решение отложено', block_evidence_disappeared_review: 'пропал из источников, перепроверяется', no_block_evidence: 'признаков рекламы нет' };
function adsRuleBtn(d, type) { return '<button class="icon-btn" type="button" data-ads-rule="' + type + '" data-domain="' + esc(d) + '" aria-label="' + (type === 'allow' ? 'Разрешить ' : 'Заблокировать ') + esc(d) + '" title="' + (type === 'allow' ? 'Разрешить' : 'Заблокировать') + '">' + ico(type === 'allow' ? 'check' : 'block') + '</button>'; }
async function adsViews() { await Promise.all(['ads', 'adspub', 'qlog', 'review', 'blocked'].map(k => S[k] || k === 'ads' || k === 'adspub' ? load(k, true) : null)); render(); }
function fmtBytes(b) { b = num(b); if (b == null) return '—'; const u = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ']; let i = 0; while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; } return (i ? b.toFixed(1) : String(b)) + ' ' + u[i]; }
// Keenetic gives a tunnel that never had a handshake a huge age (2^31 s, "24855 д").
const hsSec = t => { const h = t && t.handshake != null ? num(t.handshake) : null; return h == null || isNaN(h) || h >= 315360000 ? null : h; };
function agoText(sec) { if (sec == null || isNaN(sec)) return '—'; if (sec < 60) return sec + ' с назад'; if (sec < 3600) return Math.round(sec / 60) + ' мин назад'; if (sec < 86400) return Math.round(sec / 3600) + ' ч назад'; return Math.round(sec / 86400) + ' д назад'; }
// An interval in plain units: 900 → «15 мин», 86400 → «24 ч».
function durText(sec) { const n = num(sec); if (n == null) return '—'; if (n < 60) return n + '\u00a0с'; if (n < 3600) return Math.round(n / 60) + '\u00a0мин'; return Math.round(n / 3600) + '\u00a0ч'; }
// fix.38.1: one script, two cron lines - told apart by the line's status file.
const JOB_TAGS = { 'vward-ads-scheduler': 'Блокировка рекламы: проверка доменов', 'vward-ads-dns-tick': 'Блокировка рекламы: слежение за DNS' };
const JOB_NAMES = { 'vward-route-reconciler.sh': 'Сверка маршрутов', 'S91vward-route-engine': 'Перезапуск маршрутизации', 'vward-policy-chain.sh': 'Обновление IP-категорий', 'vward-route-hints-update.sh': 'Подсказки каталога', 'vward-tunnel-health.sh': 'Агент VPN', 'S92vward-runtime': 'Агент компонентов', 'vward-wan-guard.sh': 'Восстановление интернета', 'vward-housekeeping.sh': 'Сжатие журналов', 'vward-ads-privacy-scheduler.sh': 'Блокировка рекламы', 'vward-wifi-client-scheduler.sh': 'Контроль Wi-Fi клиентов' };
const JOB_COMPONENT = { 'S91vward-route-engine': 'route-engine' };
function cronText(c) {
  const f = String(c || '').split(' ');
  if (f.length !== 5) return c || '';
  if (f.join(' ') === '* * * * *') return 'каждую минуту';
  if (/^\*\/\d+$/.test(f[0]) && f.slice(1).join(' ') === '* * * *') return 'каждые ' + f[0].slice(2) + ' мин';
  if (/^\d+$/.test(f[0]) && f.slice(1).join(' ') === '* * * *') return 'каждый час в :' + ('0' + f[0]).slice(-2);
  if (/^\d+$/.test(f[0]) && /^\d+$/.test(f[1]) && f.slice(2).join(' ') === '* * *') return 'каждый день в ' + ('0' + f[1]).slice(-2) + ':' + ('0' + f[0]).slice(-2);
  return c;
}
function bandText(b) { return b === '5' ? '5 ГГц' : b === '2.4' ? '2.4 ГГц' : 'диапазон неизвестен'; }
// Two lists of one service under names that differ only in case or signs (Viva 2026-10-19:
// «Youtube» 172 and «YouTube» 188 domains): the smaller one goes into the bigger one.
const listKey = n => String(n || '').toLowerCase().replace(/[^a-z0-9а-яё]/g, '');
function listDups(items) {
  const own = cfgRoute().group || prof().policy_group, by = {};
  items.filter(l => l.name !== 'AdaptiveAuto' && l.name !== own).forEach(l => { const k = listKey(l.name); if (k) (by[k] = by[k] || []).push(l); });
  return Object.values(by).filter(g => g.length > 1).map(g => g.sort((a, b) => num(b.count) - num(a.count)));
}
// fix.38.1 (owner 12.11.2026, «пустые списки можешь удалять, наводи порядок»): lists with no domain
// keep a route and carry nothing; VWARD names them and deletes them on the owner's one confirmation
// (each with its backup, as «Удалить список»). Never on its own: a list that is not VWARD's is the owner's.
const listEmpty = items => items.filter(l => !l.count && !listOwn(l) && l.name !== 'AdaptiveAuto' && !svcOf(l.name));
function listEmptyPanel(items) {
  const e = listEmpty(items);
  if (!e.length) return '';
  const names = e.map(l => '«' + (l.description || l.name) + '»').join(', ');
  return panel('Пустые списки', (confirmBox('list-empty-del', 'Удалить ' + e.length + ' ' + plural(e.length, 'пустой список', 'пустых списка', 'пустых списков') + ' (' + names + ')? Из Keenetic уйдут списки и их маршруты; доменов в них нет. Перед каждым сохранится копия настроек.', 'Удалить', true) ||
      '<p class="panel-desc">Без доменов: ' + esc(names) + '. Маршрут у них есть, направлять нечего.</p><div class="panel-actions">' +
      btn('ask', 'trash', 'Удалить пустые', 'danger', ' data-confirm="list-empty-del"' + (cfgOk() && !LISTBULK.busy ? '' : ' disabled')) + '</div>'));
}
async function listEmptyDelete() {
  // The lists are read again first: a list that got a domain meanwhile is left alone.
  await load('lists', true);
  const names = listEmpty(((S.lists && S.lists.lists) || []).filter(l => !svcOf(l.name))).map(l => l.name);
  if (names.length) await listBulk({ op: 'list', action: 'delete', confirm: 'LIST_DELETE' }, names, 'Удаление пустых списков'); else render();
}
function listDupPanel(items) {
  const dups = listDups(items);
  if (!dups.length) return '';
  return panel('Похожие списки', dups.map(g => { const [to, ...from] = g, f = from[0];
    return confirmBox('list-merge-' + f.name, 'Объединить «' + (f.description || f.name) + '» (' + fmtInt(f.count) + ') с «' + (to.description || to.name) + '» (' + fmtInt(to.count) + ')? Домены перейдут в «' + (to.description || to.name) + '» и пойдут по его маршруту, список «' + (f.description || f.name) + '» удалится. Перед этим сохранится резервная копия.', 'Объединить') ||
      '<p class="panel-desc">«' + esc(f.description || f.name) + '» (' + fmtInt(f.count) + ') и «' + esc(to.description || to.name) + '» (' + fmtInt(to.count) + ') - похоже, один и тот же сервис.</p><div class="panel-actions">' +
      btn('ask', 'list', 'Объединить', '', ' data-confirm="list-merge-' + esc(f.name) + '" data-name="' + esc(f.name) + '" data-what="' + esc(to.name) + '"' + (cfgOk() ? '' : ' disabled')) + '</div>'; }).join(''),
    { desc: 'Два списка одного сервиса делят его домены и маршруты; объединённый список проще вести.' });
}
const WIFI_EMPTY = { not_collected: 'Сбор ещё не запускался: первые данные появятся в течение 10 минут', collect_failed: 'Сбор завершился с ошибкой: подробности в журнале Wi-Fi',
  keenetic_empty: 'Keenetic не вернул список устройств', no_wifi: 'Keenetic не видит устройств в Wi-Fi' };
const WIFI_REASONS = { stable: 'переходы редкие, сигнал в норме', frequent_band_switches: 'часто переходит между 2.4 и 5 ГГц', frequent_switches_and_weak_5g: 'часто переходит и слабый сигнал 5 ГГц' };
function recText(c) { return c.recommendation === 'bind_2g' ? 'Закрепить за 2.4' : c.recommendation === 'review' ? 'Проверить' : c.health === 'WARNING' ? 'Внимание' : 'Норма'; }

// The lists and subnets of the old tunnel besides VWARD's own: a lost tunnel always gives them
// up (it carries nothing), a working one asks (Viva 2026-10-19: 19 lists stayed on OpkgTun2).
function tunUseExtra(cur) {
  const L = S.lists || {}, own = cfgRoute().group || prof().policy_group;
  const lists = (L.lists || []).filter(l => l.route === cur && l.name !== own && l.name !== 'AdaptiveAuto').length;
  const nets = (L.subnet_counts || {})[cur] != null ? L.subnet_counts[cur] : ((L.subnets || {})[cur] || []).length;
  return lists + num(nets || 0);
}
function tunUseConfirm(name, cur, up) {
  const box = confirmBox('tunnel-use', 'Перевести маршруты VWARD' + (cur ? ' с ' + tunLabel(cur) : '') + ' на ' + tunLabel(name) + '? Мои домены, автоподбор доменов и IP-категории пойдут через ' + tunLabel(name) + '.' + (up ? '' : ' Туннель сейчас не в сети: сайты из списков VPN будут недоступны, пока он не подключится.'), 'Переключить', !up);
  if (!box || !cur) return box;
  const n = tunUseExtra(cur), t = ((st().wg || {}).interfaces || []).find(x => x.name === cur);
  if (!n) return box;
  if (tunLost(t)) return box + '<p class="result-note">Списки и подсети туннеля ' + esc(tunLabel(cur)) + ' (' + n + ') тоже перейдут: у него нет настроек.</p>';
  return box + '<label class="check-row"><input type="checkbox" data-tun-move-all' + (confirm.moveAll === false ? '' : ' checked') + '> Перенести и списки этого туннеля (' + n + ')</label>';
}
document.addEventListener('change', e => { if (e.target.matches && e.target.matches('[data-tun-move-all]') && confirm && confirm.id === 'tunnel-use') confirm.moveAll = e.target.checked; });

function tunnelPage(name) {
  const wg = st().wg || {}, t = (wg.interfaces || []).find(x => x.name === name) || { name: name };
  const up = isTrue(t.connected), cur = prof().tunnel_interface, managed = cur === name, failopen = isTrue(wg.failopen_active);
  const use = managed || tunLost(t) ? '' : tunOff(t) ? '<p class="field-warn">Туннель выключен: назначить его туннелем по умолчанию можно после включения.</p>' : failopen ? '<p class="field-warn">Сейчас VPN недоступен и трафик идёт напрямую: переключение станет доступно, когда ' + esc(cur ? tunLabel(cur) : 'текущий туннель') + ' восстановится.</p>' :
    tunUseConfirm(name, cur, up) ||
    '<div class="panel-actions">' + btn('ask', 'route', 'Сделать туннелем по умолчанию', up ? 'primary' : '', ' data-confirm="tunnel-use"' + (cfgOk() ? '' : ' disabled')) + '</div>';
  // Without settings it cannot be switched on: no «Включить», no switch; how to bring it back - first (owner 12.11.2026).
  const lost = tunLost(t), off = tunOff(t) && !lost, e = awgOf(name), v = vlessOf(name), mp = tunnelManagePanel(name, managed);
  const rx = t.rx != null ? t.rx : e && e.rx, tx = t.tx != null ? t.tx : e && e.tx;
  const gOff = tunGuardOff(t), wgs = st().wg || {};
  return (lost ? mp[0] : '') + (gOff ? panel('Выключен агентом', '<p class="panel-desc">' + esc((wgs.failopen_at ? 'С ' + fmtTime(wgs.failopen_at * 1000) + '. ' : '') + (foText(wgs) ? 'Причина: ' + foText(wgs) + '. ' : '') +
      'Сайты из списков идут напрямую. Агент проверяет туннель раз в 5 минут и включит его сам, когда туннель ответит.') + '</p>') : '') +
    (off ? panel('Туннель выключен', '<p class="panel-desc">Трафик через туннель не идёт' + (managed ? ': он назначен по умолчанию, списки VPN идут напрямую. Его выключили в настройках Keenetic или вне Панели. ' : '. ') + '«Включить» включит его' + (e || v ? ' вместе с программой модуля' : '') + ' и сохранит настройку.</p>' +
      '<div class="panel-actions">' + btn('tunnel-up', 'check', 'Включить', 'primary', ' data-name="' + esc(name) + '"' + (cfgOk() && !TUNBUSY[name] ? '' : ' disabled')) + '</div>') : '') +
    panel(tunLabel(name), kv([
    ['Системное имя', name + (e ? ' · модуль AmneziaWG (VWARD)' : v ? ' · VLESS (VWARD)' : t.type ? ' · ' + (t.type === 'wireguard' && t.awg ? 'AmneziaWG' : TUN_TYPE[t.type] || t.type) : '')],
    ['Канал связи', t.link === 'up' ? 'есть' : t.link === 'down' ? 'нет' : t.link || '—'], ['Состояние в Keenetic', lost ? 'нет настроек' : off ? 'выключен' : gOff ? 'выключен агентом VPN' : t.state === 'up' ? 'включён' : t.state || '—', off || gOff ? 'warn' : ''],
    ['Сервер', t.endpoint || (e && e.endpoint) || (v && (v.server_name ? v.server_name + ' · ' + v.server : v.server)) || '—'], ['Адрес в туннеле', t.address || '—'], ['MTU', t.mtu != null ? String(t.mtu) : '—'],
    e ? ['Последнее рукопожатие', e.off || off ? 'туннель выключен' : e.handshake != null ? agoText(e.handshake) : e.running ? 'не было' : 'программа остановлена', !off && !e.off && (e.handshake == null || e.handshake > 180) ? 'warn' : '']
      : v ? null : ['Последнее рукопожатие', hsSec(t) != null ? agoText(hsSec(t)) : t.handshake != null ? 'не было' : '—', t.handshake != null && (hsSec(t) == null || hsSec(t) > 180) ? 'warn' : ''],
    ['Трафик', rx != null || tx != null ? '↓ ' + fmtBytes(rx) + ' · ↑ ' + fmtBytes(tx) : '—'],
    e || v ? ['Память программы', (e || v).rss_kb != null ? fmtKB((e || v).rss_kb) : (e || v).running ? '—' : 'программа остановлена'] : null,
    ['Время работы', t.uptime != null ? fmtUptime(t.uptime) : '—'],
    ['Качество за 30 минут', tqText(tq(name)), !tq(name) ? '' : tq(name).last_loss >= 100 ? 'crit' : tq(name).loss_pct >= 20 ? 'warn' : ''],
    ['Туннель по умолчанию', managed ? 'Да' : 'Нет', managed ? 'info' : '']
  ]) + (awgLost().some(x => x.name === name) ? '' : t.type === 'wireguard' && t.handshake != null && hsSec(t) == null ? '<p class="field-warn">Сервер ни разу не ответил. Если это файл Amnezia Premium (AmneziaWG 3.x), загруженный прямо в Keenetic, - Keenetic выбросил часть его настроек. Удалите этот туннель и добавьте тот же файл через «Добавить туннель»: его поднимет модуль AmneziaWG.</p>' : '') +
    confirmBox('tunnel-down', 'Выключить ' + tunLabel(name) + '? Трафик через него остановится, списки и подсети этого туннеля будут недоступны, пока он выключен. Настройка сохранится.', 'Выключить', true) +
    use + cfgNote(), { desc: managed ? 'Туннель по умолчанию: через него идут маршруты VWARD.' : 'Маршруты VWARD можно перевести на этот туннель, назначив его туннелем по умолчанию.',
      right: headPill(tunPill(t)[0], tunPill(t)[1]) + (managed || lost ? '' : sw('data-tun-onoff="' + esc(name) + '"', !off, off ? 'Включить туннель' : 'Выключить туннель', !cfgOk() || !!TUNBUSY[name])) }) +
    // Every block of the management panels: an engine's tunnel has three (firmware note,
    // configuration, deletion) and the deletion must not get lost.
    awgLostPanel(name) + (lost ? '' : mp[0]) + tunnelProbePanel(name) + tunnelTrafficPanel(name) + mp.slice(1).join('');
}
// Tunnels Keenetic took from AmneziaWG 3.x files without their header protection
// (awg-data lost[]): the same files move them to the engine, matched by server key.
const awgLost = () => (S.awg && S.awg.lost) || [];
// A tunnel's line in the list: the handshake; for the engine's tunnels it comes from the engine.
const vlessOf = name => ((S.awg && S.awg.vless && S.awg.vless.tunnels) || []).find(x => x.name === name);
const modOff = m => ((st().services || {}).modules_off || []).includes(m);
// ---- «Компоненты»: install, on/off, reinstall, reset, remove (fix.32) ----
// One operation at a time: while one runs (here or after a reboot) the buttons wait.
let COMP_JOB = null;
const COMP_ACT = { install: 'Установить', enable: 'Включить', disable: 'Отключить', reinstall: 'Переустановить', reset: 'Сбросить настройки', remove: 'Удалить' };
const COMP_DONE = { install: 'установлен', enable: 'включён', disable: 'отключён', reinstall: 'переустановлен', reset: 'настройки сброшены', remove: 'удалён' };
const compBusy = () => COMP_JOB || (st().services || {}).component_op || null;
function compModTunnels(m) { return m === 'vless' ? ((S.awg && S.awg.vless && S.awg.vless.tunnels) || []).map(t => t.name) : m === 'awg' ? ((S.awg && S.awg.tunnels) || []).map(t => t.name) : []; }
// What the step will touch, said before it is done.
function compPreview(id, act) {
  const cur = prof().tunnel_interface, n = act === 'disable' && id !== 'agh' ? tunUseExtraAll(compModTunnels(id)) : 0;
  if (id === 'agh') return {
    disable: 'Отключить AdGuard Home? DNS-строки AdGuard Home уйдут из Keenetic, реклама перестанет блокироваться, домены Smart DNS перейдут в Keenetic (там до 8 мест). «Включить» вернёт всё.',
    enable: 'Включить AdGuard Home? Он снова станет DNS роутера, домены Smart DNS вернутся в него.',
    reinstall: 'Переустановить AdGuard Home? Программа скачается заново, настройки и правила останутся.',
    reset: 'Сбросить настройки AdGuard Home? Его правила, списки и клиенты заменятся новыми настройками; вход - по сохранённому логину.',
    remove: 'Удалить AdGuard Home? DNS-строки уйдут из Keenetic, «Реклама» выключится, домены Smart DNS перейдут в Keenetic (до 8). Программа и её настройки удалятся.' }[act] || '';
  if (act === 'disable') return 'Отключить ' + compName(id) + '? Его туннели (' + compModTunnels(id).length + ') выключатся и не будут запускаться' +
    (n ? ', их списки и подсети (' + n + ') перейдут на ' + tunLabel(cur) : '') + '. «Включить» вернёт туннели и маршруты.';
  return 'Включить ' + compName(id) + '? Туннели модуля включатся, списки и подсети вернутся на них.';
}
function tunUseExtraAll(names) { return names.filter(n => n !== prof().tunnel_interface).reduce((a, n) => a + tunUseExtra(n), 0); }
function compButtons(id) {
  const sv = st().services || {}, b = (act, cls) => btn('comp-ask', act === 'remove' ? 'trash' : act === 'reinstall' ? 'refresh' : act === 'install' ? 'box' : 'power', COMP_ACT[act], cls || '', ' data-comp="' + id + '" data-cact="' + act + '"' + (cfgOk() && !compBusy() ? '' : ' disabled'));
  if (id === 'agh') {
    const none = aghState()[1] === ST.none[1];
    if (none) return [b('install', 'primary')];
    return [sv.adguard_disabled ? b('enable', 'primary') : b('disable'), b('reinstall'), b('reset'), b('remove', 'danger')];
  }
  // Not installed (owner 02.11): «Установить» only - for AmneziaWG, whose program VWARD downloads.
  if (id === 'awg' && S.awg && !S.awg.installed) return [b('install', 'primary')];
  if (id === 'vless' && S.awg && S.awg.vless && !S.awg.vless.installed && !compModTunnels(id).length) return [b('install', 'primary')];
  if (id === 'dnsmasq' || id === 'singbox') { const f = pkgFacts(id === 'dnsmasq' ? 'dnsmasq-full' : 'sing-box-go'); return f.known !== false && f.installed === false ? [b('install', 'primary')] : []; }
  if (!compModTunnels(id).length && !modOff(id)) return [];
  return [modOff(id) ? b('enable', 'primary') : b('disable')];
}
function compPanel(id) {
  if (!S.status || (id === 'agh' ? !S.ads : (id === 'awg' || id === 'vless') && !S.awg)) return '';
  const busy = compBusy(), btns = compButtons(id), c = confirm && confirm.id === 'comp' && confirm.comp === id ? confirm : null;
  if (!btns.length && !c) return '';
  const a = S.ads || {}, needLogin = id === 'agh' && !a.agh_connected && c && (c.act === 'install' || c.act === 'reset');
  const cur = prof().tunnel_interface, inMod = id !== 'agh' && compModTunnels(id).includes(cur);
  const alt = ((st().wg || {}).interfaces || []).filter(t => t.name !== cur && !compModTunnels(id).includes(t.name) && isTrue(t.connected));
  let body = '';
  if (c) {
    body = '<div class="confirm' + (c.act === 'remove' ? ' danger' : '') + '"><span>' + esc(c.act === 'install' ? (id === 'vless' ? 'Установить Xray? VWARD скачает официальную сборку и сверит закреплённую SHA-256. Без запуска туннелей.' : id === 'dnsmasq' || id === 'singbox' ? 'Установить ' + compName(id) + '? VWARD проверит HTTPS-источник Entware, SHA-256 и зависимости. Программа останется выключенной. Существующие настройки не меняются.' : id === 'awg' ? 'Установить модуль AmneziaWG? VWARD скачает программу vward-awg для этого роутера и сверит её контрольную сумму. Туннели и маршруты не меняются.' : 'Установить AdGuard Home? VWARD скачает официальную сборку для этого роутера, займёт свободные порты (веб-интерфейс 3000, DNS 65053 или следующие) и подключит его к Keenetic.') : compPreview(id, c.act)) + '</span>' +
      (['remove', 'reinstall', 'reset'].includes(c.act) ? '<label class="check-row"><input type="checkbox" data-comp-backup' + (c.backup === false ? '' : ' checked') + '> Сохранить копию настроек перед этим</label>' : '') +
      (c.act === 'disable' && inMod ? '<label class="check-row">Туннель по умолчанию ' + esc(tunLabel(cur)) + ' в этом модуле. Маршруты VWARD: ' + sel('data-comp-to', 'Куда перевести маршруты', alt.map(t => [t.name, 'через ' + tunLabel(t.name)]).concat([['direct', 'напрямую через провайдера']]), c.to || (alt[0] ? alt[0].name : 'direct')) + '</label>' : '') +
      (needLogin ? '<p class="panel-desc">Логин и пароль для входа в AdGuard Home (VWARD сохранит их на роутере и будет входить сам):</p><input class="input" name="comp-login" placeholder="логин" aria-label="Логин AdGuard Home" autocomplete="username"><input class="input" name="comp-password" type="password" placeholder="пароль, от 8 символов" aria-label="Пароль AdGuard Home" autocomplete="new-password">' : '') +
      '<button class="btn small ' + (c.act === 'remove' ? 'danger' : 'primary') + '" type="button" data-act="comp-yes">' + esc(COMP_ACT[c.act]) + '</button><button class="btn small" type="button" data-act="confirm-no">Отмена</button></div>';
  } else body = '<div class="panel-actions even">' + btns.join('') + '</div>';
  return panel('Управление', body + (busy ? '<p class="result-note">Идёт операция: ' + esc(String(busy).replace(/^agh-/, 'AdGuard Home: ').replace(/^module-/, 'модуль ')) + '. Остальные кнопки ждут её окончания.</p>' : '') + resultBox('comp-' + id),
    { desc: id === 'dnsmasq' || id === 'singbox' || id === 'vless' && !compModTunnels(id).length ? 'Установка программы без включения службы и без изменения туннелей.' : id === 'agh' ? 'Установка, отключение и удаление со всеми зависимостями: DNS Keenetic, «Реклама», Smart DNS.' : id === 'awg' && S.awg && !S.awg.installed ? 'Программа модуля не установлена; «Установить» скачает её. Без неё туннели AmneziaWG не запускаются.' : 'Отключение выключает туннели модуля и переводит их маршруты; включение возвращает их.' });
}
async function compRun(c) {
  const f = { op: 'comp', id: c.comp, action: c.act, confirm: 'COMPONENT_OP' };
  if (c.backup !== false && ['remove', 'reinstall', 'reset'].includes(c.act)) f.backup = 1;
  if (c.act === 'disable' && c.comp !== 'agh' && compModTunnels(c.comp).includes(prof().tunnel_interface)) f.tunnel = c.to || 'direct';
  const li = document.querySelector('[name=comp-login]'), pw = document.querySelector('[name=comp-password]');
  if (li && pw) {
    if (!/^[A-Za-z0-9._@-]{1,64}$/.test(li.value.trim()) || pw.value.length < 8) { toast('Введите логин и пароль от 8 символов', 'warn'); return; }
    f.login = li.value.trim(); f.password = pw.value; pw.value = '';
  }
  confirm = null; COMP_JOB = c.comp + '-' + c.act;
  actionResult = { id: 'comp-' + c.comp, text: COMP_ACT[c.act] + ': выполняется…' }; render();
  const j = await bgJob(f, c.act === 'install' || c.act === 'reinstall' ? 15 : 5);
  COMP_JOB = null;
  const name = compName(c.comp), msg = j.ok ? name + ': ' + COMP_DONE[c.act] : !j.done ? 'Ещё выполняется, проверьте позже' : 'Не выполнено: ' + errText(j.x) + (j.x && j.x.reason ? ' (' + j.x.reason + ')' : '');
  actionResult = { id: 'comp-' + c.comp, text: msg };
  toast(msg, j.ok ? 'ok' : 'err', 'a-comp-' + c.comp);
  await Promise.all([load('status', true), load('ads', true), load('awg', true), load('lists', true)]); render();
}
document.addEventListener('change', e => {
  if (!e.target.matches || !confirm || confirm.id !== 'comp') return;
  if (e.target.matches('[data-comp-backup]')) confirm.backup = e.target.checked;
  if (e.target.matches('[data-comp-to]')) confirm.to = e.target.value;
});
// «Управление» of a component VWARD cannot operate from the Panel (owner 02.11: the same section
// everywhere; an action that does not apply is not shown - here it is said why).
function mgmtNote(text) { return panel('Управление', '<p class="panel-desc">' + esc(text) + '</p>'); }
function compCard(id, name, kind, desc) {
  const f = pkgFacts(id), c = (((st().services || {}).components) || []), perm = k => { const x = c.find(r => r.id === 'entware-auto-' + k); return x ? x.label : 'Нет данных'; };
  const sel = kind === 'dnsmasq' ? dnsMode() === 'dnsmasq' : false;
  const s = compStatus(Object.assign({}, f, { selected: sel, works: sel ? (f.running ? null : false) : null }));
  // Not installed (owner 02.11): only what tells it - state, source, use; no update rows, no
  // «Диагностика: Не установлен», no «part of the data» warning.
  const rows = [['Состояние', s[1], s[0]]].concat(f.installed ? [['Версия', f.version && f.version !== '-' ? f.version : '—']] : [],
    [['Источник', 'пакет Entware'], ['Использование', kind === 'dnsmasq' ? (sel ? 'выбран активным DNS' : 'не выбран') : 'туннелей нет']],
    f.installed ? [['Автопроверка обновлений', perm('check')], ['Автозагрузка обновлений', perm('download')], ['Автоустановка обновлений', perm('apply')],
      ['Диагностика', ((c.find(r => r.id === id) || {}).label) || 'Нет данных']] : []);
  return (f.installed ? loadError(['status']) : '') + panel(name, kv(rows), { desc: desc }) +
    (f.installed ? mgmtNote('Обновление пакета - в «Обновления программ». Удаление и сброс из Панели VWARD появятся в следующем выпуске.') : compPanel(kind));
}
const TUN_TYPE = { wireguard: 'WireGuard', openvpn: 'OpenVPN', sstp: 'SSTP', pptp: 'PPTP', l2tp: 'L2TP', ike: 'IPsec', ipsec: 'IPsec', proxy: 'Proxy', opkgtun: 'OpkgTun' };
const awgOf = name => ((S.awg && S.awg.tunnels) || []).find(x => x.name === name);
// A VWARD engine's tunnel whose settings are gone (the USB stick formatted, owner 2026-10-18):
// Keenetic keeps the OpkgTun connection, no engine holds it. Known once the engines answered.
// A tunnel that is up or connected has its program whatever the engines' answer says (a slow
// Keenetic cut that answer short and a working new tunnel read «Нет настроек», Viva 2026-10-18).
const tunLost = t => !!(t && S.awg && S.awg.vless && Array.isArray(S.awg.vless.tunnels) && Array.isArray(S.awg.tunnels)) && String(t.type || '').toLowerCase() === 'opkgtun' && !isTrue(t.connected) && t.link !== 'up' && !vlessOf(t.name) && !awgOf(t.name);
// A tunnel's line in the list: its kind and anything wrong with it; the handshake and the rest
// are on the tunnel's own page.
const tunSub = t => {
  const v = vlessOf(t.name), e = awgOf(t.name);
  // «Нет настроек» is its status already: no second line saying the same (owner 12.11.2026).
  if (tunLost(t)) return '';
  // The status says it; why - on the tunnel's page (one status a row, owner 2026-10-18).
  if (tunGuardOff(t)) return '';
  if (v) return 'VLESS' + (v.running || tunOff(t) ? '' : ' · программа остановлена');
  if (e) return 'модуль AmneziaWG' + (e.running || tunOff(t) ? '' : ' · программа остановлена');
  return t.type === 'wireguard' && t.awg ? 'AmneziaWG' : TUN_TYPE[t.type] || t.type || '';
};
// Switched off in Keenetic (its «state» down), which is not «no connection».
const tunOff = t => String(t.state || '').toLowerCase() === 'down' && !tunGuardOff(t);
// Why the VPN agent switched the default tunnel off (its own words, from the agent's state).
const FO_WHY = { silent: 'туннель не отвечал', restart: 'перезапуск модуля не помог', restart_servers: 'перезапуск Xray и другие серверы подписки не помогли', no_fallback: 'другого туннеля на связи нет', fallback_off: 'переход на другой туннель выключен' };
const foText = wg => tunLost(tunNow(prof().tunnel_interface)) ? 'настройки туннеля не найдены - добавьте его заново' : ((wg && wg.failopen_reason) || []).map(r => FO_WHY[r]).filter(Boolean).join('; ');
// Status of a tunnel in lists: switched off by the owner - grey, not a fault; by the VPN agent - a warning.
const tunPill = t => TUNBUSY[t.name] ? ['', TUN_BUSY[TUNBUSY[t.name]]] : tunLost(t) ? ['warn', 'Нет настроек'] : tunOff(t) ? ['', 'Выключен'] : tunGuardOff(t) ? ['warn', 'Выключен агентом'] : isTrue(t.connected) ? ['ok', 'В сети']
  : TUNUP[t.name] ? ['', 'Подключение'] : ['warn', 'Не в сети'];
// The guard switched it off itself (fail-open: the lists go direct until it answers).
const tunGuardOff = t => String(t.state || '').toLowerCase() === 'down' && isTrue((st().wg || {}).failopen_active) && t.name === prof().tunnel_interface;
// On, off and restart in place, at once, as Keenetic's own switch (owner 2026-10-12: no window,
// no timer). The status says what is going on - «Выключение», «Включение», «Перезапуск», then
// «Подключение» until the server answers (a minute at most); a refusal puts the switch back and
// says why under the tunnel.
const TUNBUSY = {}, TUNUP = {}, TUNERR = {};
const TUN_BUSY = { up: 'Включение', down: 'Выключение', restart: 'Перезапуск' };
async function tunnelOp(op, name) {
  let x;
  try { x = await apiPost('tunnel-conf', { op: op, name: name }); } catch (e) { return { ok: false, text: 'Ошибка: ' + e.message }; }
  return x.ok ? { ok: true } : { ok: false, code: x.error, text: errText(x) + (x.reason ? ' (ответ роутера: ' + x.reason + ')' : '') };
}
async function tunnelState(op, name) {
  if (TUNBUSY[name]) return;
  TUNBUSY[name] = op; delete TUNERR[name]; render();
  const r = await tunnelOp(op, name);
  if (!r.ok) TUNERR[name] = r.text;
  if (r.ok && op !== 'down') TUNUP[name] = Date.now(); else delete TUNUP[name];
  await Promise.all([load('status', true), load('awg', true)]);
  if (r.ok && op === 'up' && tunOff(tunNow(name))) { r.ok = false; TUNERR[name] = 'Туннель не включился'; delete TUNUP[name]; }
  delete TUNBUSY[name]; render();
  if (r.ok && op !== 'down') await tunnelConnecting(name);
  return r;
}
const tunNow = name => ((st().wg || {}).interfaces || []).find(x => x.name === name);
// After on or restart: the status every 3 s until the server answers, a minute at most.
async function tunnelConnecting(name) {
  const until = Date.now() + 60000;
  while (Date.now() < until && TUNUP[name]) {
    const t = tunNow(name);
    if (!t || isTrue(t.connected) || tunOff(t)) break;
    await new Promise(res => setTimeout(res, 3000));
    await load('status', true); render();
  }
  delete TUNUP[name]; render();
  const t = tunNow(name);
  return !!t && isTrue(t.connected);
}
// KeeneticOS 5.2 carries AmneziaWG 3.x itself: once Keenetic offers 5.2 or newer while the
// router runs older, the engine's tunnels say so. The versions are what the router's own
// update check got from Keenetic's servers. The stable channel comes first; a test build is
// shown as one, with a warning - the owner decides whether to install it.
const fwNum = v => { const m = /^(\d+)\.(\d+)/.exec(v || ''); return m ? +m[1] * 100 + +m[2] : 0; };
const fwShort = v => fwNum(v) ? Math.floor(fwNum(v) / 100) + '.' + fwNum(v) % 100 + (/^\d+\.\d+$/.test(v) ? '' : ' (' + v + ')') : v;
const fwNative = () => {
  const f = (S.ext && S.ext.firmware) || null;
  if (!f || !fwNum(f.title || f.release) || fwNum(f.title || f.release) >= 502) return null;
  const ok = (f.channels || []).filter(c => fwNum(c.version) >= 502);
  return ok.find(c => c.name === 'stable') || ok.find(c => c.name === 'preview') || ok.find(c => c.name === 'draft') || ok[0] || null;
};
const nativePanel = () => {
  const c = fwNative();
  if (!c || !((S.awg && S.awg.tunnels) || []).length) return '';
  const test = c.name !== 'stable';
  return panel(test ? 'Есть тестовая прошивка Keenetic' : 'Обновите прошивку Keenetic', '<p class="panel-desc">' +
    (test ? 'На канале «' + esc(fwChannel(c.name)) + '» Keenetic выпустил KeeneticOS ' : 'Для роутера вышла KeeneticOS ') + esc(fwShort(c.version)) +
    '. В ней AmneziaWG 3.x встроена в прошивку: туннели будут заметно быстрее и не будут занимать процессор и память программой на флешке. Прошивку ставит Keenetic, роутер перезагрузится.</p>' +
    (test ? '<p class="field-warn">Внимание: это тестовая версия, в ней возможны ошибки и сбои в работе роутера. Ставить её или дождаться стабильной - решать вам; канал обновлений меняется на странице «Прошивка Keenetic».</p>' : '') +
    kv([['Прошивка Keenetic', 'Обновления', 'info', 'u-fw', '', 'установлена ' + esc(((S.ext || {}).firmware || {}).title || ''), 'out']]));
};
function awgLostPanel(only) {
  const L = awgLost().filter(x => !only || x.name === only);
  if (!L.length) return '';
  const names = L.map(x => '«' + (x.description || x.name) + '»').join(', ');
  return panel(L.length > 1 ? 'Эти туннели не подключатся' : 'Туннель не подключится',
    '<p class="field-warn">' + esc(names) + (L.length > 1 ? ' загружены' : ' загружен') + ' в Keenetic из файлов AmneziaWG 3.x, и Keenetic выбросил их защиту заголовков - без неё сервер не отвечает. Выберите те же файлы: VWARD поднимет туннели в модуле под теми же названиями и перенесёт на них списки и подсети.</p>' +
    '<label class="file-pick">' + ico('save') + '<span>' + (L.length > 1 ? 'Выбрать их файлы .conf' : 'Выбрать файл .conf') + '</span><input type="file" multiple data-awg-adopt' + (cfgOk() ? '' : ' disabled') + '></label>' +
    '', { desc: 'Файлы проверяются по ключу сервера: чужой файл не подойдёт.' });
}
async function awgAdopt(files) {
  const read = f => new Promise(res => { if (f.size > 16384) return res(''); const r = new FileReader(); r.onload = () => res(String(r.result || '')); r.onerror = () => res(''); r.readAsText(f); });
  const done = [], bad = [], failed = [];
  tunOverlay = null;
  tunOverlayShow({ head: 'Перенос туннелей в контур', okHead: 'Туннели перенесены', failHead: 'Перенесено не всё', step: 'prepare' });
  for (const [k, f] of files.entries()) {
    let text = await read(f);
    if (vpnKey(text)) { const key = await amneziaKey(vpnKey(text)); text = key.conf || ''; }
    const m = /\[Peer\][\s\S]*?PublicKey\s*=\s*(\S+)/i.exec(text), t = m && awgLost().find(x => x.peer === m[1]);
    if (!t) { bad.push(f.name); continue; }
    const label = t.description || t.name;
    tunOverlayShow({ sub: (files.length > 1 ? 'Файл ' + (k + 1) + ' из ' + files.length + ': ' : '') + '«' + label + '»', step: 'prepare', pct: 0 });
    // One server that does not answer does not stop the others.
    const r = await runJob({ op: 'adopt', name: t.name, conf: text }, 4);
    if (r.ok) done.push(label); else failed.push('«' + label + '» - ' + r.text.replace(/\. Роутер оставлен как был\.$/, ''));
    await load('awg', true);
  }
  tunOverlayShow({ done: true, ok: done.length > 0 && !failed.length && !bad.length, sub: '', stage: done.length ? 'В модуле: ' + done.join(', ') : '',
    text: [failed.length ? 'Не перенесены: ' + failed.join('; ') + '.' : '', bad.length ? 'Не подошли ни к одному туннелю: ' + bad.join(', ') + ' - добавьте их через «Добавить туннель».' : '',
      !failed.length && !bad.length ? 'Списки и подсети теперь идут через туннели модуля.' : ''].filter(Boolean).join(' ') });
  await Promise.all([load('status', true), load('awg', true), load('lists', true)]); render();
}
// Filled only by «Проверить сейчас»: the router does not do this in the background.
// A tunnel is shown by the name its owner gave it; the system name only on its own page.
const tunLabel = n => { const t = ((st() && st().wg && st().wg.interfaces) || []).find(x => x.name === n); return t && t.description ? t.description : n; };
// Services: a service switched on is a Keenetic list VWARD made (enabled[].group).
const SVC = { cat: 'on', busy: false };
const svcOf = group => ((S.services && S.services.enabled) || []).find(e => e.group === group);
const svcCatTunnel = cat => (((S.services && S.services.category_tunnels) || []).find(c => c.category === cat) || {}).tunnel || '';
const svcProbe = id => ((S.services && S.services.probe) || []).find(p => p.id === id);
const SVC_VERDICT = { open: 'открывается', blocked: 'заблокирован', none: 'нет ответа', denied: 'отказ (HTTP 403)', error: 'ошибка сервера', answer: 'ответ без подтверждения работы' };
function svcVia(e) {
  const l = ((S.lists && S.lists.lists) || []).find(x => x.name === e.group);
  const x = ((S.services && S.services.services) || []).find(v => v.id === e.id), pin = e.tunnel === 'auto' && x && svcCatTunnel(x.category);
  return !S.lists ? '' : !l ? 'список удалён в Keenetic' : !l.route ? 'без маршрута' : (e.tunnel !== 'auto' ? '' : pin ? 'по категории · ' : 'автоматически · ') + 'через ' + tunLabel(l.route);
}
function servicePage(id) {
  const V = S.services, x = V && (V.services || []).find(v => v.id === id), e = V && (V.enabled || []).find(v => v.id === id), d = S.svcd;
  if (!x) return loadError(['services']) + panel('Сервис', empty(V ? 'Такого сервиса нет в каталоге' : 'Загрузка…'));
  const tuns = (st().wg && st().wg.interfaces) || [], ok = cfgOk() && !SVC.busy;
  const l = e && ((S.lists && S.lists.lists) || []).find(v => v.name === e.group);
  const doms = d && d.ok && d.id === id ? d.domains : null;
  return cfgNote() + panel(x.title, '<dl class="kv">' +
      ctrlRow('Через VPN', sw('data-svc="' + esc(id) + '"', !!e, (e ? 'Выключить ' : 'Включить ') + x.title, !ok || x.too_big), e ? svcVia(e) : 'выключен - идёт напрямую') +
      (e ? ctrlRow('Туннель', tuns.length + 1 <= 4 ? choiceSlider('svc-tun:' + id, [['auto', 'Авто', !ok]].concat(tuns.map(t => [t.name, tunLabel(t.name), !ok])), e.tunnel, 'Туннель для ' + x.title)
        : sel('data-svc-tun="' + esc(id) + '"' + (ok ? '' : ' disabled'), 'Туннель для ' + x.title, [['auto', 'Автоматически']].concat(tuns.map(t => [t.name, tunLabel(t.name)])), e.tunnel), e.tunnel === 'auto' ? 'автовыбор по проверке туннелей' : 'туннель закреплён') : '') + '</dl>' +
      (l ? kv([['IP-адреса', l.addresses != null ? fmtInt(l.addresses) : '—', '', 'ip-' + l.name, '', 'адреса, которые Keenetic узнал для доменов сервиса']]) : '') + resultBox('svc'),
      { desc: (l ? 'В Keenetic - доменный список «' + (l.description || l.name) + '». ' : '') + 'Домены из каталога iplist, обновляются сами раз в сутки.' }) +
    (e && e.tunnel === 'auto' && tuns.length >= 2 ? svcProbePanel(id) : '') +
    panel('Домены', !doms ? empty('Загрузка…') : '<ul class="rows">' + doms.map(v => '<li class="row"><div class="row-main"><b>' + dom(v) + '</b></div></li>').join('') + '</ul>',
      { desc: fmtInt(x.count) + ' ' + plural(x.count, 'домен', 'домена', 'доменов') + ', каждый вместе с поддоменами.' });
}
// The last check of a service on «Автоматически» through every answering tunnel.
function svcProbePanel(id) {
  const p = svcProbe(id), x = ((S.services && S.services.services) || []).find(v => v.id === id), pin = x && svcCatTunnel(x.category);
  const to = tunLabel(p ? p.tunnel : '');
  const act = { kept: ['оставлен', 'открывается через свой туннель «' + to + '»'], moved: ['переведён', 'через свой туннель не открывался, теперь через «' + to + '»'],
    none: ['не открывается', 'ни через один туннель; остаётся на «' + to + '»'], failed: ['не переведён', 'Keenetic не принял перевод'], category: ['по категории', 'через туннель категории «' + to + '»'],
    guard: ['резервный канал', 'агент VPN держит список на «' + to + '», пока основной туннель не ответит'] };
  return panel('Проверка сайта', pin ? empty('Категория закреплена за «' + tunLabel(pin) + '»: сервис идёт через него без проверки.') : !p ? empty('Ещё не проверялся: проверка раз в 30 минут.') :
    kv((p.results || []).map(r => [tunLabel(r.via), SVC_VERDICT[r.verdict] || r.verdict, r.verdict === 'open' ? 'ok' : 'warn', null, '', r.verdict === 'open' && r.ms != null ? r.ms + ' мс' : ''])
      .concat([['Итог', (act[p.action] || [p.action])[0], p.action === 'none' || p.action === 'failed' ? 'warn' : '', null, '', ((act[p.action] || [])[1] || '') + (p.at ? '; проверен ' + fmtTime(p.at * 1000) : '')]])),
    { desc: 'Раз в 30 минут VWARD открывает сервис через каждый туннель. Не открылся через свой - переходит на самый быстрый, через который открылся.' });
}
// A background job of the services action, waited for through control-data: { ok, done, x }.
// The helper's reason= line (Keenetic's own answer) comes along with its error.
async function bgJob(fields, minutes) {
  let x, run = {};
  try { x = await apiPost('services', fields); } catch (err) { x = { ok: false, error: err.message }; }
  if (!x || !x.ok) return { ok: false, done: true, x: x || { error: 'helper_failed' } };
  const deadline = Date.now() + (minutes || 3) * 60 * 1000;
  while (Date.now() < deadline) {
    await new Promise(r => setTimeout(r, 2000));
    try { run = (await apiGet('control-data')).run || {}; } catch (err) { continue; }
    if (run.finished) break;
  }
  if (!run.finished) return { ok: false, done: false, x: {}, out: [] };
  const out = String(run.output || '').trim().split('\n'), last = out[out.length - 1] || '';
  const left = (out.filter(l => /^info\.left=/.test(l)).pop() || '').slice(10).split(',').filter(Boolean);
  const reason = (out.filter(l => /^reason=/.test(l)).pop() || '').slice(7), why = (out.filter(l => /^info\.why=/.test(l)).pop() || '').slice(9);
  return run.rc === 0 ? { ok: true, done: true, left: left, why: why, x: { ok: true, result: last.replace(/^result=/, '') } } :
    { ok: false, done: true, left: left, why: why, x: { ok: false, error: /^error=/.test(last) ? last.slice(6) : 'helper_failed', reason: reason } };
}
// Switching on writes up to 300 domains into Keenetic: a background job, as for tunnels.
async function serviceJob(fields, okMsg) {
  const show = text => { actionResult = { id: 'svc', text: text }; render(); };
  SVC.busy = true; show(fields.op === 'off' ? 'Выключаем…' : fields.op === 'on' ? 'Записываем домены в Keenetic…' : 'Переводим…');
  const j = await bgJob(fields);
  SVC.busy = false; SVREC_ACTION = !j.ok && j.done;
  show(j.ok ? okMsg : !j.done ? 'Ещё выполняется, проверьте позже' : 'Не выполнено: ' + errText(j.x));
  await Promise.all([load('services', true), load('lists', true)]); render();
}
// The default tunnel: moving every list can take Keenetic a minute, so it is a background
// job (fix.30 showed «роутер не ответил» after 20 s while the switch went on).
async function tunUseJob(name, move) {
  runningId = 'tunnel-use'; popup({ sev: 'info', title: 'Переключаем маршруты на ' + tunLabel(name) + '…' }); render();
  const j = await bgJob({ op: 'use', id: move, tunnel: name, confirm: 'TUNNEL_SWITCH' });
  runningId = null;
  toast(j.ok ? (j.x.result === 'unchanged' ? 'Уже туннель по умолчанию' : 'Маршруты VWARD идут через ' + tunLabel(name)) : !j.done ? 'Переключение ещё выполняется, проверьте позже' : 'Не переключено: ' + errText(j.x), j.ok ? 'ok' : !j.done ? 'info' : 'err', 'a-tunnel');
  await Promise.all(['config', 'status', 'security', 'route', 'lists'].map(k => load(k, true))); render();
}
document.addEventListener('input', e => { const f = e.target.closest && e.target.closest('[data-form="tunnel-conf"]'); if (f && (e.target.name === 'conf' || /^tc-/.test(e.target.name)) && f.dataset.checked) { f.dataset.checked = ''; $('tcPreview').innerHTML = ''; f.querySelector('[type=submit]').hidden = false; f.querySelector('[type=submit]').textContent = 'Проверить'; } });
async function wifiHostSet(fields, okMsg) {
  let x;
  try { x = await apiPost('wifi-host', fields); } catch (e) { toast('Ошибка: ' + e.message); return; }
  toast(x.ok ? (x.result === 'unchanged' ? 'Уже так' : okMsg) : 'Не сохранено: ' + errText(x));
  await load('wifi', true); render();
}
async function tunnelSubnet(name, op, subnet) {
  let x;
  try { x = await apiPost('tunnel-conf', { op: 'subnet-' + op, name: name, subnet: subnet }); }
  catch (e) { toast('Ошибка: ' + e.message); return; }
  toast(x.ok ? (x.result === 'unchanged' ? 'Уже так' : op === 'add' ? subnet + ' идёт через ' + name : subnet + ' убрана из ' + name) : 'Не сохранено: ' + errText(x));
  await load('lists', true); render();
}
/* ---------- Окно создания туннеля ---------- */
// Like the update window: the tunnel jobs report "step=" lines as they go (the router's
// and the engine's), then "info.key=value" and a last "result=" or "error=" line.
const TUN_STEPS = [['prepare', 'Подготовка', 5], ['download', 'Скачивание программы модуля', 12], ['test', 'Проверка сервера на временном туннеле', 20],
  ['router', 'Создание подключения в Keenetic', 35], ['program', 'Запуск программы модуля', 48], ['handshake', 'Ожидание ответа сервера', 58],
  ['save', 'Сохранение настроек роутера', 88], ['move', 'Перенос списков и подсетей', 92]];
let tunOverlay = null;
function tunOverlayShow(o) {
  tunOverlay = Object.assign(tunOverlay || { step: 'prepare', pct: 0 }, o);
  let el = $('tunOverlay');
  if (!el) { el = document.createElement('div'); el.id = 'tunOverlay'; document.body.appendChild(el); }
  const u = tunOverlay, i = Math.max(0, TUN_STEPS.findIndex(x => x[0] === u.step)), step = TUN_STEPS[i], next = TUN_STEPS[i + 1];
  const cap = next ? next[2] - 3 : 97;
  // Inside a step the ring creeps on, so a minute of waiting for the server never looks frozen.
  u.pct = u.done ? 100 : Math.min(cap, Math.max(u.pct || 0, step[2]) + (u.pct >= step[2] ? 1 : 0));
  const head = u.done ? (u.ok ? u.okHead : u.failHead) : u.head;
  const text = u.done ? u.text : 'Не закрывайте страницу. Роутер и интернет продолжают работать.';
  el.innerHTML = '<div class="upd-page' + (u.done ? (u.ok ? ' ok' : ' crit') : '') + '" role="dialog" aria-live="polite" aria-label="' + esc(head) + '">' +
    '<h2>' + esc(head) + '</h2>' + (u.sub ? '<p class="upd-ver">' + esc(u.sub) + '</p>' : '') +
    '<p class="upd-text">' + esc(text) + '</p>' + ringHtml(u.pct, u.done, u.ok) +
    '<p class="upd-stage">' + esc(u.done ? (u.stage || '') : step[1]) + '</p>' +
    (u.done ? '<div class="panel-actions">' + (u.ok && u.open ? '<button class="btn primary" type="button" data-act="tun-open" data-name="' + esc(u.open) + '">Открыть туннель</button>' : '') +
      (u.keep ? '<button class="btn primary" type="button" data-act="tun-keep">' + (TUN_KEEP && TUN_KEEP.mode === 'replace' ? 'Заменить всё равно' : 'Добавить всё равно') + '</button>' : '') +
      '<button class="btn' + (u.ok && u.open || u.keep ? '' : ' primary') + '" type="button" data-act="tun-close">' + (u.ok ? 'Готово' : u.keep ? 'Нет' : 'Закрыть') + '</button></div>' : '') + '</div>';
}
function tunOverlayClose() { tunOverlay = null; const el = $('tunOverlay'); if (el) el.remove(); }
const jobInfo = out => { const info = {}; String(out || '').split('\n').forEach(l => { const m = /^(info\.([a-z]+)|step)=(.*)$/.exec(l); if (m) info[m[2] || 'step'] = m[3]; }); return info; };
const jobLast = out => { const l = String(out || '').trim().split('\n'); return l[l.length - 1] || ''; };
// runJob FIELDS: starts a tunnel job and follows it in the window; the finished run, or null.
async function runJob(fields, minutes) {
  let x;
  try { x = await apiPost('tunnel-conf', fields); } catch (e) { return { ok: false, text: 'Ошибка: ' + e.message }; }
  if (!x.ok) return { ok: false, text: errText(x) };
  const deadline = Date.now() + minutes * 60 * 1000;
  let run = {};
  while (Date.now() < deadline) {
    await new Promise(r => setTimeout(r, 3000));
    try { run = (await apiGet('control-data')).run || {}; } catch (e) { tunOverlayShow({}); continue; }
    const info = jobInfo(run.output);
    tunOverlayShow(info.step ? { step: info.step } : {});
    if (run.finished) break;
  }
  const info = jobInfo(run.output), last = jobLast(run.output);
  if (!run.finished) return { ok: false, text: 'Роутер ещё работает над туннелем. Проверьте страницу «VPN» через пару минут.' };
  if (run.rc === 0 && /^result=/.test(last)) return { ok: true, info: info };
  const why = (String(run.output || '').match(/^reason=(.*)$/m) || [])[1] || '';
  return { ok: false, code: /^error=/.test(last) ? last.slice(6) : '', reason: why, text: errText({ error: last.replace(/^error=/, '') || 'engine_failed', reason: /^sent /.test(why) ? '' : why }) + '. Роутер оставлен как был.' };
}
// What the AmneziaWG module sent and got back while it waited for the handshake: nothing back means
// the server does not take the key from the file, or its answers do not reach the router.
const hsTraffic = why => { const m = /^sent (\d*) bytes, received (\d*)/.exec(why || ''); if (!m) return '';
  return 'Модуль AmneziaWG отправил ' + fmtBytes(+m[1] || 0) + ', получил ' + fmtBytes(+m[2] || 0) + (+m[2] ? '. ' : ': сервер не принял ключ из файла или его ответы не доходят до роутера. '); };
// The server stayed silent: the window asks whether to keep the tunnel anyway (a second run with keep=1).
let TUN_KEEP = null;
async function tunnelJob(mode, fields, label) {
  tunOverlay = null; TUN_KEEP = null;
  const heads = { create: ['Новый туннель', 'Туннель создан', 'Туннель не создан'], replace: ['Замена конфигурации', 'Конфигурация заменена', 'Конфигурация не заменена'] }[mode];
  tunOverlayShow({ head: heads[0], okHead: heads[1], failHead: heads[2], sub: label ? '«' + label + '»' : '', step: 'prepare' });
  const r = await runJob(fields, 5);
  const i = r.info || {}, silent = !r.ok && r.code === 'tunnel_no_handshake' && !fields.keep;
  if (silent) TUN_KEEP = { mode: mode, fields: fields, label: label };
  tunOverlayShow({ done: true, ok: r.ok, keep: silent, open: r.ok ? (mode === 'create' ? i.name : fields.name) : '',
    stage: r.ok ? [label, i.endpoint ? 'сервер ' + i.endpoint : ''].filter(Boolean).join(' · ') : '',
    text: r.ok ? (i.handshake === 'none' ? (mode === 'create' ? 'Туннель добавлен, но сервер пока не ответил. Он станет «В сети», когда сервер ответит; состояние видно на странице туннеля.' : 'Конфигурация заменена, но сервер пока не ответил. Туннель станет «В сети», когда сервер ответит.') :
        'Сервер ответил, туннель работает. Направьте на него списки и сервисы на странице туннеля.') :
      silent ? 'Сервер не ответил на рукопожатие за 30 секунд. ' + hsTraffic(r.reason) + (mode === 'create' ? 'Туннель не добавлен, роутер оставлен как был. Добавить его всё равно? Он появится в списке со статусом «Не в сети» и подключится, когда сервер ответит.' :
        'Конфигурация не заменена, роутер оставлен как был. Заменить всё равно? Туннель будет «Не в сети», пока сервер не ответит.') : r.text });
  await Promise.all([load('status', true), load('lists', true), load('awg', true)]); render();
}
// Manual tunnel fields: [id, caption, placeholder, secret, mono]; empty optional ones are left out.
const TC_FIELDS = [
  ['key', 'Закрытый ключ (PrivateKey)', 'из настроек VPN-провайдера', true, true],
  ['address', 'Адрес в туннеле', '10.8.0.2/32', false, true],
  ['peer', 'Открытый ключ сервера (PublicKey)', 'ключ сервера', false, true],
  ['endpoint', 'Сервер', 'vpn.example.com:51820', false, true],
  ['allowed', 'Разрешённые адреса', '0.0.0.0/0', false, true],
  ['psk', 'Общий ключ (PresharedKey), если есть', 'необязательно', true, true],
  ['keepalive', 'Keepalive, секунд', '25', false, false],
  ['mtu', 'MTU', 'необязательно', false, false],
  ['awg', 'Параметры AmneziaWG, если есть', '', false, true]
];
function tcConf(form) {
  const v = k => { const el = form.querySelector('[name="tc-' + k + '"]'); return el ? el.value.trim() : ''; };
  const i = ['[Interface]', 'PrivateKey = ' + v('key'), 'Address = ' + v('address')];
  if (v('mtu')) i.push('MTU = ' + v('mtu'));
  v('awg').split(/\n+/).map(x => x.trim()).filter(x => /^[A-Za-z0-9]+\s*=\s*\S/.test(x)).forEach(x => i.push(x));
  const p = ['[Peer]', 'PublicKey = ' + v('peer')];
  if (v('psk')) p.push('PresharedKey = ' + v('psk'));
  p.push('AllowedIPs = ' + (v('allowed') || '0.0.0.0/0'), 'Endpoint = ' + v('endpoint'), 'PersistentKeepalive = ' + (v('keepalive') || '25'));
  return i.concat([''], p).join('\n') + '\n';
}
// An Amnezia key (vpn://): base64url of JSON, usually zlib with a 4-byte length in front.
// A key to one's own server carries the WireGuard/AmneziaWG .conf; a Premium key carries only
// an access key to Amnezia's servers. Decoded here in the browser; nothing of it is shown.
// A tunnel's name from its file: «fi.conf», «us-east.conf (1)», «de.conf_1» → «fi», «us-east», «de».
const confName = n => String(n || '').replace(/\s*\(\d+\)\s*$/, '').replace(/\.(conf|vpn|txt)(_\d+)?$/i, '').replace(/\s*\(\d+\)\s*$/, '')
  .replace(/["\\]/g, '').replace(/[_]+/g, ' ').trim().slice(0, 64);
// A tunnel's name goes to Keenetic: no emoji (flags of a subscription's server names), one line, 64 characters.
const tunDesc = v => String(v || '').replace(/[\u{10000}-\u{10FFFF}\uFE0F\u200D]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 64);
// The key alone, without «vpn://» (AmneziaVPN saves it so in «amnezia_config.conf»): one
// line of base64url, no [Interface]. '' when the text is not a key.
const vpnKey = t => /^\s*vpn:\/\//i.test(t) ? t.trim() : /^\s*[A-Za-z0-9_-]{60,}={0,2}\s*$/.test(t) ? 'vpn://' + t.trim() : '';
async function amneziaKey(text) {
  let b;
  try { b = Uint8Array.from(atob(text.trim().slice(6).replace(/-/g, '+').replace(/_/g, '/').replace(/\s+/g, '')), c => c.charCodeAt(0)); }
  catch (e) { return { error: 'ключ vpn:// повреждён - скопируйте его заново' }; }
  let json;
  try {
    if (b[0] === 123) json = new TextDecoder().decode(b);
    else {
      if (typeof DecompressionStream !== 'function') return { error: 'браузер не умеет распаковывать ключ vpn:// - обновите браузер или возьмите файл .conf' };
      json = await new Response(new Blob([b.slice(4)]).stream().pipeThrough(new DecompressionStream('deflate'))).text();
    }
    json = JSON.parse(json);
  } catch (e) { return { error: 'ключ vpn:// повреждён - скопируйте его заново' }; }
  if (json.api_config || json.auth_data) return { error: 'это ключ подписки Amnezia Premium: в нём нет сервера и ключей туннеля, только доступ к серверам Amnezia. Нужен файл .conf AmneziaWG - в приложении AmneziaVPN или у поддержки Amnezia' };
  const cs = (json.containers || []).slice().sort((a, b) => (b.container === json.defaultContainer) - (a.container === json.defaultContainer));
  for (const c of cs) for (const k of Object.keys(c)) {
    let lc = c[k] && c[k].last_config;
    if (!lc) continue;
    try { lc = typeof lc === 'string' ? JSON.parse(lc) : lc; } catch (e) { continue; }
    const conf = lc && typeof lc.config === 'string' ? lc.config : '';
    if (/\[Interface\]/i.test(conf) && /\[Peer\]/i.test(conf))
      return { conf: conf.replace(/\$PRIMARY_DNS/g, json.dns1 || '1.1.1.1').replace(/\$SECONDARY_DNS/g, json.dns2 || '1.0.0.1'), name: confName(json.description || json.name || '') };
  }
  return { error: 'в ключе нет настройки WireGuard или AmneziaWG (' + (cs.map(c => c.container).join(', ') || 'пусто') + ') - VWARD умеет только эти два' };
}
// A message in the add form itself: it stays until the next try (a toast was gone in seconds).
const tcMsg = html => { const el = $('tcPreview'); if (el) el.innerHTML = '<p class="field-warn">' + esc(html) + '</p>'; };
// What the file holds, and the button for the next step.
function tcPreview(form, x, mode, name) {
  $('tcPreview').innerHTML = kv([['Сервер', x.endpoint || '—'], ['Адрес в туннеле', x.address || '—'], ['MTU', x.mtu || 'как на роутере'],
    ['Обфускация AmneziaWG', x.awg === '1' ? 'Включена' : 'Выключена'], ['Keepalive', x.keepalive ? x.keepalive + ' с' : '25 с'], ['Разрешённые адреса', x.allowed || '—']]) +
    (x.engine === '1' ? '<p class="field-warn">Это AmneziaWG 3.x: прошивка Keenetic его не умеет. Туннель поднимет модуль VWARD - программа на флешке, около 13 МБ памяти, скорость ниже встроенного WireGuard. В Keenetic он будет подключением OpkgTun.' + (fwNative() ? (fwNative().name === 'stable' ? ' Для роутера уже есть KeeneticOS ' + esc(fwShort(fwNative().version)) + ' со встроенной AmneziaWG 3.x - лучше сначала обновить прошивку.' :
      ' На канале «' + esc(fwChannel(fwNative().name)) + '» есть тестовая KeeneticOS ' + esc(fwShort(fwNative().version)) + ' со встроенной AmneziaWG 3.x (возможны ошибки).') : '') + '</p>' :
     '') +
    (x.hostonly ? '<p class="field-note">Настройки для компьютера, на роутере не нужны (маршруты и DNS роутер настраивает сам): ' + esc(x.hostonly.split(',').join(', ')) + '.</p>' : '');
  form.dataset.checked = '1';
  form.querySelector('[type=submit]').hidden = false;
  form.querySelector('[type=submit]').textContent = mode === 'create' ? 'Создать туннель' : 'Заменить конфигурацию ' + tunLabel(name);
}
// The file is already on the router: the same server key, or an address another tunnel has.
// Keenetic takes no two tunnels with one address; the owner chooses: replace it, add a new one, or stop.
let TC_DUP = null;
function tcDup(form, x, text, desc) {
  const same = x.same, taken = x.sameaddr, target = same || taken, kind = same ? x.samekind : x.sameaddrkind;
  TC_DUP = { text: text, desc: desc, name: target, x: x };
  const canReplace = kind === 'firmware' || kind === 'awg', canNew = !taken;
  const msg = same ? 'Такая конфигурация уже есть: туннель «' + tunLabel(same) + '» (тот же сервер и тот же ключ сервера).' + (canNew ? ' Можно заменить его этой конфигурацией или добавить отдельный туннель.' : '')
    : 'Адрес в туннеле ' + (x.address || '') + ' уже занят: «' + tunLabel(taken) + '» (другой сервер). Keenetic не принимает два туннеля с одним адресом, поэтому добавить новый нельзя.' + (canReplace ? ' Заменить: сервер и ключи этого туннеля станут из файла, маршруты и списки останутся.' : '');
  form.querySelector('[type=submit]').hidden = true; form.dataset.checked = 'dup';
  $('tcPreview').innerHTML = '<p class="field-warn">' + esc(msg) + (canReplace ? '' : ' Заменить его из Панели нельзя: ' + (kind === 'vless' ? 'это туннель VLESS - удалите его и добавьте заново.' : 'это не туннель, а другое подключение Keenetic.')) + '</p>' +
    '<div class="panel-actions">' + (canReplace ? '<button class="btn primary" type="button" data-act="tc-dup" data-choice="replace">Заменить «' + esc(tunLabel(target)) + '»</button>' : '') +
    (canNew ? '<button class="btn" type="button" data-act="tc-dup" data-choice="new">Добавить как новый</button>' : '') +
    '<button class="btn" type="button" data-act="tc-dup" data-choice="cancel">Отмена</button></div>';
}
function tunnelConfSheet(mode, name) {
  openSheet(mode === 'create' ? 'Добавить туннель' : 'Заменить конфигурацию · ' + name,
    '<div class="sheet-body"><form class="stack-form" data-form="tunnel-conf" data-mode="' + mode + '" data-name="' + esc(name || '') + '">' +
    (mode === 'create' ? '<input class="input" name="description" maxlength="64" placeholder="Название, например Германия-2" aria-label="Название туннеля">' : '') +
    // Like Keenetic: from a file, or the same values typed in by hand.
    '<div class="segmented" role="group" aria-label="Как ввести"><button type="button" data-act="tc-mode" data-m="file" aria-pressed="true">Из файла</button><button type="button" data-act="tc-mode" data-m="manual" aria-pressed="false">Вручную</button></div>' +
    '<div class="stack-form tc-file">' +
    '<label class="file-pick">' + ico('save') + '<span>Выбрать файл .conf или .vpn</span><input type="file" name="file" data-conf-file></label>' +
    '<textarea class="input mono" name="conf" rows="7" spellcheck="false" autocomplete="off" aria-label="Текст конфигурации" placeholder="или вставьте текст [Interface] PrivateKey = …, ключ Amnezia vpn://…' + (mode === 'create' ? ', ссылку vless://… или trojan://…, или адрес подписки https://…' : '') + '"></textarea></div>' +
    '<div class="stack-form tc-manual" hidden>' +
    TC_FIELDS.map(f => '<label class="field"><span class="form-label">' + esc(f[1]) + '</span>' + (f[0] === 'awg' ?
      '<textarea class="input mono" name="tc-awg" rows="3" spellcheck="false" autocomplete="off" placeholder="Jc = 4&#10;Jmin = 40&#10;…"></textarea>' :
      '<input class="input' + (f[4] ? ' mono' : '') + '" name="tc-' + f[0] + '"' + (f[3] ? ' type="password"' : '') + ' placeholder="' + esc(f[2]) + '" autocomplete="off" spellcheck="false">') + '</label>').join('') +
    '</div>' +
    '<div id="tcPreview"></div>' +
    '<p class="panel-desc">' + (mode === 'create' ? 'VWARD создаст туннель и дождётся ответа сервера. Если сервер не ответит, туннель удалится.' :
      'Сначала конфигурация проверяется на временном туннеле. Только если сервер ответил, она записывается в ' + esc(name) + ': маршруты и списки остаются на месте.') + ' Ключи не показываются и не пишутся в журналы.</p>' +
    '<button class="btn primary" type="submit">Проверить</button></form></div>');
}
function tunnelTrafficPanel(name) {
  const L = S.lists || {}, lists = (L.lists || []).filter(l => l.route === name), nets = (L.subnets || {})[name] || [];
  // The API sends at most 300 subnets a tunnel; the count is the real one (it said «300», Viva 2026-10-17).
  const netN = (L.subnet_counts || {})[name] != null ? L.subnet_counts[name] : nets.length;
  return panel('Маршруты', (!S.lists ? empty('Загрузка…') :
      // Lists are changed in one place, «Доменные списки»; subnets on their own page, not a sheet here.
      kv([['Доменные списки', lists.length ? String(lists.length) : 'нет', '', 'lists'],
          ['Подсети', netN ? fmtInt(netN) : 'нет', '', 'tn-' + name]])) + resultBox('tunnel-traffic'));
}
// tunnelNetsPage NAME: the tunnel's subnets - adding, a search that hides the rows that do
// not match (the page is not redrawn, the field keeps the cursor), removal.
function tunnelNetsPage(name) {
  const nets = ((S.lists || {}).subnets || {})[name] || [];
  const rows = nets.map(n => '<li class="row" data-net="' + esc(n) + '"><div class="row-main"><b class="mono">' + esc(n) + '</b></div><span class="row-acts">' + rowBtn('tsubnet', 'remove', n, 'close', 'Убрать ' + n + ' из туннеля') + '</span></li>').join('');
  return panel('Подсети', !S.lists ? empty('Загрузка…') :
      inputBar({ form: 'tunnel-subnet', attrs: ' data-name="' + esc(name) + '"', label: 'Добавить подсеть', name: 'subnet', mono: true, placeholder: '149.154.160.0/20', aria: 'Подсеть', off: !cfgOk(), icon: 'plus', btn: 'Добавить' }) +
      (nets.length > 10 ? '<div class="stack-form"><input class="input mono" type="search" data-net-filter="1" placeholder="Найти подсеть" aria-label="Найти подсеть" autocomplete="off"></div>' : '') +
      (nets.length ? '<ul class="rows" id="netRows">' + rows + '</ul>' : empty('Подсетей нет')) +
      resultBox('tunnel-traffic'),
    { desc: (function () {
      const all = ((S.lists || {}).subnet_counts || {})[name] != null ? S.lists.subnet_counts[name] : nets.length;
      return fmtInt(all) + ' подсетей идут через «' + tunLabel(name) + '».' + (all > nets.length ? ' Показаны первые ' + fmtInt(nets.length) + '.' : '');
    })() });
}
// The size slider says where it stands while it moves; the setting is saved when it is let go.
document.addEventListener('input', e => {
  if (!e.target.hasAttribute || !e.target.hasAttribute('data-journal-size')) return;
  const txt = journalSizeText(JOURNAL_SIZE[+e.target.value]), o = $('journalSize');
  if (o) o.textContent = txt; e.target.setAttribute('aria-valuetext', txt);
});
document.addEventListener('input', e => {
  if (!e.target.dataset || !e.target.dataset.netFilter) return;
  const q = e.target.value.trim();
  document.querySelectorAll('#netRows [data-net]').forEach(li => { li.hidden = !!q && !li.dataset.net.includes(q); });
});
function tunnelManagePanel(name, managed) {
  // Only a WireGuard (AmneziaWG) tunnel takes a .conf; the others are set up in Keenetic.
  // VWARD's engines (AmneziaWG, VLESS) are Keenetic «OpkgTun» connections: checked first.
  const own = ((st().wg && st().wg.interfaces) || []).find(t => t.name === name);
  const engine = vlessOf(name) || ((S.awg && S.awg.tunnels) || []).some(t => t.name === name);
  const lost = tunLost(own);
  if (!engine && !lost && own && own.type && own.type !== 'wireguard')
    return [panel('Конфигурация', '<p class="panel-desc">Туннель настраивается в Keenetic, VWARD только направляет через него маршруты.</p>')];
  const others = ((st().wg && st().wg.interfaces) || []).filter(t => t.name !== name);
  const L = S.lists || {}, routed = (L.lists || []).some(l => l.route === name) || ((L.subnet_counts || {})[name] || ((L.subnets || {})[name] || []).length) > 0;
  const del = managed ? '<p class="panel-desc">Это туннель по умолчанию, его нельзя удалить или выключить. Сначала назначьте туннелем по умолчанию другой туннель.</p>' :
    (confirm && confirm.id === 'tunnel-delete' ? '<div class="confirm danger"><span>Удалить ' + esc(tunLabel(name)) + '? Его списки и подсети перейдут: ' + esc(confirm.to === 'bypass' ? 'на провайдера' : confirm.to === 'vpn' ? 'в туннель по умолчанию' : tunLabel(confirm.to)) + '. Ключи туннеля удалятся.</span><button class="btn small danger" type="button" data-act="confirm-yes">Удалить</button><button class="btn small" type="button" data-act="confirm-no">Отмена</button></div>' :
      (routed ? '<dl class="kv">' + ctrlRow('Куда передать списки и подсети', sel('data-tunnel-del-to', 'Куда передать', [['vpn', 'Туннель по умолчанию'], ['bypass', 'Провайдер']].concat(others.filter(t => t.name !== prof().tunnel_interface).map(t => [t.name, tunLabel(t.name)])), 'vpn')) + '</dl>' : '') +
      '<div class="panel-actions even">' + btn('tunnel-delete', 'trash', 'Удалить туннель', 'danger', cfgOk() ? '' : ' disabled') + '</div>');
  // The default tunnel cannot be removed: no section for it at all (owner 2026-10-17).
  const delPanel = managed ? '' : panel('Удаление', del, { desc: routed ? 'Списки и подсети туннеля перейдут, куда выберете.' : 'У туннеля нет списков и подсетей.' });
  // Its lists and subnets go nowhere (the route is withdrawn, sites go via the provider):
  // one tap moves them to the default tunnel, the tunnel itself stays (fix.32).
  const mv = !managed && routed ? (confirmBox('tunnel-move', 'Перенести списки и подсети ' + tunLabel(name) + ' (' + tunUseExtra(name) + ') на ' + tunLabel(prof().tunnel_interface) + '? Туннель останется, удалить его можно потом.', 'Перенести') ||
    '<p class="field-warn">На туннеле ' + esc(String(tunUseExtra(name))) + ' списков и подсетей: пока он без настроек, эти сайты идут напрямую через провайдера.</p><div class="panel-actions">' + btn('ask', 'route', 'Перенести на туннель по умолчанию', 'primary', ' data-confirm="tunnel-move"' + (cfgOk() ? '' : ' disabled')) + '</div>') : '';
  if (lost)
    return [panel('Нет настроек', '<p class="panel-desc">Настройки туннеля хранились на флешке и пропали вместе с ней, поэтому включить его нельзя. Добавьте туннель заново - ключ, ссылку или файл' +
      (managed ? ', затем у нового нажмите «Сделать туннелем по умолчанию»: списки и подсети переедут на него. Этот туннель потом удалите.' : '. Этот туннель потом удалите.') + '</p>' +
      '<div class="panel-actions">' + btn('tunnel-create', 'plus', 'Добавить туннель', 'primary', cfgOk() ? '' : ' disabled') + '</div>' + mv + (managed ? '' : del))];
  const vl = vlessOf(name);
  if (vl)
    return [vlessServersPanel(name),
      vl.running ? '' : panel('Модуль VLESS', kv([['Xray', ST.bad[1], ST.bad[0], 'd-vless']])),
      soonPanel('vless') + delPanel];
  if (((S.awg && S.awg.tunnels) || []).some(t => t.name === name))
    return [nativePanel(), panel('Конфигурация', '<p class="panel-desc">Туннель держит модуль AmneziaWG VWARD. Чтобы сменить сервер, добавьте новый туннель и удалите этот.</p>' + kv([['Модуль AmneziaWG', 'Компоненты', '', 'd-awg', '', '', 'out']])),
      delPanel];
  return [panel('Конфигурация', '<div class="panel-actions even">' + btn('tunnel-replace', 'refresh', 'Заменить конфигурацию', 'primary', cfgOk() ? '' : ' disabled') + '</div>' + resultBox('tunnel-conf'),
      { desc: 'Новый .conf в этот же туннель, маршруты останутся.' }),
    delPanel];
}
// The servers of a VLESS tunnel's subscription, as the VPN apps show them: the country flag and
// name, the time a connection from the router takes (or «нет ответа»), the server in use. A tap
// moves the tunnel to that server; it stays on its own when the new one does not answer.
const VSRV = {};
// Why a server did not answer the connection test (curl's exit code from the engine).
const VSRV_SHORT = { dns: 'Имя не найдено', refused: 'Отказ', timeout: 'Нет ответа' };
const VSRV_WHY = { dns: 'имя сервера не находится в DNS', refused: 'сервер отказал в соединении: порт закрыт', timeout: 'сервер не ответил за 2 секунды' };
// Countries (fix.28.2): from the flag at the start of a server's name, as the engine reads it.
const VFLAG = /^\s*([\u{1F1E6}-\u{1F1FF}])([\u{1F1E6}-\u{1F1FF}])\s*/u;
const vCode = n => { const m = VFLAG.exec(n || ''); return m ? String.fromCharCode(m[1].codePointAt(0) - 0x1F1E6 + 65, m[2].codePointAt(0) - 0x1F1E6 + 65) : '--'; };
let REGION = null;
try { REGION = new Intl.DisplayNames(['ru'], { type: 'region' }); } catch (e) { REGION = null; }
const vFlag = c => c === '--' ? '' : String.fromCodePoint(...[...c].map(ch => 0x1F1E6 + ch.charCodeAt(0) - 65));
// Short names where the browser's are long (owner 2026-10-17: «США», not «Соединенные Штаты»).
const VSHORT = { US: 'США', GB: 'Великобритания', AE: 'ОАЭ', KR: 'Южная Корея', CZ: 'Чехия', HK: 'Гонконг', RU: 'Россия', MD: 'Молдова', BA: 'Босния', MK: 'Македония' };
const vCountry = c => { if (c === '--') return 'Без страны'; if (VSHORT[c]) return VSHORT[c]; try { return (REGION && REGION.of(c)) || c; } catch (e) { return c; } };
// How the list is shown: grouped by country or one list, and the order; kept in this browser.
let VVIEW = { group: true, sort: 'ping' };
try { VVIEW = Object.assign(VVIEW, JSON.parse(localStorage.getItem('vward.vless.view') || '{}')); } catch (e) { /* defaults */ }
const vViewSave = () => { try { localStorage.setItem('vward.vless.view', JSON.stringify(VVIEW)); } catch (e) { /* only this visit */ } };
const VOPEN = new Set();
const VSORT = [['ping', 'Отклик'], ['name', 'Название'], ['country', 'Страна']];
function vSort(list) {
  const ms = x => x.ms != null ? x.ms : 1e9, nm = x => (x.name || x.host || '').replace(VFLAG, '');
  const by = { ping: (a, b) => ms(a) - ms(b), name: (a, b) => nm(a).localeCompare(nm(b), 'ru'),
    country: (a, b) => vCountry(vCode(a.name)).localeCompare(vCountry(vCode(b.name)), 'ru') || ms(a) - ms(b) }[VVIEW.sort] || ((a, b) => ms(a) - ms(b));
  // The server in use first: in a long subscription it was somewhere below (a Viva 2026-10-12).
  return list.slice().sort((a, b) => (b.current ? 1 : 0) - (a.current ? 1 : 0) || by(a, b));
}
function vRow(name, s, off) {
  const pick = !s.current && !off;
  return '<li class="row' + (pick ? ' link' : '') + (off ? ' muted' : '') + '"' + (pick ? ' role="button" tabindex="0" data-vserver="' + s.n + '" data-name="' + esc(name) + '"' : '') + '><div class="row-main"><b>' + esc(s.name || s.host) + '</b><small>' + esc(s.host) + '</small></div>' +
    '<span class="pill ' + (s.current ? 'info' : off ? '' : s.ms != null ? 'ok' : 'crit') + '"' + (s.current || s.ms != null || off ? '' : ' title="' + esc(VSRV_WHY[s.why] || VSRV_WHY.timeout) + '"') + '>' +
    (s.current ? 'Подключён' : off ? 'Страна выключена' : s.ms != null ? s.ms + ' мс' : VSRV_SHORT[s.why] || 'Нет ответа') + '</span></li>';
}
function vlessServersPanel(name) {
  const v = VSRV[name];
  // Shown at once when the tunnel's page opens: no button first (owner 2026-10-17).
  if (!v) { setTimeout(() => { if (!VSRV[name]) vlessServers(name); }, 0); return panel('Серверы', empty('Проверка серверов…')); }
  const head = '<div class="panel-actions">' + btn('vless-servers', 'refresh', v.busy ? 'Проверяем…' : 'Обновить', '', ' data-name="' + esc(name) + '"' + (v.busy ? ' disabled' : '')) + '</div>';
  if (v.busy && !v.data) return panel('Серверы', empty('Проверка серверов…'));
  if (v.error) return panel('Серверы', '<p class="field-warn">' + esc(v.error) + '</p>' + head);
  const d = v.data, off = new Set((d.countries && d.countries.off) || []), all = d.servers || [];
  const view = '<dl class="kv">' + ctrlRow('Группировать по странам', sw('data-vsrv-group', VVIEW.group, 'Группировать по странам')) +
    ctrlRow('Переходить между странами', sw('data-vcross="' + esc(name) + '"', !d.countries || d.countries.cross !== false, 'Переходить между странами', !cfgOk()),
      'сервер не отвечает - туннель перейдёт на сервер другой включённой страны') + '</dl>' +
    '<p class="panel-desc">Сортировка</p>' + choiceSlider('vsrv-sort', VSORT.filter(o => !(VVIEW.group && o[0] === 'country')), VVIEW.group && VVIEW.sort === 'country' ? 'ping' : VVIEW.sort, 'Сортировка', true);
  let body;
  if (!all.length) body = empty('В подписке нет серверов');
  else if (!VVIEW.group) body = '<ul class="rows">' + vSort(all).map(s => vRow(name, s, off.has(vCode(s.name)) && !s.current)).join('') + '</ul>';
  else {
    const groups = {};
    all.forEach(s => { (groups[vCode(s.name)] = groups[vCode(s.name)] || []).push(s); });
    const best = g => Math.min(...g.map(x => x.ms != null ? x.ms : 1e9));
    const codes = Object.keys(groups).sort((x, y) => (groups[y].some(v => v.current) ? 1 : 0) - (groups[x].some(v => v.current) ? 1 : 0) || (x === '--' ? 1 : 0) - (y === '--' ? 1 : 0) ||
      (VVIEW.sort === 'name' ? vCountry(x).localeCompare(vCountry(y), 'ru') : best(groups[x]) - best(groups[y])));
    body = codes.map(c => {
      const g = groups[c], open = VOPEN.has(name + '|' + c), b = best(g), isOff = off.has(c);
      // The country's switch in its own row, the arrow opens it (owner 2026-10-17).
      return '<div class="vgroup' + (isOff ? ' muted' : '') + (open ? ' open' : '') + '"><div class="vhead">' +
        '<div class="row-main link" role="button" tabindex="0" data-act="vsrv-open" data-code="' + c + '" data-name="' + esc(name) + '" aria-expanded="' + open + '"><b>' + esc((vFlag(c) ? vFlag(c) + ' ' : '') + vCountry(c)) + '</b><small>' + g.length + ' ' + plural(g.length, 'сервер', 'сервера', 'серверов') +
        (g.some(x => x.current) ? ' · подключён' : isOff ? ' · выключена' : b < 1e9 ? ' · лучший ' + b + ' мс' : ' · нет ответа') + '</small></div>' +
        sw('data-vcountry="' + c + '" data-name="' + esc(name) + '"', !isOff, vCountry(c), !cfgOk() || g.some(x => x.current)) +
        '<button class="icon-btn vchev" type="button" data-act="vsrv-open" data-code="' + c + '" data-name="' + esc(name) + '" aria-expanded="' + open + '" aria-label="' + (open ? 'Свернуть' : 'Развернуть') + '">' + ico('down') + '</button></div>' +
        (open ? '<ul class="rows">' + vSort(g).map(s => vRow(name, s, isOff && !s.current)).join('') + '</ul>' : '') + '</div>';
    }).join('');
  }
  return panel('Серверы', view + body + head,
    { beta: true, desc: 'Нажмите на сервер, чтобы подключиться. Выключенную страну VWARD сам не выбирает.' });
}
async function vlessCountry(name, code, on) {
  let r;
  try { r = await apiPost('tunnel-conf', { op: 'countries', name: name, target: code, value: on ? '1' : '0' }); } catch (e) { r = { ok: false, error: e.message }; }
  if (!r.ok) toast('Не сохранено: ' + errText(r));
  else if (VSRV[name] && VSRV[name].data) {
    const c = VSRV[name].data.countries = VSRV[name].data.countries || { off: [], cross: true };
    if (code === 'cross') c.cross = on; else c.off = c.off.filter(x => x !== code).concat(on ? [] : [code]);
  }
  render();
}
async function vlessServers(name, fresh) {
  VSRV[name] = Object.assign(VSRV[name] || {}, { busy: true, error: '' }); render();
  let r;
  try { r = await apiPost('tunnel-conf', fresh ? { op: 'servers', name: name, fresh: '1' } : { op: 'servers', name: name }); } catch (e) { r = { ok: false, error: e.message }; }
  VSRV[name] = r.ok ? { data: r } : { error: errText(r) };
  render();
}
async function vlessSelect(name, n) {
  const s = ((VSRV[name] && VSRV[name].data && VSRV[name].data.servers) || []).find(x => String(x.n) === String(n));
  tunOverlay = null;
  tunOverlayShow({ head: 'Смена сервера', okHead: 'Сервер сменён', failHead: 'Сервер не ответил', sub: s ? s.name || s.host : '', step: 'program' });
  const r = await runJob({ op: 'server', name: name, server: String(n) }, 2);
  tunOverlayShow({ done: true, ok: r.ok, open: '', stage: r.ok ? tunLabel(name) : '', text: r.ok ? 'Туннель подключён к новому серверу.' : r.code === 'server_unreachable' ? 'Сервер не ответил, туннель остался на прежнем.' : r.text });
  await Promise.all([load('status', true), load('awg', true)]);
  await vlessServers(name);
}
// Snapshots of VWARD's settings: one a day automatically, or by the button.
function backupPanel() {
  const b = S.backups, list = (b && b.backups) || [], kinds = { manual: 'вручную', auto: 'автоматически', prerestore: 'перед восстановлением' };
  const rows = list.map(x => '<li class="row"><div class="row-main"><b>' + esc(fmtTime(x.created)) + '</b><small>' + esc(kinds[x.kind] || x.kind) + ' · ' + esc(fmtBytes(x.size)) + '</small>' +
    '</div>' +
    '<span class="row-acts"><a class="icon-btn" href="/cgi-bin/api.cgi?action=backup-download&amp;name=' + encodeURIComponent(x.name) + '" download aria-label="Скачать" title="Скачать">' + ico('save') + '</a>' +
    '<button class="icon-btn" type="button" data-backup-restore="' + esc(x.name) + '" aria-label="Восстановить" title="Восстановить"' + (cfgOk() ? '' : ' disabled') + '>' + ico('undo') + '</button></span>' +
    (confirm && confirm.id === 'backup-restore' && confirm.name === x.name ? '<div class="confirm danger"><span>Восстановить настройки VWARD на это время? Текущие сохранятся отдельной копией.</span><button class="btn small danger" type="button" data-act="confirm-yes">Восстановить</button><button class="btn small" type="button" data-act="confirm-no">Отмена</button></div>' : '') + '</li>').join('');
  return panel('Резервные копии', (!b ? empty('Загрузка…') : !b.ok ? empty(errText(b)) : list.length ? '<ul class="rows">' + rows + '</ul>' : empty('Копий пока нет')) +
    '<div class="panel-actions">' + btn('backup-create', 'archive', 'Создать копию сейчас', '', cfgOk() ? '' : ' disabled') + '</div>' + resultBox('backup'),
    { desc: 'Раз в сутки, хранятся 7 копий.' });
}
// AdGuard Home's own ad settings, changed through its API (the rest stays in its web UI).
function aghSettingsPanel(a) {
  if (!S.ads || !a.agh_connected) return '';
  const g = S.agh;
  if (!g) return panel('Фильтрация', empty('Загрузка…'));
  if (!g.ok) return panel('Фильтрация', empty(errText(g)));
  const f = g.filtering || {}, fl = f.filters || [], sv = g.services, on = cfgOk() || true;
  const row = (key, label, val, hint, extra) => val == null ? '' : ctrlRow(label, sw('data-agh="' + key + '"', val, label), hint);
  return panel('Фильтрация', '<dl class="kv">' +
      row('protection', 'Фильтрация AdGuard Home', g.protection, g.protection ? 'блокирует по всем фильтрам и правилам' : 'выключена - реклама не блокируется') +
      confirmBox('agh-protection-off', 'Выключить защиту AdGuard Home? Реклама и трекеры перестанут блокироваться на всех устройствах.', 'Выключить', true) +
      (f.enabled == null ? '' : fl.length ? row('filtering', 'Фильтрация по спискам', f.enabled, fmtInt(fl.filter(x => x.enabled).length) + ' из ' + fmtInt(fl.length) + ' списков включены') :
        ctrlRow('Фильтрация по спискам', sw('data-agh="filtering"', false, 'Фильтрация по спискам', true), 'списков нет - добавьте в «Фильтрах»')) +
      (f.interval == null ? '' : ctrlRow('Обновлять списки', sel('data-agh-interval', 'Обновлять списки', [[0, 'не обновлять'], [1, 'каждый час'], [12, 'каждые 12 ч'], [24, 'раз в сутки'], [72, 'раз в 3 дня'], [168, 'раз в неделю']], f.interval))) +
      row('safebrowsing', 'Безопасная навигация', g.safebrowsing, 'блокирует фишинг и вредоносные сайты') +
      row('parental', 'Родительский контроль', g.parental, 'блокирует сайты для взрослых') +
      row('safesearch', 'Безопасный поиск', g.safesearch, 'строгий режим в поисковиках и YouTube') + '</dl>' +
      kv([f.filters ? ['Фильтры', fmtInt(fl.filter(x => x.enabled).length) + ' из ' + fmtInt(fl.length) + ' · ' + fmtInt(fl.reduce((n, x) => n + (x.enabled ? x.rules : 0), 0)) + ' правил', '', 'd-aghfilters'] : null,
        sv ? ['Блокировка сервисов', sv.blocked.length ? fmtInt(sv.blocked.length) + ' заблокировано' : 'нет', '', 'd-aghservices'] : null]) + resultBox('agh'),
    { desc: 'Меняется сразу; остальное - в веб-интерфейсе AdGuard Home.' });
}
async function aghSet(fields, okMsg) {
  let x;
  try { x = await apiPost('ads-control', Object.assign({ op: 'agh' }, fields)); }
  catch (e) { toast('Ошибка: ' + e.message); return; }
  const err = /ERROR=([a-z_]+)/.exec(x.result || '');
  toast(x.ok ? okMsg : 'Не выполнено: ' + (err ? errText({ error: err[1] }) : errText(x)));
  await load('agh', true); render();
}
// AdGuard Home asks for a login: VWARD keeps it (root-only file) after AdGuard accepts it.
function aghConnectPanel(a) {
  if (!S.ads) return '';
  // Connected: nothing to show (owner 2026-10-17); not connected: the login, needed for the statistics.
  if (a.agh_connected) return '';
  // Nothing to connect to: the program is not on the router (a formatted USB stick, Viva 2026-10-19).
  if (aghState()[1] === ST.none[1]) return '';
  return panel('Подключить VWARD к AdGuard Home', '<form class="inline-form multi" data-form="agh-connect">' + formLabel('Логин и пароль от AdGuard Home') + '<input class="input" name="login" placeholder="логин AdGuard Home" aria-label="Логин AdGuard Home" autocomplete="username"><input class="input" name="password" type="password" placeholder="пароль" aria-label="Пароль AdGuard Home" autocomplete="current-password"><button class="btn primary" type="submit">Подключить</button></form>',
    { desc: 'Пароль проверяется и хранится только на роутере.' });
}
function tunnelProbePanel(name) {
  const r = S.tprobe[name], ex = r && r.exit, sv = (r && r.server) || {}, pg = (r && r.ping) || {};
  const place = ex ? [ex.city, ex.region, ex.country].filter(Boolean).join(', ') : '';
  const body = !r ? '' : r.busy ? empty('Проверка… до 10 секунд') : !r.ok ? empty(errText(r)) : kv([
    ['Внешний IP', ex ? ex.ip : 'не определён', ex ? '' : 'warn'],
    ['Местоположение', place || '—'],
    ['Провайдер', (ex && ex.org) || '—'],
    [/^http/.test(pg.target || '') ? 'Отклик страницы 1.1.1.1' : 'Пинг до ' + (pg.target || '1.1.1.1'), pg.avg_ms != null ? Math.round(pg.avg_ms) + ' мс' : 'нет ответа', pg.avg_ms != null ? '' : 'warn'],
    ['Потери', pg.loss != null ? pg.loss + '%' : '—', pg.loss ? (pg.loss >= 50 ? 'crit' : 'warn') : ''],
    // A VLESS tunnel: its server is the engine's, and the WireGuard rows do not apply.
    ['Сервер', vlessOf(name) ? ([vlessOf(name).server_name, vlessOf(name).server].filter(Boolean).join(' · ') || '—') : (sv.host || '—') + (sv.port ? ':' + sv.port : '')],
    vlessOf(name) ? null : ['Обфускация AmneziaWG', sv.awg ? 'Включена' : 'Выключена'],
    vlessOf(name) ? null : ['Keepalive', sv.keepalive ? sv.keepalive + ' с' : 'выключен']
  ]) + '<p class="panel-desc">Проверено в ' + esc(r.at) + '</p>';
  // On and off: the switch in the tunnel's own header (owner 2026-10-17); here two buttons.
  return panel('Проверка', body +
    '<div class="panel-actions even">' + btn('tunnel-probe', 'check', 'Проверить', 'primary', ' data-name="' + esc(name) + '"' + (r && r.busy ? ' disabled' : '')) +
    btn('tunnel-restart', 'refresh', 'Перезапустить', '', ' data-name="' + esc(name) + '"' + (cfgOk() && !TUNBUSY[name] && !TUNUP[name] ? '' : ' disabled')) + '</div>');
}
const wifiHost = mac => { const c = ((S.wifi && S.wifi.clients) || []).find(x => x.mac === mac); return (c && c.host) || null; };
const wifiName = mac => { const h = wifiHost(mac); return (h && (h.name || h.hostname)) || mac; };
const segPrev = {};
// Auto / 2.4 / 5 GHz as one slider: the thumb sits on the band Keenetic has
// pinned (or on the one being confirmed) and glides to a new choice.
function segSlider(mac, ops, on) {
  const b = ((S.wifi && S.wifi.binds) || {})[String(mac).toLowerCase()];
  const cur = b === '2g' ? 'bind-2g' : b === '5g' ? 'bind-5g' : 'auto';
  const shown = confirm && confirm.id === 'wifi-bind' ? confirm.op : cur;
  const to = Math.max(0, ops.findIndex(o => o[0] === shown)), from = segPrev[mac] != null ? segPrev[mac] : to;
  segPrev[mac] = to;
  return '<div class="seg-slider' + (on ? '' : ' off') + '" role="radiogroup" aria-label="Диапазон" data-i="' + from + '" data-to="' + to + '"><i class="seg-thumb"></i>' +
    ops.map(o => '<button type="button" role="radio" data-wifi-bind="' + o[0] + '" aria-checked="' + (o[0] === shown) + '"' + (on ? '' : ' disabled') + '>' + o[1] + '</button>').join('') + '</div>';
}
function wifiClientPage(mac) {
  const c = ((S.wifi && S.wifi.clients) || []).find(x => x.mac === mac) || { mac: mac };
  const ctl = S.config && S.config.wifi ? S.config.wifi.CONTROL_ENABLED : S.wifi && S.wifi.control_enabled;
  const ops = [['auto', 'Авто', 'WIFI_BAND_AUTO', 'Авто'], ['bind-2g', '2.4 ГГц', 'WIFI_BIND_2G', 'Только 2.4 ГГц'], ['bind-5g', '5 ГГц', 'WIFI_BIND_5G', 'Только 5 ГГц']];
  const h = c.host || {}, deny = h.access === 'deny';
  const device = panel('Устройство', inputBar({ form: 'wifi-name', attrs: ' data-mac="' + esc(mac) + '"', label: 'Имя устройства', name: 'name', maxlength: 64, value: h.name || '', placeholder: h.hostname || 'Имя устройства', off: !cfgOk(), icon: 'check', btn: h.registered ? 'Переименовать' : 'Сохранить' }) +
      '<dl class="kv">' + ctrlRow('Доступ в интернет', sw('data-wifi-access="' + esc(mac) + '"', !deny, 'Доступ в интернет для ' + wifiName(mac), !cfgOk()), deny ? 'запрещён: устройство видит только домашнюю сеть' : 'разрешён') + '</dl>' +
      confirmBox('wifi-deny', 'Запретить устройству «' + wifiName(mac) + '» выход в интернет? Домашняя сеть останется доступной.', 'Запретить', true) +
      kv([['MAC', mac], ['IP-адрес', h.ip || '—'], ['Имя в сети', h.hostname || '—'], ['Зарегистрировано в Keenetic', h.registered ? 'Да' : 'Нет'],
        h.ssid ? ['Сеть Wi-Fi', h.ssid] : null, h.rssi != null ? ['Сигнал', h.rssi + ' дБм', num(h.rssi) < -75 ? 'warn' : ''] : null,
        h.txrate != null ? ['Скорость', h.txrate + ' Мбит/с'] : null, h.uptime != null ? ['В сети', fmtUptime(h.uptime)] : null,
        h.rx != null || h.tx != null ? ['Трафик', '↓ ' + fmtBytes(h.rx) + ' · ↑ ' + fmtBytes(h.tx)] : null]) + cfgNote(),
    { desc: 'Имя сохраняется в Keenetic.' });
  return device + panel('Диапазоны Wi-Fi', kv([['Сейчас', bandText(c.band)], ['Состояние', recText(c) === 'Норма' ? 'без замечаний' : recText(c), c.health === 'WARNING' ? 'warn' : '', null, '', WIFI_REASONS[c.reason] || ''], ['Переходов за окно', fmtInt(c.switches)], ['Слабый 5 ГГц', fmtInt(c.weak_5g) + ' раз'], ['Мин. сигнал 5 ГГц', c.min_5g_rssi && c.min_5g_rssi !== '-' ? c.min_5g_rssi + ' дБм' : '—']])) +
    panel('Диапазон', segSlider(mac, ops, ctl) +
      (ctl ? '' : '<p class="panel-desc">Закрепление выключено: включите «Ручное управление» в разделе «Wi-Fi клиенты».</p>') +
      (confirm && confirm.id === 'wifi-bind' ? '<div class="confirm"><span>Применить «' + esc(ops.find(o => o[0] === confirm.op)[3]) + '» для ' + esc(mac) + '? Перед изменением сохранится резервная копия настроек, при ошибке изменение откатится.</span><button class="btn small primary" type="button" data-act="confirm-yes">Применить</button><button class="btn small" type="button" data-act="confirm-no">Отмена</button></div>' : '') + resultBox('wifi'),
    { desc: 'Только для зарегистрированных устройств.' });
}
// The confirmations of switching a component off or on (its page and «Управление»).
function compConfirm(c) {
  if (!confirm || confirm.comp && confirm.comp !== c.id) return '';
  const all = cfg().components || [], off = compCascade(c.id, true), onWith = compCascade(c.id, false);
  const stale = all.filter(d => d.uses.includes(c.id) && compOn(d.id) && !off.includes(d.id)).map(d => d.id);
  return (confirmBox('comp-off', 'Выключить «' + compName(c.id) + '»?' + (off.length ? ' Вместе с ним остановятся: ' + compNames(off) + '.' : '') + (stale.length ? ' На устаревших данных продолжат работать: ' + compNames(stale) + '.' : '') + ' Файлы и настройки останутся, включить можно в любой момент.', 'Выключить', true) ||
       confirmBox('comp-on', 'Включить «' + compName(c.id) + '»? Вместе с ним включатся: ' + compNames(onWith) + '.', 'Включить'));
}
function compPage(c) {
  const x = (plat().components || {})[c.id] || {}, g = graphOf(c.id), on = c.id === 'tunnel-guard' ? guardOn() : compOn(c.id), core = !!(g && g.core);
  const sw1 = core ? '<span class="num">Всегда</span>' : sw('data-comp="' + c.id + '"', on, 'Компонент «' + compName(c.id) + '» включён', !cfgOk() || !g);
  return panel(compName(c.id), '<dl class="kv">' + ctrlRow('Компонент включён', sw1, core ? 'базовый компонент: без него VWARD не работает' : on ? '' : 'файлы установлены, но компонент не запускается') + '</dl>' +
      compConfirm(c) +
      // fix.38.1: «Версия» and «Установлен» were VWARD's own version and «—» on every part - gone.
      kv([['Запуск', c.when]]) +
      '<div class="panel-actions even">' + (c.page ? '<button class="btn" type="button" data-go="' + c.page + '">Открыть раздел</button>' : '') + (activityOf(c.log) ? '<button class="btn" type="button" data-go="a-' + activityOf(c.log) + '">События</button>' : '') + '</div>' + cfgNote(),
    { desc: capFirst((partOf(c.id) || {}).desc || ''), right: headPill(!on ? 'warn' : x.health === 'PASS' ? 'ok' : '', !on ? 'Выключен' : x.health === 'PASS' ? 'Работает' : 'Нет данных') });
}

/* ---------- Навигация ---------- */
// A wide screen holds every section in the bar; a phone holds the chosen ones plus «Ещё».
const WIDE = window.matchMedia('(min-width: 900px)');
const barIds = () => WIDE.matches ? PAGES.map(p => p.id) : tabIds;
function tabsHtml() {
  const cur = navId(current);
  if (WIDE.matches) return barIds().map(id => '<button class="tab" type="button" data-tab="' + id + '"' + (id === cur ? ' aria-current="page"' : '') + '>' + ico(page(id).icon) + '<span>' + SHORT[id] + '</span></button>').join('');
  return tabIds.map(id => '<button class="tab" type="button" data-tab="' + id + '"' + (id === cur ? ' aria-current="page"' : '') + '>' + ico(page(id).icon) + '<span>' + SHORT[id] + '</span></button>').join('') +
    '<button class="tab" type="button" data-tab="more"' + (tabIds.includes(cur) ? '' : ' aria-current="page"') + '>' + ico('more') + '<span>Ещё</span></button>';
}
function renderNav() {
  const cur = navId(current), warnPages = new Set(notifications().map(n => navId(n.to)));
  $('tabbar').innerHTML = tabsHtml();
  $('tabbar').querySelectorAll('[data-tab]').forEach(t => { if (warnPages.has(t.dataset.tab) && t.dataset.tab !== cur) t.insertAdjacentHTML('beforeend', '<span class="dot" aria-label="Есть уведомление"></span>'); });
  document.documentElement.style.setProperty('--tabs', WIDE.matches ? barIds().length : tabIds.length + 1);
  const active = notifications();
  notesWatch(active);
  const unread = notesUnread(), n = unread.length;
  // Nothing wrong among the unread (a new version, a saved setting): a calm accent badge, not the red one.
  const onlyNews = n && !unread.some(x => ['warn', 'crit', 'err'].includes(x.sev));
  $('bellBtn').innerHTML = ico('bell') + (n ? '<span class="badge' + (onlyNews ? ' news' : '') + '">' + n + '</span>' : '');
  $('bellBtn').setAttribute('aria-label', n ? 'Уведомления: ' + n : 'Уведомления');
}
// Only the blocks whose markup changed are replaced: the rest keep their scroll, focus and open details.
let rendered = null;
function patchContent(html, whole) {
  const box = $('content'), t = document.createElement('template');
  t.innerHTML = html;
  ddEnhance(t.content);
  t.content.querySelectorAll('.meter i[data-width]').forEach(i => { i.style.width = Math.max(0, Math.min(100, Number(i.dataset.width))) + '%'; });
  const fresh = [...t.content.children], old = [...box.children];
  // A card that was a placeholder or the browser's copy fades in with the router's answer.
  const waited = new Set([...box.querySelectorAll('.card.skel[data-card], .card.stale[data-card]')].map(c => c.dataset.card));
  // A refresh of the same page keeps its height while the blocks are swapped: a page that
  // shrank for a moment brought the phone's address bar back and moved the bottom bar.
  if (!whole) box.style.minHeight = box.offsetHeight + 'px';
  if (whole || fresh.length !== old.length) box.replaceChildren(t.content);
  else fresh.forEach((n, i) => { if (!old[i].isEqualNode(n)) old[i].replaceWith(n); });
  // A new page slides in a little; a refresh of the same page never moves.
  if (whole) { box.classList.remove('page-enter'); void box.offsetWidth; box.classList.add('page-enter'); }
  if (waited.size) box.querySelectorAll('.card[data-card]').forEach(c => { if (waited.has(c.dataset.card) && !c.matches('.skel, .stale')) { c.classList.add('fade-in'); c.addEventListener('animationend', () => c.classList.remove('fade-in'), { once: true }); } });
  if (FERR) fieldErrShow(box.querySelector('form[data-form="' + FERR.form + '"]' + (FERR.kind ? '[data-kind="' + FERR.kind + '"]' : '')));
  // A three-way slider is drawn where it was and then moved, so the thumb glides.
  requestAnimationFrame(() => {
    box.querySelectorAll('.seg-slider[data-to]').forEach(el => { if (el.dataset.i !== el.dataset.to) el.dataset.i = el.dataset.to; });
    box.style.minHeight = '';
  });
}
/* ---------- Потянуть вниз - обновить ----------
   On a phone, the page pulled down from its very top refreshes its data (not the whole page:
   what is open stays open). The browser's own reload by pulling is off (overscroll-behavior).
   While it refreshes, only the line under the header runs: no round marker (owner 2026-10-17). */
(() => {
  let y0 = null, pulled = 0;
  const reset = () => { y0 = null; pulled = 0; };
  document.addEventListener('touchstart', e => { y0 = window.scrollY <= 0 && e.touches.length === 1 && !document.querySelector('.layer.open,[role=dialog]:not([hidden])') ? e.touches[0].clientY : null; pulled = 0; }, { passive: true });
  document.addEventListener('touchmove', e => {
    if (y0 == null) return;
    pulled = Math.max(0, Math.min(110, e.touches[0].clientY - y0));
    if (window.scrollY > 0) reset();
  }, { passive: true });
  document.addEventListener('touchend', () => {
    if (y0 != null && pulled >= 80) {
      const own = !document.body.classList.contains('loading');
      if (own) document.body.classList.add('loading');
      Promise.all(DATA_FOR(current).concat('off').map(k => load(k, true))).then(() => { render(); toast('Данные обновлены'); }, render)
        .finally(() => { if (own && !pageBusy) document.body.classList.remove('loading'); reset(); });
      return;
    }
    reset();
  }, { passive: true });
})();

/* ---------- Выпадающие списки ----------
   A native <select> opens a full-screen picker on phones.  Each one gets a
   button and a menu right under it; the select stays (hidden) as the value
   holder, so forms and the change handlers work as before. */
function ddLabel(sel) { const o = sel.options[sel.selectedIndex]; return o ? o.textContent : ''; }
function ddEnhance(root) {
  root.querySelectorAll('select.input:not([data-dd])').forEach(sel => {
    sel.setAttribute('data-dd', '1'); sel.classList.add('dd-native'); sel.tabIndex = -1;
    const b = document.createElement('button');
    b.type = 'button'; b.className = sel.className.replace('dd-native', '').trim() + ' dd-btn';
    b.setAttribute('aria-haspopup', 'listbox'); b.setAttribute('aria-expanded', 'false');
    if (sel.getAttribute('aria-label')) b.setAttribute('aria-label', sel.getAttribute('aria-label'));
    if (sel.disabled) b.disabled = true;
    b.innerHTML = '<span class="dd-val"></span>' + ico('chevron', 'dd-chev');
    b.firstChild.textContent = ddLabel(sel);
    sel.after(b);
  });
}
let ddOpen = null;
function ddClose(focus) {
  const m = $('ddMenu'); if (m) m.remove();
  if (ddOpen) { ddOpen.btn.setAttribute('aria-expanded', 'false'); if (focus) ddOpen.btn.focus(); }
  ddOpen = null;
}
function ddShow(btn) {
  const sel = btn.previousElementSibling;
  if (!sel || sel.tagName !== 'SELECT') return;
  ddClose();
  const m = document.createElement('div');
  m.id = 'ddMenu'; m.setAttribute('role', 'listbox');
  m.innerHTML = [...sel.options].map((o, i) => '<button type="button" role="option" class="dd-opt" data-dd-i="' + i + '" aria-selected="' + (i === sel.selectedIndex) + '"' + (o.disabled ? ' disabled' : '') + '>' + ico('check', 'dd-mark') + '<span>' + esc(o.textContent) + '</span></button>').join('');
  document.body.appendChild(m);
  const r = btn.getBoundingClientRect(), vw = document.documentElement.clientWidth, vh = window.innerHeight;
  const w = Math.min(Math.max(r.width, 200), vw - 16);
  m.style.width = w + 'px';
  m.style.left = Math.max(8, Math.min(r.left + r.width - w, vw - w - 8)) + 'px';
  const h = m.offsetHeight, below = vh - r.bottom - 8, above = r.top - 8;
  m.style.top = (h <= below || below >= above ? r.bottom + 4 : Math.max(8, r.top - Math.min(h, above) - 4)) + 'px';
  m.style.maxHeight = Math.max(160, h <= below || below >= above ? below : above) + 'px';
  ddOpen = { btn: btn, sel: sel };
  btn.setAttribute('aria-expanded', 'true');
  const cur = m.querySelector('[aria-selected="true"]') || m.querySelector('.dd-opt:not([disabled])');
  if (cur) { cur.focus({ preventScroll: true }); cur.scrollIntoView({ block: 'nearest' }); }
}
function ddPick(i) {
  if (!ddOpen) return;
  const { btn, sel } = ddOpen;
  ddClose(true);
  if (sel.selectedIndex === i) return;
  sel.selectedIndex = i;
  btn.firstChild.textContent = ddLabel(sel);
  sel.dispatchEvent(new Event('change', { bubbles: true }));
}
document.addEventListener('click', e => {
  const q = e.target.closest('[data-q]');
  if (!q) return;
  e.preventDefault(); e.stopPropagation();
  const k = qKey(q.dataset.q), id = q.dataset.q;
  if (QOPEN.has(k)) QOPEN.delete(k); else QOPEN.add(k);
  render();
  // Redrawn: the same «?» keeps the keyboard focus.
  const again = [...document.querySelectorAll('[data-q]')].find(b => b.dataset.q === id); if (again) again.focus();
}, true);
document.addEventListener('click', e => {
  const fold = e.target.closest('[data-fold]');
  if (fold && (fold.classList.contains('block-toggle') || !e.target.closest('a, button, input, select, [data-go]'))) {
    e.stopPropagation(); foldToggle(fold.dataset.fold); render(); return;
  }
  const opt = e.target.closest('.dd-opt');
  if (opt) { e.stopPropagation(); ddPick(Number(opt.dataset.ddI)); return; }
  const b = e.target.closest('.dd-btn');
  if (b) { e.stopPropagation(); if (ddOpen && ddOpen.btn === b) ddClose(); else ddShow(b); return; }
  if (ddOpen && !e.target.closest('#ddMenu')) ddClose();
}, true);
document.addEventListener('keydown', e => {
  if (!ddOpen) {
    const b = e.target.closest && e.target.closest('.dd-btn');
    if (b && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) { e.preventDefault(); ddShow(b); }
    return;
  }
  const opts = [...document.querySelectorAll('#ddMenu .dd-opt:not([disabled])')], at = opts.indexOf(document.activeElement);
  if (e.key === 'Escape') { e.preventDefault(); ddClose(true); }
  else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); const n = opts[(at + (e.key === 'ArrowDown' ? 1 : -1) + opts.length) % opts.length]; if (n) n.focus(); }
  else if (e.key === 'Tab') ddClose();
});
window.addEventListener('resize', () => ddClose());
window.addEventListener('scroll', e => { if (ddOpen && !(e.target && e.target.closest && e.target.closest('#ddMenu'))) ddClose(); }, true);

let PAGEQ = null;
function render() {
  const p = page(current);
  PAGEQ = null;
  document.title = p.title + ' · VWARD';
  const back = $('backBtn');
  back.classList.toggle('detail', !!p.parent);
  back.hidden = current === 'overview';
  back.setAttribute('aria-label', p.parent ? 'Назад: ' + page(p.parent).title : 'Назад к обзору');
  const html = current.startsWith('c-') ? compPage(comp(current.slice(2))) : current.startsWith('l-') ? listPage(current.slice(2)) : current.startsWith('ip-') ? addrPage(current.slice(3)) : current.startsWith('s-') ? servicePage(current.slice(2)) : current.startsWith('t-') ? tunnelPage(current.slice(2)) : current.startsWith('tn-') ? tunnelNetsPage(current.slice(3)) : current.startsWith('w-') ? wifiClientPage(current.slice(2)) : RENDER[current]();
  // The page title and, when the page's own block has a long explanation, its «?» right by it.
  // No «?» in the top bar on any page (owner 02.11): back, title, search, bell, theme; the page's
  // own explanation is shown in its block instead.
  $('pageTitle').innerHTML = '<span class="page-title-text">' + esc(p.title) + '</span>';
  patchContent(offNotice() + html, rendered !== current);
  rendered = current;
  // A chosen chip scrolled out of its row is brought back into view (the row only, not the page).
  document.querySelectorAll('.chips').forEach(row => {
    const on = row.querySelector('[aria-pressed="true"]'); if (!on) return;
    const x = on.getBoundingClientRect().left - row.getBoundingClientRect().left + row.scrollLeft;
    if (x < row.scrollLeft || x + on.offsetWidth > row.scrollLeft + row.clientWidth) row.scrollLeft = x - 16;
  });
  document.querySelectorAll('.tabbar.preview').forEach(t => t.style.setProperty('--tabs', tabIds.length + 1));
  renderNav();
}
// Every section is a browser history entry, so the back button and the back gesture stay inside VWARD.
// mode: 'pop' - called from history, 'replace' - no new entry.
const histDepth = () => (history.state && history.state.d) || 0;
// fix.38: pages merged into another; an old link, a bookmark or a notification lands there.
const MOVED = { 'd-components': 'utils' };
function go(id, key, mode) {
  if (MOVED[id]) id = MOVED[id];
  if (!page(id)) id = 'overview';
  if (mode !== 'pop') {
    const sheet = history.state && history.state.sheet;
    if (mode === 'replace' || sheet) history.replaceState({ p: id, d: histDepth() }, '', pathOf(id));
    else if (id !== current) history.pushState({ p: id, d: histDepth() + 1 }, '', pathOf(id));
  }
  // «Журналы» opened anew show nothing until asked (owner 12.11.2026).
  if (id === 'logs' && current !== 'logs') { logShown = {}; logQuery = ''; }
  // Autopick's live feed: read when its page opens, then with each refresh while it is open.
  if (id === 'd-adaptive' && current !== 'd-adaptive') { ADV.open = ''; ADV.lim = 50; ADV.tried = false; }
  current = id; editing = false; confirm = null; actionResult = null; FERR = null;
  closeLayer(true); render(); window.scrollTo(0, 0);
  if (key) { const row = [...document.querySelectorAll('[data-key]')].find(r => r.dataset.key === key); if (row) { row.scrollIntoView({ block: 'center' }); row.classList.add('flash'); } }
  refreshPage(true);
}
/* ---------- Загрузка страницы ----------
   A page opened or refreshed by the owner says so: a line under the top bar and «Обновление…»;
   after 3 seconds «Роутер отвечает медленно…» (owner 2026-10-12). The background refresh every
   few seconds stays quiet. */
let pageBusy = null;
function busyStart(id, keys) {
  // The same page still loading (the first answers, then the rest): the same 3 seconds.
  if (pageBusy && pageBusy.id === id) return pageBusy;
  const b = pageBusy = { id: id, slow: false };
  document.body.classList.add('loading'); document.body.classList.remove('slow');
  // «Обзор» says it in its own line under the title; other pages - under the top bar.
  // fix.38.1 (owner 12.11.2026, «роутер медленно отвечает» on every page): a page whose data is
  // already on the screen (the last refresh or the kept copy) is renewed quietly - the thin line
  // under the top bar only; the words come when after 3 s some of its data is still missing.
  setTimeout(() => { if (pageBusy !== b || (keys && keys.every(k => S[k] != null))) return; b.slow = true; document.body.classList.toggle('slow', id !== 'overview'); if (current === id) render(); }, 3000);
  return b;
}
function busyEnd(b) { if (!b || pageBusy !== b) return; pageBusy = null; document.body.classList.remove('loading', 'slow'); }
const busyOn = id => !!pageBusy && pageBusy.id === id;
async function refreshPage(busy, auto) {
  const id = current, keys = DATA_FOR(id).concat('off', 'notes'), b = busy ? busyStart(id, keys) : null;
  // owner 12.11.2026: «Журналы» load on «Показать журнал» only; a history loads on opening and on
  // «Обновить», never by the 15 s refresh.
  if (id === 'logs') { busyEnd(b); load('journal').then(() => { if (current === 'logs') render(); }, () => {}); return; }
  if (id.startsWith('a-') && !(auto && ACTAT[id.slice(2)])) loadActivity(id.slice(2));
  if (id.startsWith('t-')) keys.push('status', 'lists', 'awg', 'ext', 'tq');
  if (id.startsWith('tn-')) keys.push('status', 'lists');
  if (id.startsWith('l-')) keys.push('listd');
  if (id.startsWith('ip-')) keys.push('laddr');
  if (id.startsWith('s-')) keys.push('services', 'svcd', 'lists', 'status', 'config');
  if (id.startsWith('w-')) keys.push('wifi');
  if (id === 'd-https' || id === 'ads') keys.push('https');
  if (id === 'd-notes') notesVersions().forEach(v => loadNotes(v));
  if (id === 'd-querylog') keys.push('qlog');
  if (id === 'd-cron') keys.push('cron');
  if (id === 'd-review') keys.push('review');
  if (id === 'd-blocked') keys.push('blocked');
  if (id === 'd-allowed') keys.push('allowed');
  // Each answer is drawn as soon as it arrives: a slow source does not hold the others back.
  const draw = () => { if (current === id && !editing && !document.activeElement.matches('input,select,textarea')) render(); };
  await Promise.all(keys.map(k => load(k).then(draw, draw)));
  if (b && pageBusy === b) { busyEnd(b); draw(); }
}
// The open journal follows the router: on opening, every REFRESH_SEC while shown,
// on coming back to the tab, and right before it is saved.
const LOG_HOURS = 24;
// fix.35.3 (02.11: «Журналы пусты» at 21:45 over entries shown until 21:41, every source «не
// читается», the time renewed): a failed refresh keeps the last good text of each source and its
// time, with a warning; an empty window is said only when the sources answered so. One load per
// journal at a time: the 15 s refresh does not pile up 17 requests behind a slow router, and an
// older answer never overwrites a newer one. The owner's own request (auto false) runs once more
// after the one in progress.
// After a refresh that did not come through (a router slow to answer, 02.11 21:43-21:48 Keenetic's
// own DNS queue was late), the automatic one waits a minute instead of 15 s; the owner's does not.
const LOGRUN = {}, LOGGOOD = {}, LOGWARN = {}, LOGBACK = {};
function loadLog(tab, force, auto) {
  const r = LOGRUN[tab];
  if (r) { if (force && !auto) r.again = true; return r.p; }
  if (auto && (LOGBACK[tab] || 0) > Date.now()) return Promise.resolve(S.logs[tab]);
  if (!force && S.logs[tab] != null) render();
  const run = LOGRUN[tab] = { again: false };
  run.p = (async () => { let out; do { run.again = false; out = await loadLogOnce(tab); } while (run.again); return out; })()
    // Asked by the owner: the page is drawn anew once the load ends (the button, «Показать ещё», the time).
    .finally(() => { delete LOGRUN[tab]; if (current === 'logs' && logTab === tab && !editing) render(); });
  return run.p;
}
const logFailed = x => /^Журнал недоступен/.test(String(x || '').trim());
async function loadLogOnce(tab) {
  const hhmm = t => new Date(t).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  const want = logShown[tab] || logN;
  if (tab === 'all') {
    // «Расписание» is crond's own record of every start, not events: only in its tab.
    // The last 24 hours only, cut by the API (owner 02.11); older entries stay in the files and archives.
    // One request for every source (owner 12.11.2026), each source after its «@@VWARD-LOG name» line.
    const srcs = LOG_TABS.filter(tb => tb.id !== 'cron'), old = (tb, why) => { const g = LOGGOOD[tb.id]; return { label: tb.label, text: g ? g.text : 'Журнал недоступен: ' + why, err: why, at: g && g.at }; };
    let parts;
    try {
      const got = logSplit(await apiText('log', { name: 'all', count: want, hours: LOG_HOURS }));
      parts = srcs.map(tb => {
        const x = got[tb.id];
        if (x == null) return old(tb, 'нет в ответе роутера');
        if (!logFailed(x)) LOGGOOD[tb.id] = { text: x, at: Date.now() };
        return { label: tb.label, text: x };
      });
    } catch (e) { parts = srcs.map(tb => old(tb, e.message)); }
    LOGPARTS.length = 0; parts.forEach(p => LOGPARTS.push(p));
    const info = [], merged = mergeLogs(parts, logNewest, info, want);
    LOGMORE.all = want < LOG_MAX && merged.split('\n').filter(l => l && !l.startsWith('    ')).length >= want;
    parts.forEach((p, i) => { if (p.err) Object.assign(info[i], p.at ? { state: 'stale', at: p.at } : { state: 'error' }, { err: p.err }); });
    LOGINFO.length = 0; info.forEach(i => LOGINFO.push(i));
    const bad = parts.filter(p => p.err), why = bad.length ? bad[0].err : '';
    LOGBACK.all = bad.length ? Date.now() + 60000 : 0;
    if (bad.length === parts.length && LOGGOOD.all) {
      // Nothing came: the last good timeline stays with its own time.
      S.logs.all = LOGGOOD.all.text;
      LOGWARN.all = 'Журналы не обновились (' + why + '): показаны записи на ' + hhmm(LOGGOOD.all.at);
    } else {
      S.logs.all = merged || (bad.length ? 'Журналы не прочитаны: ' + why : 'Журналы пусты');
      S.loadedAt['log:all'] = Date.now();
      if (merged) LOGGOOD.all = { text: merged, at: Date.now() };
      LOGWARN.all = bad.length ? 'Не обновились ' + bad.length + ' из ' + parts.length + ' журналов (' + why + ')' + (bad.some(p => p.at) ? ': у них показаны прежние записи' : '') : '';
    }
  } else {
    try {
      const x = await apiText('log', { name: tab, count: want, hours: LOG_HOURS });
      S.logs[tab] = x; S.loadedAt['log:' + tab] = Date.now(); LOGWARN[tab] = ''; LOGBACK[tab] = 0;
      LOGMORE[tab] = want < LOG_MAX && x.split('\n').filter(Boolean).length >= want;
      if (!logFailed(x)) LOGGOOD[tab] = { text: x, at: Date.now() };
    } catch (e) {
      const g = LOGGOOD[tab]; LOGBACK[tab] = Date.now() + 60000;
      if (g) { S.logs[tab] = g.text; LOGWARN[tab] = 'Журнал не обновился (' + e.message + '): показаны записи на ' + hhmm(g.at); }
      else { S.logs[tab] = 'Журнал недоступен: ' + e.message; LOGWARN[tab] = ''; }
    }
  }
  return S.logs[tab];
}
// logSplit TEXT: {name: text} of the «Все» answer, one «@@VWARD-LOG name» line before each source.
function logSplit(text) {
  const out = {}; let cur = null;
  String(text || '').split('\n').forEach(l => {
    const m = /^@@VWARD-LOG ([a-z]+)$/.exec(l);
    if (m) { cur = m[1]; out[cur] = ''; } else if (cur != null) out[cur] += (out[cur] ? '\n' : '') + l;
  });
  return out;
}
const LOGPARTS = [];
// logPick TEXT, Q: the entries whose words hold Q (an entry keeps its continuation lines).
function logPick(text, q) {
  q = String(q || '').trim().toLowerCase();
  if (!q || text == null) return text;
  const out = []; let keep = false;
  String(text).split('\n').forEach(l => {
    if (logTime(l.replace(/^\[[^\]]+\] /, '')) != null || !out.length && !keep) keep = l.toLowerCase().includes(q);
    else if (!keep && l.toLowerCase().includes(q)) keep = true;
    if (keep) out.push(l);
  });
  return out.length ? out.join('\n') : 'Ничего не найдено';
}
// The last event of each source, apart from the moment the journals were loaded; a source that did
// not answer this time says so, with the time of the entries still shown for it.
function logSources() {
  if (!LOGINFO.length) return '';
  const st1 = { empty: 'записей нет', missing: 'ещё не создан', error: 'не читается', quiet: 'за 24 ч записей нет' };
  const val = i => i.state === 'stale' ? 'не обновился, записи на ' + new Date(i.at).toLocaleTimeString('ru-RU') : i.state === 'error' && i.err ? 'не прочитан: ' + i.err :
    i.last != null ? fmtTime(new Date(i.last).toISOString()) : st1[i.state];
  return '<details class="log-sources"><summary>' + ico('clock', 'log-sign') + '<span>Последняя запись по источникам</span>' + ico('chevron', 'chev') + '</summary><dl class="kv">' +
    LOGINFO.map(i => '<div class="kv-row"><dt>' + esc(i.label) + '</dt><dd' + (i.state === 'error' || i.state === 'stale' ? ' class="warn"' : '') + '>' + esc(val(i)) + '</dd></div>').join('') + '</dl></details>';
}
function logStamp(tab) {
  const t = S.loadedAt['log:' + tab];
  return t ? 'Запрошено в ' + new Date(t).toLocaleTimeString('ru-RU') : '';
}

/* ---------- Всплывающие панели ---------- */
function closeLayer(fromHistory) {
  const open = !!$('layer').innerHTML;
  loginOpen = false; $('layer').innerHTML = '';
  if (open && !fromHistory && history.state && history.state.sheet) history.back();
  ['searchBtn', 'bellBtn'].forEach(b => $(b).setAttribute('aria-expanded', 'false'));
}
// An open sheet is a history entry too: «back» closes it instead of leaving the section.
function openSheet(title, body, cls, btnId) {
  closeLayer(true);
  if (!(history.state && history.state.sheet)) history.pushState({ p: current, d: histDepth() + 1, sheet: 1 }, '', pathOf(current));
  $('layer').innerHTML = '<div class="scrim" data-act="close"></div><div class="sheet ' + (cls || '') + '" role="dialog" aria-label="' + esc(title || 'Поиск') + '">' + (title ? '<div class="sheet-head"><h2>' + esc(title) + '</h2><button class="icon-btn" type="button" data-act="close" aria-label="Закрыть">' + ico('close') + '</button></div>' : '') + body + '</div>';
  ddEnhance($('layer'));
  if (btnId) $(btnId).setAttribute('aria-expanded', 'true');
}
// Only registered devices may open VWARD, and this one is not.
function showDeviceBlocked() {
  cacheDrop();
  if (document.getElementById('deviceBlocked')) return;
  document.body.insertAdjacentHTML('beforeend', '<div id="deviceBlocked" class="blocked-screen" role="alertdialog" aria-label="Устройство не зарегистрировано"><div class="blocked-card">' + ico('lock') +
    '<h2>Устройство не зарегистрировано</h2><p>VWARD открывается с устройств, зарегистрированных в Keenetic. Телефон или компьютер, подключённый к роутеру по его VPN, получает адрес из пула VPN, и Keenetic не узнаёт его в списке.</p>' +
    '<form class="inline-form multi" data-form="blocked-login">' + formLabel('Войти с логином и паролем Keenetic') + '<input class="input" name="login" placeholder="логин Keenetic" aria-label="Логин" autocomplete="username"><input class="input" name="password" type="password" placeholder="пароль" aria-label="Пароль" autocomplete="current-password"><button class="btn primary" type="submit">Войти</button></form>' +
    '<p>Или зарегистрируйте устройство в веб-интерфейсе роутера: «Список устройств» → устройство → «Зарегистрировать», затем обновите страницу.</p>' +
    '<div class="panel-actions"><a class="btn" href="http://' + esc(location.hostname) + '/" target="_blank" rel="noopener">' + ico('external') + 'Открыть Keenetic</a><button class="btn primary" type="button" data-act="page-reload">' + ico('refresh') + 'Обновить</button></div></div></div>');
}
function showLogin() {
  cacheDrop();
  if (loginOpen) return;
  openSheet('Вход в Панель VWARD', '<div class="sheet-body"><form class="inline-form multi" data-form="login">' + formLabel('Логин и пароль от Keenetic') + '<input class="input" name="login" placeholder="логин Keenetic" aria-label="Логин" autocomplete="username"><input class="input" name="password" type="password" placeholder="пароль" aria-label="Пароль" autocomplete="current-password"><button class="btn primary" type="submit">Войти</button></form><p class="panel-desc">Логин и пароль от веб-интерфейса роутера.</p></div>');
  loginOpen = true;
}
const noteWhen = at => { const d = new Date(at * 1000), now = new Date(); return d.toDateString() === now.toDateString() ? d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) : fmtTime(at * 1000); };
// «{t}» in a note the router's agents wrote: the tunnel's name as the Panel shows it.
const noteTun = (x, t) => x.to && /^t-/.test(x.to) ? String(t || '').replace(/\{t\}/g, tunLabel(x.to.slice(2))) : t;
const noteItem = (x, cls, when) => '<' + (x.to ? 'button type="button" data-go="' + esc(x.to) + '"' : 'div') + ' class="note-item' + (cls ? ' ' + cls : '') + '"><span class="sev ' + esc(x.sev) + '">' + ico(x.icon || NOTE_ICON[x.sev] || 'alert') + '</span><span class="note-main"><b>' + esc(noteTun(x, x.title)) + '</b>' + (x.text ? '<small>' + esc(noteTun(x, x.text)) + '</small>' : '') + '</span>' + (when ? '<time>' + esc(when) + '</time>' : '') + '</' + (x.to ? 'button' : 'div') + '>';
// «Требует внимания»: what is wrong at this moment, goes by itself. «История»: what popped up, newest first, unread marked.
function openNotes() {
  const n = notifications(), nt = S.notes || {}, hist = nt.items || [], unread = notesUnread().length;
  const now = n.length ? '<div class="result-group">Требует внимания</div>' + n.map(x => noteItem(x)).join('') : '';
  const head = '<div class="notes-bar"><span>' + (unread ? 'Непрочитанных: ' + unread : hist.length ? 'Всё прочитано' : '') + '</span>' + (unread ? '<button class="link-btn" type="button" data-act="notes-read">Прочитать все</button>' : '') + '</div>';
  // A warning still shown above is not repeated below; it moves there when it goes.
  const keys = new Set(n.map(noteKey)), shown = hist.filter(x => !x.key || !keys.has(x.key));
  const past = shown.length ? '<div class="result-group">История</div>' + shown.map(x => noteItem(x, x.at > (nt.read_at || 0) ? 'unread' : '', noteWhen(x.at))).join('') : '';
  openSheet('Уведомления', '<div class="sheet-body">' + (n.length || hist.length ? head + now + past : empty('Всё работает штатно')) + '</div>', 'notes', 'bellBtn');
}
const SEARCH_INDEX = [
  ['system', 'Модель'], ['system', 'KeeneticOS'], ['system', 'Веб-интерфейс Keenetic'], ['system', 'VWARD'], ['system', 'Диагностика'], ['system', 'Файлы VWARD'], ['system', 'Свободно'],
  ['wan', 'Интерфейс'], ['wan', 'IPv4'], ['wan', 'Шлюз'], ['wan', 'Восстанавливать автоматически'], ['wan', 'Проверять'], ['wan', 'Обновить адрес'], ['wan', 'Переподключить'], ['d-wanrec', 'Неудачных проверок подряд'],
  ['settings', 'Только зарегистрированные устройства'], ['vpn', 'Агент VPN'], ['vpn', 'Маршрутизация списков'], ['vpn', 'История агента VPN'],
  ['d-smartdns', 'Агент Smart DNS'],
  ['routes', 'Автоподбор доменов'], ['routes', 'Доменные списки'], ['routes', 'Источники'], ['vpn', 'IP-категории'], ['wan', 'Wi-Fi клиенты'],
  ['wifi', 'Сбор данных'], ['wifi', 'Ручное управление'], ['wifi', 'Домашний сегмент'], ['wifi', 'Окно анализа'], ['wifi', 'Слабый сигнал 5 ГГц'],
  ['utils', 'AdGuard Home'], ['d-agh', 'Имена устройств из Keenetic'], ['d-agh', 'Все устройства через AdGuard Home'], ['d-agh', 'Не давать обходить фильтрацию'], ['d-agh', 'Выводить AdGuard Home из DNS при сбое'], ['ads', 'Последняя проверка'], ['ads', 'Правила в AdGuard Home'], ['ads', 'Журнал запросов'], ['ads', 'На проверке'], ['ads', 'Категории блокировки'], ['ads', 'Не опубликовано'], ['ads', 'Мои правила'], ['ads', 'Источники'], ['ads', 'HTTPS-фильтр'], ['ads', 'Режим работы'],
  ['u-vward', 'Установка обновлений'], ['u-vward', 'Время установки'], ['u-vward', 'Интервал проверки'], ['u-vward', 'Канал'],
  ['settings', 'Адрес Панели'], ['settings', 'Тема'], ['u-vward', 'Версия'], ['d-diag', 'Задания по расписанию'], ['settings', 'Вход по учётной записи Keenetic'], ['settings', 'Разделы на панели']
];
function openSearch() {
  openSheet('', '<div class="search-box">' + ico('search') + '<input id="searchInput" placeholder="Раздел, параметр или компонент" aria-label="Поиск по VWARD" autocomplete="off"><button class="icon-btn" type="button" data-act="close" aria-label="Закрыть">' + ico('close') + '</button></div><div class="sheet-body" id="searchResults"></div>', 'search', 'searchBtn');
  const i = $('searchInput'); i.focus(); renderResults('');
}
function renderResults(q) {
  q = q.trim().toLowerCase();
  const out = [], pages = PAGES.filter(p => !q || p.title.toLowerCase().includes(q));
  const params = SEARCH_INDEX.filter(x => q && (x[1] + ' ' + page(x[0]).title).toLowerCase().includes(q));
  const comps = COMPONENTS.filter(c => q && compName(c.id).toLowerCase().includes(q));
  if (pages.length) out.push('<div class="result-group">Разделы</div>' + pages.map(p => '<button class="result" type="button" data-go="' + p.id + '">' + ico(p.icon) + '<span>' + esc(p.title) + '</span></button>').join(''));
  if (params.length) out.push('<div class="result-group">Параметры</div>' + params.map(x => '<button class="result" type="button" data-go="' + x[0] + '" data-key="' + esc(x[1]) + '">' + ico(page(x[0]).icon) + '<span>' + esc(x[1]) + '<small>' + esc(page(x[0]).title) + '</small></span></button>').join(''));
  if (comps.length) out.push('<div class="result-group">Компоненты</div>' + comps.map(c => '<button class="result" type="button" data-go="c-' + c.id + '">' + ico('platform') + '<span>' + esc(compName(c.id)) + '<small>Компоненты</small></span></button>').join(''));
  $('searchResults').innerHTML = out.join('') || empty('Ничего не найдено');
}
/* ---------- Всплывающие уведомления и история ----------
   A pop-up comes out under the bell (top right), stays a few seconds and is kept in the bell's
   history on the router (the last 200, «Прочитать все»; owner 2026-10-12). Nothing at the
   bottom of the screen; a wrong input is said under its field (fieldErr). */
// What only answers a click here and now is not kept in the history.
const NOTE_QUIET = /^(Данные обновлены|Журнал скопирован|Текст выделен|Карточки сброшены|Архив журналов скачивается|На панели помещается|Оставьте хотя бы|«Поделиться»|Поделиться не удалось|Вы вышли|Тема: )/;
const NOTE_ICON = { ok: 'check', err: 'alert', crit: 'alert', warn: 'alert', news: 'bell', info: 'bell' };
const noteSev = msg => /^(Ошибка|Не |Нет |Файл больше)/.test(msg) ? 'err' : 'ok';
// A short stable key of a warning: the same one is kept once, however many Panels are open.
const noteKey = n => { let h = 5381; const t = n.sev + '|' + n.title + '|' + (n.to || ''); for (let i = 0; i < t.length; i++) h = (h * 33 ^ t.charCodeAt(i)) >>> 0; return 'n' + h.toString(36); };
// One line and the time; goes by itself in 5 s, an error stays until closed (× or a swipe);
// three at most, the newest on top. A tap opens the page it is about.
function popup(n) {
  const box = $('toasts'), el = document.createElement('div'), stay = n.stay || n.sev === 'err' || n.sev === 'crit';
  el.className = 'toast ' + n.sev; el.setAttribute('role', stay ? 'alert' : 'status');
  el.innerHTML = '<span class="sev ' + n.sev + '">' + ico(n.icon || NOTE_ICON[n.sev] || 'bell') + '</span><span class="toast-text"' + (n.to ? ' role="button" tabindex="0" data-go="' + esc(n.to) + '"' : '') + ' title="' + esc(n.title + (n.text ? '. ' + n.text : '')) + '"><b>' + esc(n.title) + '</b>' + (n.text ? '<small>' + esc(n.text) + '</small>' : '') + '</span>' +
    (n.btn ? '<button class="btn small toast-btn" type="button">' + esc(n.btn[0]) + '</button>' : '') + '<time>' + new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) + '</time><button class="toast-x" type="button" aria-label="Закрыть">' + ico('close') + '</button>';
  box.prepend(el);
  while (box.children.length > 3) box.lastChild.remove();
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('in')));
  const gone = () => { if (el.classList.contains('out')) return; el.classList.remove('in'); el.classList.add('out'); el.style.transform = ''; setTimeout(() => el.remove(), 260); };
  if (!stay) setTimeout(gone, 5000);
  el.querySelector('.toast-x').addEventListener('click', e => { e.stopPropagation(); gone(); });
  if (n.btn) el.querySelector('.toast-btn').addEventListener('click', e => { e.stopPropagation(); n.btn[1](); });
  if (n.to) el.querySelector('.toast-text').addEventListener('click', e => { if (moved) { e.stopPropagation(); e.preventDefault(); return; } gone(); }, true);
  // A swipe left, right or up throws it away (owner 2026-10-17). Pointer events and
  // touch-action:none: with touch events Android's back gesture took the sideways swipe.
  let p0 = null, dx = 0, dy = 0, axis = '', moved = false;
  el.addEventListener('pointerdown', e => { if (e.button > 0 || e.target.closest('.toast-x')) return; p0 = [e.clientX, e.clientY]; dx = dy = 0; axis = ''; moved = false; el.style.transition = 'none'; });
  el.addEventListener('pointermove', e => {
    if (!p0) return;
    dx = e.clientX - p0[0]; dy = e.clientY - p0[1];
    if (!axis && Math.hypot(dx, dy) > 8) { axis = Math.abs(dx) >= Math.abs(dy) ? 'x' : 'y'; moved = true; try { el.setPointerCapture(e.pointerId); } catch (_) {} }
    if (!axis) return;
    const d = axis === 'x' ? dx : Math.min(0, dy);
    el.style.transform = axis === 'x' ? 'translateX(' + d + 'px)' : 'translateY(' + d + 'px)';
    el.style.opacity = String(Math.max(0.15, 1 - Math.abs(d) / (axis === 'x' ? 220 : 90)));
  });
  const end = () => {
    if (!p0) return;
    p0 = null; el.style.transition = '';
    if (axis === 'x' && Math.abs(dx) > 70) { el.classList.add('out'); el.style.transform = 'translateX(' + (dx > 0 ? 120 : -120) + '%)'; el.style.opacity = '0'; setTimeout(() => el.remove(), 260); }
    else if (axis === 'y' && dy < -30) { el.classList.add('out'); el.style.transform = 'translateY(-120%)'; el.style.opacity = '0'; setTimeout(() => el.remove(), 260); }
    else { el.style.transform = ''; el.style.opacity = ''; }
    setTimeout(() => { moved = false; }, 0);
  };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
}
// Kept on the router; the bell shows it at once, before the router answers.
function noteKeep(n, quiet) {
  const item = { id: 'p' + Date.now(), at: Math.floor(Date.now() / 1000), sev: n.sev, key: n.key || '', to: n.to || '', title: String(n.title).slice(0, 200), text: String(n.text || '').slice(0, 400) };
  const items = (S.notes && S.notes.items) || [];
  if (item.key && items.some(x => x.key === item.key && item.at - x.at < 21600)) return;
  S.notes = Object.assign({ ok: true, read_at: 0 }, S.notes || {}, { items: [item].concat(items).slice(0, 200) });
  apiPost('notes', { op: 'add', sev: item.sev, title: item.title, text: item.text, to: item.to, key: item.key }).catch(() => {});
  if (!quiet) renderNav();
}
// toast MSG [SEV] [ACT]: ACT names the action (a-OP-TARGET): its error is kept as ACT_CODE,
// and its later success takes the earlier errors out of the history. A message of a step in
// progress («Переключаем…») is shown, not kept (fix.31).
function toast(msg, sev, act) {
  const n = { sev: sev || noteSev(String(msg)), title: String(msg) };
  popup(n);
  if (act && n.sev === 'ok') noteResolve(act);
  if (NOTE_QUIET.test(n.title) || /…$/.test(n.title)) return;
  if (act && n.sev === 'err') n.key = (act + '_' + noteKey(n)).slice(0, 64);
  noteKeep(n);
}
const actKey = f => ('a-' + [f.op, f.action, f.target].filter(Boolean).join('-')).replace(/[^A-Za-z0-9-]/g, '-').slice(0, 48);
function noteResolve(act) {
  const items = (S.notes && S.notes.items) || [], keep = items.filter(x => !((x.sev === 'err' || x.sev === 'crit') && (x.key === act || String(x.key).indexOf(act + '_') === 0)));
  if (keep.length === items.length) return;
  S.notes = Object.assign({}, S.notes, { items: keep });
  apiPost('notes', { op: 'resolve', key: act }).catch(() => {});
  renderNav();
}
// A warning that appeared since the last look pops up once and goes into the history; one that
// went and came back pops up again. Only on the router's fresh answer, not on the browser's copy.
let notesSeen = store.get('vward-notes-seen', null);
function notesWatch(list) {
  if (!S.status || S.cached.status || S.errors.status) return;
  const keys = list.map(noteKey), seen = notesSeen, fresh = list.filter((n, i) => !(seen && seen.includes(keys[i])));
  if (seen && keys.length === seen.length && !fresh.length) return;
  notesSeen = keys; store.set('vward-notes-seen', keys);
  // The very first look (a new browser) only remembers: what is wrong is already in the bell.
  // The VPN agent writes its own switch-off to the history (own): the Panel only shows it.
  fresh.forEach(n => { if (seen) popup(n); if (!n.own) noteKeep(Object.assign({}, n, { key: noteKey(n) }), true); });
}
// The history's unread: newer than «Прочитать все». The bell counts them (a warning is written
// to the history when it appears, so it is counted too until read).
function notesUnread() {
  const nt = S.notes || {};
  return (nt.items || []).filter(x => x.at > (nt.read_at || 0));
}
// An input error stays under its field until the field is changed (owner 2026-10-12).
let FERR = null;
function fieldErr(form, msg) {
  FERR = { form: form.dataset.form || '', kind: form.dataset.kind || '', msg: msg };
  fieldErrShow(form);
  const i = form.querySelector('input:not([type=hidden]):not([type=radio]), textarea');
  if (i) i.focus();
}
function fieldErrShow(form) {
  if (!FERR || !form) return;
  let p = form.nextElementSibling;
  if (!p || !p.classList.contains('field-err')) { p = document.createElement('p'); p.className = 'field-err'; p.setAttribute('role', 'alert'); form.after(p); }
  p.textContent = FERR.msg;
  form.querySelectorAll('input:not([type=hidden]), textarea').forEach(i => i.setAttribute('aria-invalid', 'true'));
}
function fieldErrClear() {
  if (!FERR) return;
  FERR = null;
  document.querySelectorAll('.field-err').forEach(p => p.remove());
  document.querySelectorAll('[aria-invalid]').forEach(i => i.removeAttribute('aria-invalid'));
}
document.addEventListener('input', e => { if (FERR && e.target.closest && e.target.closest('form')) fieldErrClear(); });

/* ---------- Действия ---------- */
let SPEED_STARTING = false;
async function runAction(resultId, action, fields, okMsg) {
  actionResult = null; render();
  try {
    const x = await apiPost(action, fields);
    toast(x.ok ? okMsg : 'Не выполнено: ' + errText(x));
    return x;
  } catch (e) { toast('Ошибка: ' + e.message); return null; }
  finally { render(); }
}
const CONFIRMED = {
  'sd-drop': c => smartdnsServer('clear', '', c.id.slice(8)),
  'svrec-accept': c => svRecover(c.id.slice(13), 'accept'),
  'svrec-restore': c => svRecover(c.id.slice(14), 'restore'),
  'list-merge': c => cfgSet({ op: 'list', action: 'merge', target: c.name, value: c.what, confirm: 'LIST_MERGE' }, 'Списки объединены', ['lists']),
  'list-clear': c => cfgSet({ op: 'list', action: 'clear', target: c.name, confirm: 'LIST_CLEAR' }, 'Список очищен', ['lists', 'listd']),
  'lists-del': () => { const ns = [...LISTPICK]; LISTPICK.clear(); return listBulk({ op: 'list', action: 'delete', confirm: 'LIST_DELETE' }, ns, 'Удаление списков'); },
  'list-adopt': c => cfgSet({ op: 'list-adopt', target: c.name, value: '1', confirm: 'LIST_ADOPT' }, 'Список под управлением VWARD', ['lists']).then(x => { if (x && x.ok && c.then) return listModeSet(c.name, c.then); }),
  'list-empty-del': () => listEmptyDelete(),
  'list-del': c => cfgSet({ op: 'list', action: 'delete', target: c.name, confirm: 'LIST_DELETE' }, 'Список удалён', ['lists']).then(x => { if (x && x.ok && current === 'l-' + c.name) go('lists'); }),
  'cleanup': c => cfgSet({ op: 'cleanup', target: c.what }, 'Очищено', ['cleanup', 'status']),
  // «Очистить» in «Журналы» (owner 12.11.2026): the live journal(s) emptied on the router, archives kept.
  'log-clear': c => cfgSet({ op: 'journal', target: 'clear', value: c.what, confirm: 'LOG_CLEAR' }, c.what === 'all' ? 'Журналы очищены' : 'Журнал очищен', ['journal']).then(x => {
    if (!x || !x.ok) return;
    Object.keys(LOGGOOD).forEach(k => { if (c.what === 'all' || k === c.what || k === 'all') delete LOGGOOD[k]; });
    if (logShown[c.what]) loadLog(c.what, true);
  }),
  'reset': () => cfgSet({ op: 'reset', target: 'settings', confirm: 'RESET_SETTINGS' }, 'Настройки VWARD сброшены', ['status', 'config', 'backups']),
  'vward-off': () => vwardPower('off'),
  'tunnel-down': () => tunnelState('down', current.slice(2)),
  'site-block': c => siteDo('block', c.dom),
  'agh-official': () => extOp('agh-official', '', 'AGH_OFFICIAL'),
  'ext-upgrade': c => { const p = ((S.ext && S.ext.packages) || []).find(x => x.name === c.pkg); extOp('upgrade', c.pkg, p && p.critical ? 'EXT_UPGRADE_CRITICAL' : 'EXT_UPGRADE'); },
  'fw-channel': c => cfgSet({ op: 'firmware', target: 'channel', value: c.value, confirm: 'FIRMWARE_CHANNEL_TEST' }, 'Канал прошивки: ' + fwChannel(c.value), ['ext']),
  'route-reconcile': () => runLong('routes', 'control', { op: 'route-reconcile', confirm: 'ROUTE_RECONCILE' }, 'control-data', 'Маршруты сверены').then(() => load('route', true)).then(render),
  'policy-refresh': () => runLong('routes', 'control', { op: 'policy-refresh', confirm: 'POLICY_REFRESH' }, 'control-data', 'IP-категории обновлены').then(() => load('route', true)).then(render),
  'update-apply': () => updateOp('apply', 'APPLY_UPDATE'),
  'update-retry': () => updateOp('retry', 'RETRY_UPDATE'),
  'update-rollback': () => updateOp('rollback', 'ROLLBACK_UPDATE'),
  'update-recover': () => updateOp('recover', 'RECOVER_UPDATE'),
  'ads-publish': () => runAction('ads', 'ads-control', { op: 'enqueue', job: 'publish', confirm: 'ADS_PUBLISH' }, 'Публикация поставлена в очередь').then(() => load('ads', true)).then(render),
  'https-start': () => runAction('https', 'ads-https-control', { op: 'start', confirm: 'HTTPS_START' }, 'HTTPS-фильтр запущен').then(() => load('https', true)).then(render),
  'https-ca': () => runAction('https', 'ads-https-control', { op: 'ca-init', confirm: 'HTTPS_CA_INIT' }, 'Сертификат создан').then(() => load('https', true)).then(render),
  'wifi-deny': c => wifiHostSet({ op: 'access', mac: c.mac, value: 'deny', confirm: 'WIFI_ACCESS_DENY' }, 'Интернет для устройства запрещён'),
  'backup-restore': c => apiPost('backup-control', { op: 'restore', name: c.name, confirm: 'BACKUP_RESTORE' }).then(x => { toast(x.ok ? 'Настройки восстановлены' : 'Не восстановлено: ' + errText(x)); return Promise.all(['backups', 'config', 'security', 'status'].map(k => load(k, true))); }, e => toast('Ошибка: ' + e.message)).then(render),
  'agh-protection-off': () => aghSet({ setting: 'protection', value: '0', confirm: 'AGH_PROTECTION_OFF' }, 'Фильтрация AdGuard Home выключена'),
  'agh-filter-remove': c => aghSet({ setting: 'filter-remove', url: c.url, confirm: 'AGH_FILTER_REMOVE' }, 'Список удалён'),
  'agh-off': () => apiPost('agh-auth', { op: 'disconnect', confirm: 'AGH_DISCONNECT' }).then(x => { toast(x.ok ? 'AdGuard Home отключён' : 'Не отключено: ' + errText(x)); return load('ads', true); }).then(render, () => render()),
  'auth-off': () => apiPost('auth', { op: 'disable', confirm: 'CONSOLE_AUTH_DISABLE' }).then(x => { toast(x.ok ? 'Вход выключен' : 'Не выключено: ' + errText(x)); return Promise.all([load('auth', true), load('security', true)]); }).then(render, () => render()),
  'dnsg-bypass': () => dnsGuardSet('bypass', '1', 'Обход защиты закрыт'),
  'ads-autopub': () => adsSetting('AUTO_PUBLISH', '1').then(() => load('adspub', true)).then(render),
  'feed-dev': () => cfgSet({ op: 'update-feed', target: 'dev', confirm: 'UPDATE_FEED_DEV' }, 'Канал: Разработка'),
  'feed-main': () => cfgSet({ op: 'update-feed', target: 'main' }, 'Канал: Стабильная'),
  'comp-off': c => { const id = c.comp || current.slice(2); return cfgSet({ op: 'component', target: id, value: '0', confirm: 'COMPONENT_DISABLE' }, '«' + compName(id) + '» выключен', ['status']); },
  'comp-on': c => { const id = c.comp || current.slice(2); return cfgSet({ op: 'component', target: id, value: '1' }, '«' + compName(id) + '» включён', ['status']); },
  'tunnel-move': () => { const name = current.slice(2); return apiPost('tunnel-conf', { op: 'move', name: name }).then(x => { toast(x.ok ? 'Списки и подсети перенесены на ' + tunLabel(prof().tunnel_interface) : 'Не перенесено: ' + errText(x), x.ok ? 'ok' : 'err', 'a-tunnel-move'); return Promise.all([load('status', true), load('lists', true)]).then(render); }, e => { toast('Ошибка: ' + e.message); render(); }); },
  'tunnel-delete': c => { const name = current.slice(2); return apiPost('tunnel-conf', { op: 'delete', name: name, target: c.to, confirm: 'TUNNEL_DELETE' }).then(x => { toast(x.ok ? tunLabel(name) + ' удалён' : 'Не удалено: ' + errText(x)); return Promise.all([load('status', true), load('lists', true)]).then(() => { if (x.ok) go('vpn', null, 'replace'); else render(); }); }, e => { toast('Ошибка: ' + e.message); render(); }); },
  'tunnel-use': c => tunUseJob(current.slice(2), c.moveAll === false ? 'own' : 'all'),
  'wg-off': () => cfgSet({ op: 'wan-guard', value: '0', confirm: 'WAN_GUARD_DISABLE' }, 'Восстановление интернета выключено'),
  'wan-renew': () => wanOp('wan-renew', 'WAN_RENEW', 'Адрес запрошен заново'),
  'wan-bounce': () => wanOp('wan-bounce', 'WAN_BOUNCE', 'Интернет переподключён'),
  'tg-off': () => cfgSet({ op: 'tunnel-guard', value: '0', confirm: 'TUNNEL_GUARD_DISABLE' }, 'Агент VPN выключен', ['status']),
  'sd-off': () => cfgSet({ op: 'smartdns-feature', value: '0', confirm: 'SMARTDNS_OFF' }, 'Smart DNS выключен, строки VWARD сняты', ['ai', 'lists']),
  'wifi-ctl-on': () => cfgSet({ op: 'wifi', target: 'CONTROL_ENABLED', value: '1', confirm: 'WIFI_CONTROL_ENABLE' }, 'Ручное управление включено', ['wifi']),
  'wifi-bind': c => { const op = c.op, mac = current.slice(2), token = { 'bind-2g': 'WIFI_BIND_2G', 'bind-5g': 'WIFI_BIND_5G', auto: 'WIFI_BAND_AUTO' }[op]; return runAction('wifi', 'wifi-control', { op: op, mac: mac, confirm: token }, 'Диапазон изменён').then(() => load('wifi', true)).then(render); }
};
async function cfgSet(fields, okMsg, reload) {
  try {
    const x = await apiPost('config', fields);
    toast(x.ok ? (x.result === 'unchanged' ? 'Уже сохранено' : okMsg) : 'Не сохранено: ' + errText(x), null, actKey(fields));
    return x;
  } catch (e) { toast('Ошибка: ' + e.message); return null; }
  finally { await Promise.all(['config'].concat(reload || []).map(k => load(k, true))); render(); }
}
const WAN_ERRORS = {
  COOLDOWN: 'между ручными действиями нужна минута', BUSY: 'идёт автоматическое восстановление связи, повторите через минуту',
  UPDATER_BUSY: 'идёт обновление, повторите позже', RENEW_FAILED: 'роутер не принял запрос адреса', DOWN_FAILED: 'роутер не отключил интерфейс, связь не менялась',
  UP_FAILED: 'интерфейс не включился - VWARD продолжит включать его каждую минуту', INCOMPLETE_BOUNCE: 'не удалось завершить прошлое переподключение',
  PROFILE_UNAVAILABLE: 'интерфейс интернета не определён', INTERRUPTED: 'действие прервано, интерфейс включён обратно'
};
async function wanOp(op, token, okMsg) {
  runningId = op; render();
  let text;
  try {
    const x = await apiPost('control', { op: op, confirm: token }), code = ((x.output || '').match(/ERROR=([A-Z_]+)/) || [])[1];
    text = x.ok ? okMsg : 'Не выполнено: ' + (WAN_ERRORS[code] || errText(x));
  } catch (e) { text = 'Ошибка: ' + e.message; }
  runningId = null; toast(text);
  await load('status', true); render();
}
/* «Автоматически» и «По расписанию» различаются окном установки (apply_window). */
let updModeShown = null;
async function updateMode(mode) {
  const p = plat(), on = mode === 'manual' ? '0' : '1';
  // Shown at once; saved in the background and put back if the router refuses.
  updModeShown = mode; render();
  if (mode !== 'manual') {
    const x = await apiPost('config', { op: 'update', target: 'apply_window', value: mode === 'auto' ? 'any' : 'window' }).catch(e => ({ ok: false, error: e.message }));
    if (!x.ok) { toast('Не сохранено: ' + errText(x)); updModeShown = null; await load('config', true); render(); return; }
  }
  await runAction('updates', 'settings', { auto_apply: on, auto_critical: isTrue(p.auto_critical) ? '1' : '0', auto_important: isTrue(p.auto_important) ? '1' : '0', auto_routine: isTrue(p.auto_routine) ? '1' : '0' }, 'Настройки обновлений сохранены');
  await Promise.all([load('status', true), load('config', true)]); updModeShown = null; render();
}
/* Long operations run in the background on the router: they outlast the 10-second request.
   The Panel polls dataAction and shows the output until the run finishes. */
/* ---------- Окно установки обновления ---------- */
// Like Keenetic: a window over the page while an update installs or rolls back,
// by the button or on schedule; it follows the updater's phases.
const UPD_STEPS = [['CHECKING', 'Подготовка к установке', 5], ['VERIFIED', 'Проверка подписи', 15], ['BACKING_UP', 'Резервная копия', 30], ['INSTALLING', 'Установка файлов', 55], ['VERIFYING', 'Проверка работы', 80], ['COMMIT_PREPARED', 'Завершение', 92], ['COMMITTED', 'Готово', 100]];
const UPD_BUSY = ['BACKING_UP', 'INSTALLING', 'VERIFYING', 'COMMIT_PREPARED', 'ROLLING_BACK'];
let updOverlay = null;
// A full-screen window like Keenetic's own: a ring with the percentage and the stage under it.
// Each stage has its share; inside a stage the ring creeps on so it never looks frozen.
function updOverlayShow(o) {
  updOverlay = Object.assign(updOverlay || { op: 'apply', phase: 'CHECKING', from: plat().version || '', pct: 0 }, o);
  let el = $('updOverlay');
  if (!el) { el = document.createElement('div'); el.id = 'updOverlay'; document.body.appendChild(el); }
  const u = updOverlay, rb = u.op === 'rollback' || u.phase === 'ROLLING_BACK';
  const i = Math.max(0, UPD_STEPS.findIndex(x => x[0] === u.phase)), step = UPD_STEPS[i], next = UPD_STEPS[i + 1];
  const base = rb ? 50 : step[2], cap = rb ? 95 : next ? next[2] - 3 : 100;
  u.pct = u.done ? 100 : Math.min(cap, Math.max(u.pct || 0, base) + (u.pct >= base ? 1 : 0));
  const head = u.done ? (u.ok ? (rb ? 'Откат выполнен' : 'Обновление установлено') : 'Обновление не установлено') : (rb ? 'Откат обновления VWARD' : 'Обновление VWARD');
  const stage = u.done ? (u.ok ? 'VWARD ' + verHuman(u.version) + ' работает' : 'Прежняя версия работает') : rb ? 'Возврат прежней версии' : step[1];
  const text = u.done ? (u.ok ? 'Обновите страницу, чтобы открыть новую версию.' : (u.error || 'Установщик вернул прежнюю версию, всё работает как раньше. Подробности - в «Журналах» → «Обновления».'))
    : 'Не закрывайте страницу, пока не завершится обновление. Роутер и интернет продолжают работать.';
  const state = u.done ? (u.ok ? ' ok' : ' crit') : '';
  el.innerHTML = '<div class="upd-page' + state + '" role="dialog" aria-live="polite" aria-label="' + esc(head) + '">' +
    '<h2>' + esc(head) + '</h2>' + (u.version && !u.done ? '<p class="upd-ver">' + esc((u.from ? verHuman(u.from) + ' → ' : '') + verHuman(u.version)) + '</p>' : '') +
    '<p class="upd-text">' + esc(text) + '</p>' + ringHtml(u.pct, u.done, u.ok) +
    '<p class="upd-stage">' + esc(stage) + '</p>' +
    (u.done ? '<div class="panel-actions">' + (u.ok ? '<button class="btn primary" type="button" data-act="upd-reload">Обновить страницу</button>' : '<button class="btn" type="button" data-act="upd-close">Закрыть</button>') + '</div>' : '') + '</div>';
}
// The ring with the percentage (a check or a cross when done), for the update and tunnel windows.
function ringHtml(pct, done, ok) {
  const R = 76, C = 2 * Math.PI * R, a = (pct / 100) * 2 * Math.PI - Math.PI / 2;
  return '<div class="upd-ring"><svg viewBox="0 0 180 180" aria-hidden="true"><circle class="upd-track" cx="90" cy="90" r="' + R + '"/>' +
    '<circle class="upd-arc" cx="90" cy="90" r="' + R + '" stroke-dasharray="' + C.toFixed(1) + '" stroke-dashoffset="' + (C * (1 - pct / 100)).toFixed(1) + '" transform="rotate(-90 90 90)"/>' +
    (done ? '' : '<circle class="upd-dot" cx="' + (90 + R * Math.cos(a)).toFixed(1) + '" cy="' + (90 + R * Math.sin(a)).toFixed(1) + '" r="11"/>') + '</svg>' +
    '<span class="upd-pct">' + (done ? ico(ok ? 'check' : 'alert') : pct + '%') + '</span></div>';
}
function updOverlayClose() { updOverlay = null; const el = $('updOverlay'); if (el) el.remove(); }
// Updater exit codes that are answers, not failures.
const UPDATE_RC = { 10: 'Новых обновлений нет', 11: 'Обновление отложено: версия в карантине', 20: 'Обновление найдено, установится в назначенное время',
  30: 'Настройки обновлений не прочитаны. Файлы VWARD не менялись.', 31: 'Проверка обновления не прошла. Файлы VWARD не менялись: нажмите «Проверить» и повторите.',
  32: 'Обновление не подходит к этой версии. Файлы VWARD не менялись.', 33: 'Не хватает места или условий для установки. Файлы VWARD не менялись.',
  34: 'Нет связи с сервером обновлений' };
const UPDATE_RC_OK = { 10: 1, 20: 1 };
// On «Стабильная» the feed may still hold a build older than the one installed: the
// sequence/anti-rollback check refuses it (32), which there means «nothing newer yet».
const updRc = rc => rc === 32 && (cfg().update || {}).feed === 'main' ? 'На канале «Стабильная» нет выпуска новее установленной версии. Файлы VWARD не менялись.' : UPDATE_RC[rc];
// The id of the block whose long action is running: its button shows the progress.
let runningId = null;
async function runLong(resultId, action, fields, dataAction, okMsg) {
  const show = text => { actionResult = { id: resultId, text: text }; render(); };
  runningId = resultId; actionResult = null;
  try { return await runLongBody(resultId, action, fields, dataAction, okMsg, show); } finally { runningId = null; render(); }
}
async function runLongBody(resultId, action, fields, dataAction, okMsg, show) {
  const installing = dataAction === 'update-data' && fields && fields.op !== 'check';
  if (installing) updOverlayShow({ manual: true, op: fields.op, phase: 'CHECKING', version: (S.update && S.update.pending && S.update.pending.version) || '', done: false });
  render();
  let x;
  try { x = await apiPost(action, fields); }
  catch (e) { if (installing) updOverlayClose(); toast('Ошибка: ' + e.message); return; }
  if (!x.ok) { if (installing) updOverlayClose(); toast('Не выполнено: ' + errText(x)); return; }
  let run = {};
  const deadline = Date.now() + 15 * 60 * 1000;
  while (Date.now() < deadline) {
    await new Promise(r => setTimeout(r, 3000));
    let u;
    try { u = await apiGet(dataAction); } catch (e) { continue; }
    run = u.run || {};
    if (installing && u.phase) updOverlayShow({ phase: u.phase });
    if (run.finished) break;
  }
  const done = !run.finished ? 'Ещё выполняется, проверьте позже' : run.rc === 0 ? okMsg : dataAction === 'update-data' && updRc(run.rc) ? updRc(run.rc) : 'Не выполнено' + (run.rc != null ? ' (код ' + run.rc + ')' : '') + ' - подробности в «Журналах»';
  const answered = run.finished && (run.rc === 0 || (dataAction === 'update-data' && UPDATE_RC_OK[run.rc]));
  if (installing) {
    if (run.finished && run.rc === 0) { await load('status', true); updOverlayShow({ done: true, ok: true, version: (updOverlay && updOverlay.version) || plat().version }); return run; }
    if (run.finished && run.rc === 20) updOverlayClose();
    else updOverlayShow({ done: true, ok: false, error: run.finished ? (UPDATE_RC[run.rc] || '') : 'Установка ещё идёт. Проверьте раздел «Обновления» через минуту.' });
  }
  // An empty okMsg: the caller reports the outcome itself.
  if (okMsg || !answered) toast(done);
  // The outcome is a toast only: no leftover line under the buttons.
  actionResult = null;
  render();
  return run;
}
const UPDATE_OK = { check: 'Проверка завершена', apply: 'Обновление установлено', retry: 'Обновление установлено', rollback: 'Откат выполнен', recover: 'Обновление восстановлено' };
function updateOp(op, token) {
  return runLong('updates', 'update-control', token ? { op: op, confirm: token } : { op: op }, 'update-data', op === 'check' ? '' : UPDATE_OK[op] || 'Готово')
    .then(run => Promise.all([load('update', true), load('status', true)]).then(() => {
      // After a check that finished, say what it found. A check that failed or never started
      // has already said so: no «Новых обновлений нет» from the last answer (Viva 2026-10-13).
      if (op === 'check' && run && run.finished && (run.rc === 0 || UPDATE_RC_OK[run.rc])) { const pd = S.update && S.update.pending; toast(pd && pd.present ? 'Найдено обновление ' + (pd.version || '') : 'Новых обновлений нет'); }
      render();
    }));
}
// DNS of every device through AdGuard Home (vward-ads-privacy-dns-guard.sh).
// aghDown ADS AGH: AdGuard Home does not answer (the DNS guard's check, or the Panel's own request).
const aghDown = (a, g) => ((a && a.dns_guard) || {}).agh_up === '0' || !!(g && g.ok === false && g.error === 'adguard_unavailable');
// Nothing can be switched on while AdGuard Home's own way out is not encrypted.
function dnsGuardPanel(a) {
  if (!a.agh_connected) return '';
  const g = a.dns_guard || {}, enc = g.upstream === 'encrypted', on = g.enforce === '1', by = g.bypass === '1';
  const ex = (g.exclude || '').split(',').filter(Boolean).length;
  const onHint = !on ? 'телефоны и телевизоры не смогут спросить DNS в обход' : g.agh_up === '0' ? 'AdGuard Home не отвечает - заворот временно снят' :
    num(g.redirected) ? fmtInt(g.redirected) + ' ' + plural(num(g.redirected), 'запрос завёрнут', 'запроса завёрнуто', 'запросов завёрнуто') : 'все устройства спрашивают AdGuard Home';
  const byHint = !by ? 'закрывает зашифрованный DNS в обход (DoT, DoH)' : num(g.refused) ? fmtInt(g.refused) + ' ' + plural(num(g.refused), 'попытка обхода закрыта', 'попытки обхода закрыто', 'попыток обхода закрыто') : 'обходов не было';
  return panel('Фильтрация', (on && g.agh_up === '0' ? '<p class="field-warn">AdGuard Home не отвечает: заворот временно снят, устройства спрашивают DNS провайдера. VWARD вернёт его сам.</p>' : '') + '<dl class="kv">' +
      ctrlRow('Все устройства через AdGuard Home', sw('data-dnsg="enforce"', on, 'Все устройства через AdGuard Home', !S.ads || (!enc && !on)), onHint) +
      ctrlRow('Не давать обходить фильтрацию', sw('data-dnsg="bypass"', by, 'Не давать обходить фильтрацию', !S.ads || (!enc && !by)), byHint) +
      ctrlRow('Выводить AdGuard Home из DNS при сбое', sw('data-dnsg="chain"', g.chain !== '0', 'Выводить AdGuard Home из DNS при сбое', !S.ads),
        g.chain === '0' ? 'выключено: если AdGuard Home не отвечает, дом остаётся без DNS' : 'если он не отвечает, интернет идёт через DNS провайдера, потом он возвращается сам') + '</dl>' +
      confirmBox('dnsg-bypass', 'Закрыть обход? Телефоны Android с «Частным DNS» в режиме «Имя хоста» останутся без интернета, пока этот режим не выключить. В режиме «Автоматически» всё продолжит работать.', 'Закрыть обход') +
      (enc || g.upstream == null ? '' : '<p class="field-warn">' + ico('alert') + 'Выход AdGuard Home в интернет не зашифрован: провайдер видит DNS-запросы. Сначала в AdGuard Home → «Настройки DNS» → «Upstream DNS-серверы» поставьте зашифрованные адреса (https://...), затем включайте защиту.</p>') +
      kv([['Исключения', ex ? fmtInt(ex) + ' ' + plural(ex, 'устройство', 'устройства', 'устройств') : 'нет', '', 'd-dnsex']]),
    { desc: 'Реклама и трекеры блокируются на всех устройствах.' });
}
async function dnsGuardSet(setting, value, okMsg) {
  let x;
  try { x = await apiPost('ads-control', { op: 'dns-guard', setting: setting, value: value }); } catch (e) { x = { ok: false, error: e.message }; }
  const err = /ERROR=([a-z_]+)/.exec(x.result || '');
  toast(x.ok ? okMsg : 'Не выполнено: ' + (err ? errText({ error: err[1] }) : errText(x)));
  await load('ads', true); render();
}
// Device names from Keenetic in AdGuard Home (vward-ads-privacy-clients.sh).
function aghClientsRows(a) {
  if (!a.agh_connected) return '';
  const c = a.clients || {}, on = c.enabled !== '0', busy = runningId === 'agh-clients', n = num(c.devices) || 0;
  const hints = {
    ok: fmtInt(n) + ' ' + plural(n, 'устройство', 'устройства', 'устройств') + (c.changed_ts ? ' · изменено ' + fmtStamp(c.changed_ts) : ''),
    partial: 'часть имён не записалась, повтор через минуту',
    old_script: '',
    agh_unavailable: 'AdGuard Home не ответил, повтор через минуту',
    router_unavailable: 'Keenetic не ответил, повтор через минуту'
  }, hint = !on ? 'выключено' : c.result in hints ? hints[c.result] : 'имена появятся в течение минуты';
  return '<dl class="kv">' + ctrlRow('Имена устройств из Keenetic', sw('data-ads-clients', on, 'Имена устройств из Keenetic', !S.ads), hint) + '</dl>' +
    (on && c.result === 'old_script' ? '<p class="field-warn">' + ico('alert') + 'Имена устройств сейчас записывает старая программа, которая перезапускает AdGuard Home. VWARD отключит её сам при подключении к AdGuard Home и продолжит без перезапусков.</p>' : '') +
    (on && c.result !== 'old_script' ? '<div class="panel-actions">' + btn('agh-clients', 'refresh', busy ? 'Обновляем…' : 'Обновить имена', '', busy ? ' disabled' : '') + '</div>' : '');
}
// Routed domains through Keenetic's DNS (vward-ads-privacy-route-dns.sh), so the
// VPN routes learn every address a device gets for them.
function routeDnsRows(a) {
  if (!a.agh_connected) return '';
  const r = a.route_dns || {}, on = r.enabled === '1', n = num(r.domains) || 0, sk = num(r.skipped) || 0;
  const hints = {
    ok: fmtInt(n) + ' ' + plural(n, 'домен', 'домена', 'доменов') + ' · маршруты сразу знают адреса устройств' + (sk ? ' · ' + fmtInt(sk) + ' через Smart DNS' : ''),
    not_via_agh: 'не нужно: DNS Keenetic не спрашивает AdGuard Home',
    no_domains: 'в маршрутах Keenetic нет доменов',
    client_conflict: 'адрес роутера занят другим клиентом AdGuard Home',
    chain_failed: 'DNS Keenetic не ответил, отменено; VWARD повторит сам',
    agh_unavailable: 'AdGuard Home не ответил, VWARD повторит сам',
    router_unavailable: 'Keenetic не ответил, VWARD повторит сам'
  }, hint = r.result === 'dns_lost' ? 'выключено само: DNS Keenetic перестал отвечать' : !on ? 'экспериментально, выключено' : r.result in hints ? hints[r.result] : 'включается…';
  return '<dl class="kv">' + ctrlRow('Домены маршрутов через DNS Keenetic', sw('data-route-dns', on, 'Домены маршрутов через DNS Keenetic', !S.ads), hint) + '</dl>';
}
async function routeDnsOp(value) {
  let x;
  try { x = await apiPost('ads-control', { op: 'route-dns', value: value }); } catch (e) { x = { ok: false, error: e.message }; }
  const err = /ERROR=([a-z_]+)/.exec(x.result || '');
  toast(x.ok ? (value === 'on' ? 'Маршруты по доменам видят адреса устройств' : 'Домены маршрутов снова идут напрямую') : 'Не выполнено: ' + (err ? errText({ error: err[1] }) : errText(x)));
  await load('ads', true); render();
}
async function aghClientsOp(value) {
  if (value === 'sync') { runningId = 'agh-clients'; render(); }
  let x;
  try { x = await apiPost('ads-control', { op: 'clients', value: value }); } catch (e) { x = { ok: false, error: e.message }; }
  if (runningId === 'agh-clients') runningId = '';
  toast(x.ok ? ({ on: 'Имена устройств включены', off: 'Имена устройств выключены', sync: 'Имена обновлены' })[value] : 'Не выполнено: ' + errText(x));
  await load('ads', true); render();
}
async function adsControl(fields, okMsg, resultId) {
  const x = await runAction(resultId || 'ads', 'ads-control', fields, okMsg);
  await load('ads', true); render(); return x;
}
async function adsSetting(key, value) {
  const fields = {}; fields[key] = value;
  if (key === 'AUTO_PUBLISH' && value === '1') fields.confirm = 'ADS_AUTO_PUBLISH';
  // Shown at once (the interval row follows the mode); the router's answer confirms or puts it back.
  if (S.ads && S.ads.settings) { S.ads.settings[key] = value; render(); }
  const x = await runAction('ads', 'ads-settings', fields, 'Сохранено');
  await load('ads', true); render(); return x;
}
function download(name, text) {
  const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
const today = () => new Date().toISOString().slice(0, 10);
function copyText(text) {
  const fallback = () => {
    const box = $('logBox'); if (!box) return;
    const r = document.createRange(); r.selectNodeContents(box); const s = getSelection(); s.removeAllRanges(); s.addRange(r);
    let ok = false; try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    toast(ok ? 'Журнал скопирован' : 'Текст выделен - скопируйте его вручную');
  };
  if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(() => toast('Журнал скопирован'), fallback);
  else fallback();
}

document.addEventListener('click', e => {
  const t = e.target.closest('[data-vserver],[data-go],[data-act],[data-tab],[data-card-toggle],[data-log],[data-move],[data-card-move],[data-view],[data-ads-remove],[data-wifi-bind],[data-agent-mode],[data-ai-via],[data-theme-set],[data-seg],[data-cfg-op],[data-my-pin],[data-my-rm],[data-ads-rule],[data-qfilter],[data-ads-srcdel],[data-agh-filter-rm],[data-backup-restore],[data-files-root],[data-files-dir],[data-files-open],[data-files-up]');
  if (!t || t.disabled) return;
  // A switch inside a row that opens a page: it switches, the page stays.
  if (t.dataset.go && e.target.closest('.switch')) return;
  if (t.dataset.cardToggle) { const id = t.dataset.cardToggle; hiddenCards = hiddenCards.includes(id) ? hiddenCards.filter(x => x !== id) : hiddenCards.concat(id); store.set('vward-card-hidden', hiddenCards); render(); return; }
  if (t.dataset.cardMove) { const [id, dir] = t.dataset.cardMove.split(':'), i = cardOrder.indexOf(id), j = i + (dir === 'up' ? -1 : 1); if (j >= 0 && j < cardOrder.length) { [cardOrder[i], cardOrder[j]] = [cardOrder[j], cardOrder[i]]; store.set('vward-card-order', cardOrder); render(); } return; }
  if (t.dataset.move) { const [id, dir] = t.dataset.move.split(':'), i = tabIds.indexOf(id), j = i + (dir === 'up' ? -1 : 1); if (j >= 0 && j < tabIds.length) { [tabIds[i], tabIds[j]] = [tabIds[j], tabIds[i]]; store.set('vward-tabs', tabIds); render(); } return; }
  if (t.dataset.view) { cardView = t.dataset.view; store.set('vward-card-view', cardView); render(); return; }
  if (t.dataset.qfilter && t.dataset.go) { ADSV.filter = t.dataset.qfilter; S.qlog = null; }
  if (t.dataset.vserver) { vlessSelect(t.dataset.name, t.dataset.vserver); return; }
  if (t.dataset.go) { if (t.closest('.preview')) return; go(t.dataset.go, t.dataset.key); return; }
  // Another source: shown at once only when the owner already asked for a journal on this visit.
  if (t.dataset.log) { const was = Object.keys(logShown).length; logTab = t.dataset.log; if (was) { logShown[logTab] = logN; loadLog(logTab, true); } render(); return; }
  if (t.dataset.adsRemove) { adsControl({ op: 'remove-override', domain: t.dataset.adsRemove, scope: t.dataset.scope || 'exact' }, 'Правило удалено', 'ads-rule'); return; }
  if (t.dataset.qfilter && !t.dataset.go) { ADSV.filter = t.dataset.qfilter; S.qlog = null; render(); load('qlog', true).then(render); return; }
  if (t.dataset.adsRule) { const d = t.dataset.domain; t.disabled = true; adsControl({ op: t.dataset.adsRule, domain: d, scope: 'exact' }, (t.dataset.adsRule === 'allow' ? d + ' разрешён' : d + ' заблокирован'), 'ads-rule').then(adsViews); return; }
  if (t.dataset.adsSrcdel) { t.disabled = true; adsControl({ op: 'source-delete', source: t.dataset.adsSrcdel }, 'Источник удалён', 'ads-src'); return; }
  if (t.dataset.filesRoot) { filesGo(t.dataset.filesRoot, ''); return; }
  if (t.dataset.filesDir) { filesGo(FILES.root, filePath(t.dataset.filesDir)); return; }
  if (t.dataset.filesOpen) { fileOpen(t.dataset.filesOpen); return; }
  if (t.dataset.filesUp) { if (FILES.path) filesGo(FILES.root, FILES.path.split('/').slice(0, -1).join('/')); else filesGo('', ''); return; }
  if (t.dataset.backupRestore) { confirm = { id: 'backup-restore', name: t.dataset.backupRestore }; render(); return; }
  if (t.dataset.aghFilterRm) { confirm = { id: 'agh-filter-remove', url: t.dataset.aghFilterRm }; render(); return; }
  if (t.dataset.listDom) {
    const v = t.dataset.dom, how = t.dataset.listDom, target = current.slice(2); t.disabled = true;
    // The cross removes at once; «Отменить» in the notification brings it back for a few seconds (owner 02.11).
    apiPost('config', { op: 'list-domain', action: how, target: target, value: v }).then(x => {
      if (!x.ok) { toast('Не сохранено: ' + errText(x)); return; }
      popup({ sev: 'ok', title: how === 'remove' ? v + ' убран из списка' : 'Исключение ' + v + ' убрано',
        btn: ['Отменить', () => cfgSet({ op: 'list-domain', action: how === 'remove' ? 'add' : 'exclude', target: target, value: v }, v + ' возвращён', ['listd', 'lists'])] });
    }, e => toast('Ошибка: ' + e.message)).then(() => Promise.all(['config', 'listd', 'lists'].map(k => load(k, true)))).then(render);
    return;
  }
  if (t.dataset.cfgOp === 'tsubnet') { t.disabled = true; tunnelSubnet(current.slice(current.startsWith('tn-') ? 3 : 2), 'remove', t.dataset.cfgTarget); return; }
  if (t.dataset.myPin) { const d = t.dataset.myPin, on = t.getAttribute('aria-pressed') !== 'true'; t.disabled = true; cfgSet({ op: 'force-vpn', action: on ? 'add' : 'remove', target: d }, on ? d + ' всегда идёт через VPN' : d + ': снято «всегда через VPN»', ['route']); return; }
  if (t.dataset.myRm) { t.disabled = true; myRemove(t.dataset.myRm); return; }
  if (t.dataset.cfgOp) { const d = t.dataset.cfgTarget, msg = { 'route-domain': d + ' убран из VPN', 'force-vpn': t.dataset.cfgAction === 'add' ? d + ' всегда идёт через VPN' : d + ' убран из списка', adaptive: t.dataset.cfgAction === 'pin' ? d + ' закреплён в моих доменах' : d + ' идёт напрямую' }[t.dataset.cfgOp]; t.disabled = true; cfgSet({ op: t.dataset.cfgOp, action: t.dataset.cfgAction, target: d }, msg, ['route']); return; }
  if (t.dataset.agentMode) {
    if (t.getAttribute('aria-checked') === 'true') return;
    const m = t.dataset.mode, ag = t.dataset.agentMode;
    cfgSet({ op: 'agents-mode', target: ag, value: m }, (ag === 'all' ? 'Все агенты' : agentName(ag)) + ': ' + (m === 'watch' ? 'песочница' : 'вкл'));
    return;
  }
  if (t.dataset.seg) { if (t.getAttribute('aria-checked') !== 'true') segPick(t.dataset.seg, t.dataset.v); return; }
  if (t.dataset.aiVia) {
    if (t.getAttribute('aria-checked') === 'true' || SVC.busy) return;
    const id = t.dataset.ai, v = t.dataset.aiVia, name = id === 'all' ? 'Все ИИ-сервисы' : ((((S.ai || {}).services || []).find(s => s.id === id) || {}).title || id);
    aiJob(id, v === 'vpn' ? 'auto' : v, name + ': ' + AI_VIA.find(o => o[0] === v)[1]);
    return;
  }
  if (t.dataset.themeSet) { setTheme(t.dataset.themeSet); render(); return; }
  if (t.dataset.wifiBind) { if (t.getAttribute('aria-checked') === 'true') return; confirm = { id: 'wifi-bind', op: t.dataset.wifiBind }; render(); return; }
  if (t.dataset.tab) {
    if (t.closest('.preview')) return;
    if (t.dataset.tab === 'more') { const cur = navId(current); openSheet('Ещё', '<div class="sheet-body">' + PAGES.filter(p => !tabIds.includes(p.id)).map(p => '<button class="menu-item" type="button" data-go="' + p.id + '"' + (p.id === cur ? ' aria-current="page"' : '') + '>' + ico(p.icon) + '<span>' + esc(p.title) + '</span>' + ico('chevron', 'chev') + '</button>').join('') + '</div>'); }
    else go(t.dataset.tab);
    return;
  }
  const a = t.dataset.act;
  if (a === 'close') closeLayer();
  else if (a === 'notes-read') {
    // Read at once here; the router keeps it for the other devices.
    S.notes = Object.assign({}, S.notes || {}, { read_at: Math.floor(Date.now() / 1000) }); renderNav(); openNotes();
    apiPost('notes', { op: 'read' }).then(x => { if (x && x.ok) { S.notes = x; cacheWrite('notes'); renderNav(); } }, () => {});
  }
  else if (a === 'reload') { const b = busyStart(current); render(); Promise.all(DATA_FOR(current).map(k => load(k, true))).then(() => { busyEnd(b); render(); }); }
  else if (a === 'edit') { editing = !editing; render(); }
  else if (a === 'tc-mode') {
    const f = t.closest('form'), m = t.dataset.m;
    f.querySelector('.tc-file').hidden = m !== 'file'; f.querySelector('.tc-manual').hidden = m !== 'manual';
    f.querySelectorAll('[data-act="tc-mode"]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.m === m)));
    f.dataset.checked = ''; $('tcPreview').innerHTML = ''; f.querySelector('[type=submit]').hidden = false; f.querySelector('[type=submit]').textContent = 'Проверить';
  }
  else if (a === 'svc-cat') { SVC.cat = SVC.cat === t.dataset.cat ? '' : t.dataset.cat; render(); }
  else if (a === 'qfilters') { ADSV.filtersOpen = !(ADSV.filtersOpen || ADSV.filter !== 'all'); if (!ADSV.filtersOpen && ADSV.filter !== 'all') { ADSV.filter = 'all'; S.qlog = null; load('qlog', true).then(render); } render(); }
  else if (a === 'cards-reset') { cardOrder = CARD_IDS.slice(); hiddenCards = []; cardView = 'grid'; ['vward-card-order', 'vward-card-hidden', 'vward-card-view'].forEach(k => store.del(k)); render(); toast('Карточки сброшены'); }
  else if (a === 'ask') { confirm = { id: t.dataset.confirm, pkg: t.dataset.pkg, what: t.dataset.what, level: t.dataset.level, name: t.dataset.name }; render(); }
  else if (a === 'view-reset') { ['vward-tabs', 'vward-cards', 'vward-card-view', 'vward-theme', 'vward.vless.view'].forEach(k => { try { localStorage.removeItem(k); } catch (e) { /* only this visit */ } }); toast('Вид Панели как после установки: перезагрузите страницу'); }
  else if (a === 'ext-check') extOp('check');
  else if (a === 'all-check') extOp('check').then(() => updateOp('check'));
  else if (a === 'confirm-no') { confirm = null; render(); }
  else if (a === 'vward-on') { t.disabled = true; vwardPower('on'); }
  else if (a === 'confirm-yes') { const c = confirm; confirm = null; const id = c && /^list-merge-/.test(c.id) ? 'list-merge' : c && /^sd-drop:/.test(c.id) ? 'sd-drop' : c && /^svrec-(accept|restore):/.test(c.id) ? c.id.split(':')[0] : c && c.id; if (c && CONFIRMED[id]) CONFIRMED[id](c); else render(); }
  else if (a === 'ads-urule') { t.disabled = true; adsUserRule(t.dataset.op, t.dataset.kind, t.dataset.dom); }
  else if (a === 'ads-chain-block') { t.disabled = true; adsChainBlock(t.dataset.doms.split(' ').filter(d => DOMAIN.test(d))); }
  else if (a === 'site-fix') siteFix(t.dataset.dom);
  else if (a === 'ads-deep') { go('d-adprobe'); adsProbe(t.dataset.dom); }
  else if (a === 'ad-open') { ADV.open = ADV.open === t.dataset.dom ? '' : t.dataset.dom; render(); }
  else if (a === 'ad-chip') { ADV[t.dataset.k] = t.dataset.v; ADV.lim = 50; render(); }
  else if (a === 'ad-filters') { ADV.filters = !ADV.filters; render(); }
  else if (a === 'ad-more') { ADV.lim += 50; render(); }
  else if (a === 'ad-pause') { ADV.paused = !ADV.paused; if (!ADV.paused) adFeedLoad(); render(); }
  else if (a === 'ad-probe') { const d = t.dataset.dom; go('routes'); setTimeout(() => { const i = $('probeInput'); if (i) i.value = d; siteCheck(d); }, 0); }
  else if (a === 'site-do') { if (t.dataset.how === 'block') { confirm = { id: 'site-block', dom: t.dataset.dom }; render(); } else siteDo(t.dataset.how, t.dataset.dom); }
  else if (a === 'site-move') { const m = RPROBE && RPROBE.move; t.disabled = true; cfgSet({ op: 'domain-list', target: t.dataset.list, value: t.dataset.to }, 'Список идёт через ' + tunLabel(t.dataset.to), ['lists']).then(x => { if (RPROBE) RPROBE.move = null; if (x && x.ok && m) siteCheck(RPROBE.value); }); }
  else if (a === 'tunnel-up' || a === 'tunnel-restart') tunnelState(a === 'tunnel-up' ? 'up' : 'restart', t.dataset.name);
  else if (a === 'vless-servers') vlessServers(t.dataset.name, true);
  else if (a === 'ai-check') aiCheck(t.dataset.ai, t.dataset.dom);
  else if (a === 'ai-answer') aiAnswer(t.dataset.way);
  else if (a === 'ai-reference') aiReference(t.dataset.ai, t.dataset.group, t.dataset.token);
  else if (a === 'ai-room') { if (!SVC.busy) aiJob(t.dataset.ai, 'dns', aiName(t.dataset.ai) + ': Smart DNS'); }
  else if (a === 'ai-dns-clear') smartdnsServer('clear', '');
  else if (a === 'svrec-resolve') svRecover(t.dataset.id, 'resolve');
  else if (a === 'journal-reload') load('journal', true).then(render, render);
  else if (a === 'ai-dns-clear-url') { const f = t.closest('.panel') && t.closest('.panel').querySelector('form[data-form="ai-dns-add"] input[name="server"]'); const v = f ? f.value.trim() : '';
    if (!/^https:\/\/[A-Za-z0-9.-]+(:[0-9]{1,5})?(\/[A-Za-z0-9._~\/-]{0,200})?$/.test(v)) { actionResult = { id: 'aidns', text: 'Вставьте в поле точный адрес сервера (https://…), который нужно убрать' }; render(); }
    else { smartdnsServer('clear', v); if (f) f.value = ''; } }
  else if (a === 'prop-more') { PROP_ALL = true; render(); }
  else if (a === 'vsrv-open') { const k = t.dataset.name + '|' + t.dataset.code; if (VOPEN.has(k)) VOPEN.delete(k); else VOPEN.add(k); render(); }
  else if (a === 'tunnel-probe') {
    const n = t.dataset.name; S.tprobe[n] = { busy: true }; render();
    apiGet('tunnel-probe', { name: n }).then(r => r, e => ({ ok: false, error: e.message }))
      .then(r => { S.tprobe[n] = Object.assign(r, { at: new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) }); render(); });
  }
  else if (a === 'backup-create') { actionResult = { id: 'backup', text: 'Создаём копию…' }; render(); apiPost('backup-control', { op: 'create' }).then(x => { toast(x.ok ? 'Копия создана' : 'Не выполнено: ' + errText(x)); actionResult = null; return load('backups', true); }, e => { toast('Ошибка: ' + e.message); actionResult = null; }).then(render); }
  else if (a === 'upd-reload') location.reload();
  else if (a === 'upd-close') updOverlayClose();
  else if (a === 'tun-close') tunOverlayClose();
  else if (a === 'tun-keep') { const k = TUN_KEEP; if (!k) return; tunOverlayClose(); tunnelJob(k.mode, Object.assign({}, k.fields, { keep: '1' }), k.label); }
  else if (a === 'tc-dup') {
    const d = TC_DUP, ch = t.dataset.choice, f = t.closest('form');
    if (!d) return;
    if (ch === 'cancel') { closeLayer(); return; }
    if (ch === 'replace') { closeLayer(); tunnelJob('replace', { op: 'replace', name: d.name, conf: d.text, confirm: 'TUNNEL_REPLACE' }, tunLabel(d.name)); return; }
    tcPreview(f, d.x, 'create', '');
  }
  else if (a === 'tun-open') { const n = t.dataset.name; tunOverlayClose(); go('t-' + n); }
  else if (a === 'agh-filters-refresh') aghSet({ setting: 'filters-refresh' }, 'Списки обновляются');
  else if (a === 'comp-ask') { confirm = { id: 'comp', comp: t.dataset.comp, act: t.dataset.cact, backup: true }; render(); }
  else if (a === 'comp-yes') { if (confirm && confirm.id === 'comp') compRun(confirm); }
  else if (a === 'tunnel-create') tunnelConfSheet('create');
  else if (a === 'tunnel-replace') tunnelConfSheet('replace', current.slice(2));
  else if (a === 'tunnel-delete') { const s2 = document.querySelector('[data-tunnel-del-to]'); confirm = { id: 'tunnel-delete', to: s2 ? s2.value : 'vpn' }; render(); }
  else if (a === 'tunnel-speed') {
    // One start per tap: two taps started two measurements of 10 MB a tunnel (Viva 2026-10-16).
    if (SPEED_STARTING || (S.tq && S.tq.auto && S.tq.auto.speed_running)) { toast('Замер скорости уже идёт'); return; }
    SPEED_STARTING = true;
    runAction('tunnel-speed', 'tunnel-quality', { op: 'speed' }, 'Замер скорости начат: 10 МБ через каждый туннель по очереди').then(() => load('tq', true)).then(render).finally(() => { SPEED_STARTING = false; });
  }
  else if (a === 'tunnel-health') runAction('tunnel-health', 'control', { op: 'tunnel-health' }, 'Проверка туннеля выполнена').then(() => load('status', true)).then(render);
  else if (a === 'page-reload') location.reload();
  else if (a === 'probe-report' && PROBE) openSheet('Проверка ' + PROBE.domain, '<div class="sheet-body"><pre class="logbox">' + esc(PROBE.out || '') + '</pre></div>', 'wide');
  else if (a === 'logout') apiPost('auth', { op: 'logout' }).then(() => { toast('Вы вышли'); S.auth = null; showLogin(); });
  else if (a === 'housekeeping') runLong('storage', 'control', { op: 'housekeeping' }, 'control-data', 'Журналы проверены').then(() => load('status', true)).then(render);
  else if (a === 'refresh-hints') runLong('routes', 'control', { op: 'refresh-hints' }, 'control-data', 'Подсказки обновлены').then(() => load('route', true)).then(render);
  else if (a === 'update-op') updateOp(t.dataset.op);
  else if (a === 'panel-reload') location.reload();
  else if (a === 'diag-run') diagRun();
  else if (a === 'agh-clients') aghClientsOp('sync');
  else if (a === 'ads-job') adsControl({ op: 'enqueue', job: t.dataset.job }, 'Задание поставлено в очередь', 'ads-job');
  else if (a === 'ads-job-run') { t.disabled = true; adsControl({ op: 'job-run' }, 'Очередь запущена', 'ads-job-run'); }
  else if (a === 'ads-job-cancel') { t.disabled = true; adsControl({ op: 'job-cancel', id: t.dataset.id }, 'Задание отменено', 'ads-job-run'); }
  else if (a === 'https-op') runAction('https', 'ads-https-control', { op: t.dataset.op }, 'Готово').then(() => load('https', true)).then(render);
  else if (a === 'act-more') activityMore(t.dataset.k);
  else if (a === 'act-reload') { loadActivity(t.dataset.k); render(); }
  else if (a === 'log-show') { logShown[logTab] = logN; loadLog(logTab, true); render(); }
  else if (a === 'log-more') { logShown[logTab] = Math.min(LOG_MAX, (logShown[logTab] || logN) + logN); loadLog(logTab, true); render(); }
  else if (a === 'log-filters') { logFilters = !logFilters; render(); }
  else if (a === 'log-n') { logN = +t.dataset.v; store.set('vward-log-n', String(logN)); if (logShown[logTab]) { logShown[logTab] = logN; loadLog(logTab, true); } render(); }
  // The order re-sorts the entries already here: no request.
  else if (a === 'log-order') { logNewest = t.dataset.v !== 'oldest'; store.set('vward-log-order', logNewest ? 'newest' : 'oldest'); if (LOGPARTS.length) S.logs.all = mergeLogs(LOGPARTS, logNewest, null, logShown.all || logN) || S.logs.all; render(); }
  else if (a === 'log-wrap') { logWrap = t.dataset.v !== '0'; render(); }
  else if (a === 'log-view') { logImportant = t.dataset.v !== 'all'; store.set('vward-log-view', logImportant ? 'important' : 'all'); render(); }
  else if (a === 'log-share') {
    // A phone's own share menu (copying is there); a computer copies the text.
    if (!logShown[logTab]) { toast('Сначала нажмите «Показать журнал»'); return; }
    const text = S.logs[logTab] || '';
    if (navigator.share) navigator.share({ title: 'Журнал VWARD: ' + logLabel(logTab), text: text }).catch(err => { if (err && err.name !== 'AbortError') copyText(text); });
    else copyText(text);
  }
  // «Скачать» saves what is on the screen: no new request, no redraw (owner 12.11.2026: the journal
  // reloaded on a download). Nothing shown yet: one quiet request, the page stays as it is.
  else if (a === 'log-save') { const tab = logTab, name = 'vward-' + tab + '-' + today() + '.txt';
    if (logShown[tab] && S.logs[tab] != null) download(name, S.logs[tab]);
    else loadLogOnce(tab).then(text => download(name, text || ''), e => toast('Журнал не скачан: ' + e.message)); }
  // The whole history, the archived journals included: the router packs it as it sends it.
  else if (a === 'log-save-all') { const l = document.createElement('a'); l.href = API + '?action=log-archive'; l.download = ''; document.body.appendChild(l); l.click(); l.remove(); toast('Архив журналов скачивается'); }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeLayer();
  if ((e.key === 'Enter' || e.key === ' ') && e.target.getAttribute && e.target.getAttribute('role') === 'button') { e.preventDefault(); e.target.click(); }
});
document.addEventListener('input', e => {
  if (e.target.id === 'searchInput') renderResults(e.target.value);
  // «Найти в журнале»: among the entries already here, as the owner types; no request.
  if (e.target.closest && e.target.closest('[data-form="log-search"]')) {
    logQuery = e.target.value; const b = $('logBox');
    if (b && logShown[logTab]) b.innerHTML = logFeed(logPick(S.logs[logTab], logQuery));
  }
});
// Filters a long list in place: no re-render per key press.
document.addEventListener('input', e => {
  if (!e.target.hasAttribute('data-list-filter')) return;
  const q = e.target.value.trim().toLowerCase();
  document.querySelectorAll('[data-list-rows] > li').forEach(li => { li.hidden = !!q && !li.textContent.toLowerCase().includes(q) && !(li.dataset.find || '').includes(q); });
});
document.addEventListener('change', e => {
  const t = e.target;
  if (t.dataset.journal) { cfgSet({ op: 'journal', target: 'keep', value: t.value }, 'Срок хранения: ' + ((JOURNAL_KEEP.find(k => String(k[0]) === t.value) || [])[1] || t.value).toLowerCase(), ['journal']); return; }
  if (t.hasAttribute('data-journal-size')) { const mb = JOURNAL_SIZE[+t.value]; cfgSet({ op: 'journal', target: 'size', value: String(mb) }, 'Предельный размер: ' + journalSizeText(mb).toLowerCase(), ['journal']); return; }
  if (t.dataset.tabpick) {
    const id = t.dataset.tabpick;
    if (t.checked) { if (tabIds.length >= TAB_MAX) { t.checked = false; toast('На панели помещается не больше ' + TAB_MAX + ' разделов'); return; } tabIds.push(id); }
    else { if (tabIds.length <= 1) { t.checked = true; toast('Оставьте хотя бы один раздел'); return; } tabIds = tabIds.filter(x => x !== id); }
    store.set('vward-tabs', tabIds); render(); return;
  }
  if (t.dataset.upd) { updateMode(t.value); return; }
  if (t.hasAttribute('data-upd-feed')) {
    const v = t.value; t.value = cfg().update && cfg().update.feed || ''; feedPick(v);
    return;
  }
  if (t.dataset.comp) {
    const id = t.dataset.comp, want = t.checked;
    t.checked = !want;
    if (!want) { confirm = { id: 'comp-off', comp: id }; render(); }
    else if (compCascade(id, false).length) { confirm = { id: 'comp-on', comp: id }; render(); }
    else cfgSet({ op: 'component', target: id, value: '1' }, '«' + compName(id) + '» включён', ['status'])
      .then(() => { if (id === 'tunnel-guard' && !guardOn()) cfgSet({ op: 'tunnel-guard', value: '1' }, '«' + compName(id) + '» включён', ['status']);
        // One switch for one part (fix.38): «Восстановление интернета» on is the component and its own switch.
        if (id === 'wan-guard' && cfg().wan_guard && cfg().wan_guard.enabled === false) cfgSet({ op: 'wan-guard', value: '1' }, '«' + compName(id) + '» включён'); });
    return;
  }
  if (t.dataset.agentAct) { const ag = t.dataset.agentAct, m = t.checked ? 'act' : 'watch'; t.disabled = true;
    cfgSet({ op: 'agents-mode', target: ag, value: m }, agentName(ag) + ': ' + (m === 'watch' ? 'песочница' : 'вкл')); return; }
  if (t.dataset.listPick) { if (t.checked) LISTPICK.add(t.dataset.listPick); else LISTPICK.delete(t.dataset.listPick); render(); return; }
  if (t.dataset.tunsw) {
    const n = t.dataset.tunsw;
    t.disabled = true; tunnelState(t.checked ? 'up' : 'down', n);
    return;
  }
  if (t.hasAttribute('data-cfg-wg')) {
    if (!t.checked) { t.checked = true; confirm = { id: 'wg-off' }; render(); return; }
    // On here is on everywhere: the component too, when it was switched off (fix.38).
    (async () => { if (!compOn('wan-guard')) await cfgSet({ op: 'component', target: 'wan-guard', value: '1' }, 'Восстановление интернета включено', ['status']);
      cfgSet({ op: 'wan-guard', value: '1' }, 'Восстановление интернета включено', ['status']); })();
    return;
  }
  if (t.hasAttribute('data-cfg-tg')) {
    if (!t.checked) { t.checked = true; confirm = { id: 'tg-off' }; render(); return; }
    (async () => { if (!compOn('tunnel-guard')) await cfgSet({ op: 'component', target: 'tunnel-guard', value: '1' }, 'Агент VPN включён', ['status']);
      cfgSet({ op: 'tunnel-guard', value: '1' }, 'Агент VPN включён', ['status']); })();
    return;
  }
  if (t.dataset.cfgWifi) {
    const key = t.dataset.cfgWifi, v = t.type === 'checkbox' ? (t.checked ? '1' : '0') : t.value;
    if (key === 'CONTROL_ENABLED' && v === '1') { t.checked = false; confirm = { id: 'wifi-ctl-on' }; render(); return; }
    cfgSet({ op: 'wifi', target: key, value: v }, 'Сохранено', ['wifi']); return;
  }
  if (t.dataset.cfgRt) { cfgSet({ op: t.dataset.cfgRt, value: t.checked ? '1' : '0' }, 'Сохранено'); return; }
  if (t.dataset.extra) { const id = t.dataset.extra; cfgSet({ op: 'extra', target: id, value: t.checked ? '1' : '0' }, compName(id) + (t.checked ? ': включено' : ': выключено'), ['status']); return; }
  if (t.dataset.ipcat) { cfgSet({ op: 'ip-category', target: t.dataset.ipcat, value: t.checked ? '1' : '0' }, t.checked ? 'Категория включена' : 'Категория выключена - применится при следующей сверке'); return; }
  if (t.dataset.cfgCat) { cfgSet({ op: 'domain-category', target: t.dataset.cfgCat, value: t.checked ? '1' : '0' }, t.checked ? 'Категория включена' : 'Категория выключена'); return; }
  if (t.dataset.wifiAccess) {
    if (!t.checked) { t.checked = true; confirm = { id: 'wifi-deny', mac: t.dataset.wifiAccess }; render(); return; }
    t.disabled = true; wifiHostSet({ op: 'access', mac: t.dataset.wifiAccess, value: 'permit' }, 'Интернет разрешён'); return;
  }
  if (t.dataset.agh) {
    const k = t.dataset.agh, v = t.checked ? '1' : '0';
    if (k === 'protection' && v === '0') { t.checked = true; confirm = { id: 'agh-protection-off' }; render(); return; }
    t.disabled = true;
    aghSet({ setting: k, value: v }, 'Сохранено в AdGuard Home'); return;
  }
  if (t.hasAttribute('data-agh-interval')) { aghSet({ setting: 'interval', value: t.value }, 'Сохранено в AdGuard Home'); return; }
  if (t.dataset.aghFilter) { t.disabled = true; aghSet({ setting: 'filter-enable', url: t.dataset.aghFilter, value: t.checked ? '1' : '0' }, t.checked ? 'Список включён' : 'Список выключен'); return; }
  if (t.dataset.aghService) { t.disabled = true; aghSet({ setting: 'service', service: t.dataset.aghService, value: t.checked ? '1' : '0' }, t.checked ? 'Сервис заблокирован' : 'Сервис открыт'); return; }
  if (t.hasAttribute('data-awg-adopt')) { const fs = [...(t.files || [])]; if (fs.length) awgAdopt(fs); return; }
  if (t.hasAttribute('data-conf-file')) {
    const file = t.files && t.files[0], form = t.closest('form');
    if (!file) return;
    if (file.size > 16384) { toast('Файл больше 16 КБ - это не .conf'); return; }
    const r = new FileReader();
    r.onload = () => {
      form.querySelector('[name=conf]').value = String(r.result || ''); form.dataset.checked = ''; $('tcPreview').innerHTML = ''; form.querySelector('[type=submit]').hidden = false; form.querySelector('[type=submit]').textContent = 'Проверить';
      const d = form.querySelector('[name=description]');
      if (d && !d.value.trim()) d.value = confName(file.name);
    };
    r.readAsText(file);
    return;
  }
  if (t.dataset.svc) { const id = t.dataset.svc, x = ((S.services && S.services.services) || []).find(v => v.id === id), title = x ? x.title : id; t.disabled = true;
    serviceJob(t.checked ? { op: 'on', id: id, tunnel: 'auto' } : { op: 'off', id: id }, t.checked ? title + ' идёт через VPN' : title + ' идёт напрямую'); return; }
  if (t.dataset.svcCat) { const c = t.dataset.svcCat, v = t.value, ct = ((S.services && S.services.categories) || []).find(x => x.id === c); t.disabled = true;
    serviceJob({ op: 'category', id: c, tunnel: v }, (ct ? ct.title : c) + (v === 'auto' ? ': туннель выбирается автоматически' : ': через ' + tunLabel(v))); return; }
  if (t.dataset.svcTun) { const id = t.dataset.svcTun, v = t.value; t.disabled = true; serviceJob({ op: 'tunnel', id: id, tunnel: v }, v === 'auto' ? 'Туннель выбирается автоматически' : 'Закреплён за ' + tunLabel(v)); return; }
  if (t.name === 'vless-server') { const f = t.closest('form'), d = f && f.querySelector('[name=description]'), names = [...f.querySelectorAll('[name=vless-server]')].map(r => tunDesc(r.dataset.vname));
    if (d && (!d.value.trim() || names.includes(d.value.trim()))) d.value = tunDesc(t.dataset.vname); return; }
  if (t.dataset.cfgTa) { const k = t.dataset.cfgTa, v = t.type === 'checkbox' ? (t.checked ? '1' : '0') : t.value; t.disabled = true;
    cfgSet({ op: 'tunnel-auto', target: k, value: v }, k === 'enabled' ? (v === '1' ? 'Выбор лучшего туннеля включён' : 'Выбор лучшего туннеля выключен') :
      k === 'criterion' ? 'Выбирать туннель по: ' + (TQ_CRITERIA.find(o => o[0] === v) || [, v])[1] : 'Замер скорости: ' + (TQ_SPEED.find(o => o[0] === v) || [, v])[1], ['tq']); return; }
  if (t.dataset.cfgTq) { const on = t.checked; t.disabled = true; cfgSet({ op: t.dataset.cfgTq, value: on ? '1' : '0' }, t.dataset.cfgTq === 'tunnel-fallback' ? (on ? 'Запасной туннель включён' : 'Запасной туннель выключен') : (on ? 'Возврат на основной включён' : 'Возврат на основной выключен'), ['tq']); return; }
  if (t.dataset.listVia) { const v = t.value; t.disabled = true; cfgSet({ op: 'domain-list', target: t.dataset.listVia, value: v }, v === 'bypass' ? 'Список идёт через провайдера' : 'Список идёт через ' + v, ['lists']); return; }
  if (t.hasAttribute('data-theme-pick')) { setTheme(t.value); return; }
  if (t.hasAttribute('data-sd-feature')) {
    if (!t.checked) { t.checked = true; confirm = { id: 'sd-off' }; render(); return; }
    cfgSet({ op: 'smartdns-feature', value: '1' }, 'Smart DNS включён', ['ai', 'lists']); return;
  }
  if (t.hasAttribute('data-smartdns-guard')) { cfgSet({ op: 'smartdns-guard', value: t.checked ? '1' : '0' }, t.checked ? 'Агент Smart DNS включён' : 'Агент Smart DNS выключен', ['lists']); return; }
  if (t.dataset.extAuto) { cfgSet({ op: 'ext-auto', target: t.dataset.extAuto, value: t.checked ? '1' : '0' }, t.checked ? 'Будет обновляться автоматически' : 'Обновление только вручную', ['ext']); return; }
  if (t.hasAttribute('data-policy-group')) { if (t.value) cfgSet({ op: 'policy-group', target: t.value }, 'Мои домены теперь добавляются в ' + t.value, ['route', 'security']); return; }
  if (t.hasAttribute('data-fw-auto')) { t.disabled = true; cfgSet({ op: 'firmware', target: 'auto', value: t.checked ? '1' : '0' }, t.checked ? 'Keenetic будет обновляться автоматически' : 'Прошивка обновляется только вручную', ['ext']); return; }
  if (t.hasAttribute('data-fw-channel')) {
    const v = t.value;
    if (v !== 'stable') { t.value = ((S.ext || {}).firmware || {}).channel || 'stable'; confirm = { id: 'fw-channel', value: v }; render(); return; }
    t.disabled = true; cfgSet({ op: 'firmware', target: 'channel', value: v }, 'Канал прошивки: ' + fwChannel(v), ['ext']); return;
  }
  if (t.dataset.cfgWanp) { cfgSet({ op: 'wan-param', target: t.dataset.cfgWanp, value: t.value }, 'Сохранено', ['config']); return; }
  if (t.dataset.cfgUpd) { cfgSet({ op: 'update', target: t.dataset.cfgUpd, value: t.value }, 'Сохранено', ['status']); return; }
  if (t.dataset.dnsg === 'enforce') { dnsGuardSet('enforce', t.checked ? '1' : '0', t.checked ? 'Все устройства теперь через AdGuard Home' : 'Фильтрация для всех устройств выключена'); return; }
  if (t.dataset.dnsg === 'chain') { dnsGuardSet('chain', t.checked ? '1' : '0', t.checked ? 'AdGuard Home снова выводится из DNS при сбое' : 'AdGuard Home больше не выводится из DNS при сбое'); return; }
  if (t.dataset.dnsg === 'bypass') { if (t.checked) { t.checked = false; confirm = { id: 'dnsg-bypass' }; render(); } else dnsGuardSet('bypass', '0', 'Обход фильтрации снова разрешён'); return; }
  if (t.matches('[data-vsrv-group]')) { VVIEW.group = t.checked; vViewSave(); render(); return; }
  if (t.dataset.vcountry) { vlessCountry(t.dataset.name, t.dataset.vcountry, t.checked); return; }
  if (t.dataset.vcross) { vlessCountry(t.dataset.vcross, 'cross', t.checked); return; }
  if (t.dataset.aiTunnel) { if (!SVC.busy) aiJob(t.dataset.aiTunnel, t.value, 'Туннель выбран'); return; }
  if (t.dataset.tunOnoff) {
    const n = t.dataset.tunOnoff;
    if (t.checked) { tunnelState('up', n); return; }
    t.checked = true; confirm = { id: 'tunnel-down' }; render(); return;
  }
  if (t.dataset.dnsex) {
    const g = (S.ads && S.ads.dns_guard) || {}, cur = (g.exclude || '').split(',').filter(Boolean).filter(m => m !== t.dataset.dnsex);
    if (t.checked) cur.push(t.dataset.dnsex);
    dnsGuardSet('exclude', cur.length ? cur.join(',') : '-', t.checked ? 'Устройство исключено' : 'Устройство снова под защитой'); return;
  }
  if (t.hasAttribute('data-ads-clients')) { aghClientsOp(t.checked ? 'on' : 'off'); return; }
  if (t.hasAttribute('data-route-dns')) { routeDnsOp(t.checked ? 'on' : 'off'); return; }
  if (t.hasAttribute('data-ads-pause')) { adsControl({ op: t.checked ? 'resume' : 'pause' }, t.checked ? 'Блокировка включена' : 'Блокировка на паузе'); return; }
  if (t.dataset.adsSet) { adsSetting(t.dataset.adsSet, t.type === 'checkbox' ? (t.checked ? '1' : '0') : t.value); return; }
  if (t.hasAttribute('data-auth-devices')) {
    const on = t.checked;
    apiPost('auth', { op: 'devices', value: on ? '1' : '0' }).then(x => { toast(x.ok ? (on ? 'VWARD открыт только зарегистрированным устройствам' : 'VWARD открыт всем устройствам домашней сети') : 'Не сохранено: ' + errText(x)); return load('auth', true); }, e => toast('Ошибка: ' + e.message)).then(render);
    return;
  }
  if (t.hasAttribute('data-auth')) {
    const au = S.auth || {};
    if (t.checked && !au.enabled) { authForm = true; render(); }
    else if (!t.checked && authForm && !au.enabled) { authForm = false; render(); }
    else if (!t.checked && au.enabled) { t.checked = true; confirm = { id: 'auth-off' }; render(); }
    return;
  }
  if (t.hasAttribute('data-ads-autopub')) { if (t.checked) { t.checked = false; confirm = { id: 'ads-autopub' }; render(); } else adsSetting('AUTO_PUBLISH', '0').then(() => load('adspub', true)).then(render); return; }
  if (t.dataset.adsCat) { adsControl({ op: 'source-category', category: t.dataset.adsCat, state: t.checked ? 'on' : 'off' }, t.checked ? 'Категория включена' : 'Категория выключена', 'ads-rule'); return; }
  if (t.dataset.adsSource) { adsControl({ op: 'source-mode', source: t.dataset.adsSource, mode: t.value }, 'Режим источника изменён', 'ads-rule'); return; }
});
// A field with its button inside shows the button busy until the form's work is done.
document.addEventListener('submit', async e => {
  e.preventDefault();
  const b = e.target.classList.contains('input-bar') ? e.target.querySelector('.input-bar-btn') : null;
  if (b && b.disabled) return;
  if (b) { b.classList.add('busy'); b.disabled = true; }
  try { await onSubmit(e, e.target.dataset.form); }
  finally { if (b && b.isConnected) { b.classList.remove('busy'); b.disabled = false; } }
});
async function onSubmit(e, f) {
  // «Найти в журнале» filters as the owner types (the input handler); Enter changes nothing.
  if (f === 'log-search') return;
  if (f === 'ai-dns-add') {
    const v = e.target.querySelector('input').value.trim();
    if (!/^https:\/\/[A-Za-z0-9.-]+(:\d{1,5})?(\/[A-Za-z0-9._~\/-]{0,200})?$/.test(v)) { fieldErr(e.target, 'Адрес DoH: https://сервер/путь'); return; }
    await smartdnsServer('set', v); e.target.reset();
    return;
  }
  if (f === 'probe') {
    const v = hostOf($('probeInput').value);
    if (!IPV4.test(v) && !DOMAIN.test(v)) { RPROBE = { error: 'Требуется домен (например, youtube.com), ссылка или IPv4-адрес.' }; render(); return; }
    await siteCheck(v);
  }
  if (f === 'list-add') {
    const input = e.target.querySelector('input'), v = input.value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/[/:].*$/, '').replace(/^\*\./, '');
    if (!DOMAIN.test(v)) { fieldErr(e.target, 'Введите домен, например example.com'); return; }
    const kind = e.target.dataset.kind;
    const x = await cfgSet({ op: 'list-domain', action: kind, target: current.slice(2), value: v }, kind === 'add' ? v + ' добавлен в список' : v + ' добавлен в исключения', ['listd', 'lists']);
    if (x && x.ok) { const again = document.querySelector('form[data-form="list-add"][data-kind="' + kind + '"] input'); if (again) again.value = ''; }
  }
  if (f === 'cfg-add') {
    const input = e.target.querySelector('input'), v = input.value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/[/:].*$/, '').replace(/^\*\./, '');
    if (!DOMAIN.test(v)) { fieldErr(e.target, 'Введите домен, например example.com'); return; }
    const x = await cfgSet({ op: e.target.dataset.op, action: 'add', target: v }, v + ' добавлен', ['route']);
    if (x && x.ok) { const again = document.querySelector('form[data-form="cfg-add"] input'); if (again) again.value = ''; }
  }
  if (f === 'wifi-name') {
    const v = e.target.querySelector('[name=name]').value.trim();
    if (!v || v.length > 32 || /["\\]/.test(v)) { fieldErr(e.target, 'Имя: до 32 символов, без кавычек'); return; }
    await wifiHostSet({ op: 'name', mac: e.target.dataset.mac, name: v }, 'Имя сохранено в Keenetic'); return;
  }
  if (f === 'agh-filter-add') {
    const url = e.target.querySelector('[name=url]').value.trim(), name = e.target.querySelector('[name=name]').value.trim();
    if (!/^https:\/\/[A-Za-z0-9.-]+(:\d{1,5})?\/\S*$/.test(url)) { fieldErr(e.target, 'Нужен адрес https://…'); return; }
    if (!/^[A-Za-z0-9 ._-]{1,64}$/.test(name)) { fieldErr(e.target, 'Название: латиница, цифры, пробел, точка, дефис'); return; }
    await aghSet({ setting: 'filter-add', url: url, name: name }, 'Список добавлен'); return;
  }
  if (f === 'tunnel-subnet') {
    const v = e.target.querySelector('[name=subnet]').value.trim();
    if (!/^\d{1,3}(\.\d{1,3}){3}(\/\d{1,2})?$/.test(v)) { fieldErr(e.target, 'Введите подсеть, например 149.154.160.0/20'); return; }
    await tunnelSubnet(e.target.dataset.name, 'add', v); return;
  }
  if (f === 'tunnel-conf') {
    const form = e.target, mode = form.dataset.mode, name = form.dataset.name, manual = !form.querySelector('.tc-manual').hidden;
    if (manual && TC_FIELDS.slice(0, 4).some(f => !form.querySelector('[name="tc-' + f[0] + '"]').value.trim())) { tcMsg('Заполните ключ, адрес, ключ сервера и сервер'); return; }
    if (form.dataset.checked !== '1') $('tcPreview').innerHTML = '';
    let text = manual ? tcConf(form) : form.querySelector('[name=conf]').value;
    const descEl = form.querySelector('[name=description]');
    if (!manual && vpnKey(text)) { const k = await amneziaKey(vpnKey(text)); if (k.error) { tcMsg(k.error); return; } text = k.conf; if (descEl && !descEl.value.trim() && k.name) descEl.value = k.name; }
    // VLESS: links or a subscription; the server is chosen from the list the router reads.
    if (!manual && /^\s*(vless|trojan|https?):\/\//i.test(text)) {
      if (mode !== 'create') { tcMsg('VLESS-туннель не заменяется: добавьте новый и удалите старый'); return; }
      if (form.dataset.checked !== '1') {
        let x;
        try { x = await apiPost('tunnel-conf', { op: 'check', conf: text.trim() }); } catch (err) { tcMsg('Ошибка: ' + err.message); return; }
        if (!x.ok) { tcMsg('Не подходит: ' + errText(x)); return; }
        const n = +x.servers || 0, rows = [];
        for (let i = 1; i <= n; i++) { if (!x['server.' + i]) continue; const p = String(x['server.' + i]).split('|'); if (!p[1] || !p[2]) continue; rows.push({ i: i, name: p[0] || 'Сервер ' + i, host: p[1] || '', port: p[2] || '', sec: p[3] || 'none', net: p[4] || 'tcp' }); }
        if (!rows.length) { tcMsg('В ссылке или подписке нет серверов VLESS'); return; }
        $('tcPreview').innerHTML = '<div class="rows vless-pick" role="radiogroup" aria-label="Сервер">' + rows.map(r => '<label class="row"><input type="radio" name="vless-server" value="' + r.i + '"' + (r === rows[0] ? ' checked' : '') + ' data-vname="' + esc(r.name) + '">' +
          '<div class="row-main"><b>' + esc(r.name) + '</b><small>' + esc(r.host + ':' + r.port + ' · ' + (r.sec === 'none' ? 'без шифрования' : r.sec.toUpperCase()) + ' · ' + r.net) + '</small></div></label>').join('') + '</div>' +
          '<p class="field-warn">Туннель поднимет Xray - программа около 36 МБ на флешке, скачивается один раз с GitHub (XTLS/Xray-core), 30-60 МБ памяти. В Keenetic он будет подключением OpkgTun.</p>';
        // The subscription's own name, not the first server's (owner 2026-10-18).
        if (descEl && !descEl.value.trim()) descEl.value = tunDesc(x.title) || 'VLESS';
        form.dataset.checked = '1';
        form.querySelector('[type=submit]').textContent = 'Создать туннель';
        return;
      }
      const pick = form.querySelector('[name=vless-server]:checked'), num = pick ? pick.value : '1';
      const vdesc = tunDesc(descEl && descEl.value) || 'VLESS';
      closeLayer();
      await tunnelJob('create', { op: 'create', conf: '#server=' + num + '\n' + text.trim(), description: vdesc }, vdesc);
      return;
    }
    const desc = descEl ? tunDesc(descEl.value) : '';
    if (!manual && (!/\[Interface\]/i.test(text) || !/\[Peer\]/i.test(text))) { tcMsg('Выберите файл .conf или вставьте его текст или ключ vpn://'); return; }
    if (mode === 'create' && !desc) { tcMsg('Введите название туннеля'); return; }
    if (form.dataset.checked !== '1') {
      let x;
      try { x = await apiPost('tunnel-conf', { op: 'check', conf: text }); } catch (err) { tcMsg('Ошибка: ' + err.message); return; }
      if (!x.ok) { tcMsg('Файл не подходит: ' + errText(x)); return; }
      if (mode === 'create' && (x.same || x.sameaddr)) { tcDup(form, x, text, desc); return; }
      tcPreview(form, x, mode, name);
      return;
    }
    closeLayer();
    await tunnelJob(mode, mode === 'create' ? { op: 'create', conf: text, description: desc } : { op: 'replace', name: name, conf: text, confirm: 'TUNNEL_REPLACE' }, mode === 'create' ? desc : tunLabel(name));
    return;
  }
  if (f === 'blocked-login') {
    const login = e.target.querySelector('[name=login]').value.trim(), password = e.target.querySelector('[name=password]').value;
    if (!/^[A-Za-z0-9._@-]{1,64}$/.test(login) || !password) { fieldErr(e.target, 'Введите логин и пароль Keenetic'); return; }
    let x;
    try { x = await apiPost('auth', { op: 'login', login: login, password: password }); }
    catch (err) { fieldErr(e.target, 'Ошибка: ' + err.message); return; }
    e.target.querySelector('[name=password]').value = '';
    if (!x.ok) { fieldErr(e.target, errText(x)); return; }
    location.reload();
    return;
  }
  if (f === 'agh-connect') {
    const login = e.target.querySelector('[name=login]').value.trim(), password = e.target.querySelector('[name=password]').value;
    if (!/^[A-Za-z0-9._@-]{1,64}$/.test(login) || !password) { fieldErr(e.target, 'Введите логин и пароль AdGuard Home'); return; }
    let x;
    try { x = await apiPost('agh-auth', { op: 'connect', login: login, password: password }); }
    catch (err) { fieldErr(e.target, 'Ошибка: ' + err.message); return; }
    e.target.querySelector('[name=password]').value = '';
    if (!x.ok) { fieldErr(e.target, errText(x)); return; }
    toast('AdGuard Home подключён');
    await Promise.all([load('ads', true), load('adsstats', true)]); render(); return;
  }
  if (f === 'login' || f === 'auth-enable') {
    const login = e.target.querySelector('[name=login]').value.trim(), password = e.target.querySelector('[name=password]').value;
    if (!/^[A-Za-z0-9._@-]{1,64}$/.test(login) || !password) { fieldErr(e.target, 'Введите логин и пароль'); return; }
    let x;
    try { x = await apiPost('auth', { op: f === 'login' ? 'login' : 'enable', login: login, password: password }); }
    catch (err) { fieldErr(e.target, 'Ошибка: ' + err.message); return; }
    e.target.querySelector('[name=password]').value = '';
    if (!x.ok) { fieldErr(e.target, errText(x)); return; }
    loginOpen = false; authForm = false; closeLayer();
    toast(f === 'login' ? 'Вы вошли' : 'Вход включён');
    await Promise.all(['auth', 'security', 'status'].map(k => load(k, true)));
    refreshPage();
  }
  if (f === 'ads-qsearch' || f === 'ads-bsearch' || f === 'ads-asearch') {
    const v = e.target.querySelector('input').value.trim().toLowerCase();
    if (v && !/^[a-z0-9.-]{1,100}$/.test(v)) { fieldErr(e.target, 'Только буквы, цифры, точки и дефисы'); return; }
    if (f === 'ads-qsearch') { ADSV.search = v; S.qlog = null; render(); await load('qlog', true); }
    else if (f === 'ads-asearch') { ADSV.allowedSearch = v; S.allowed = null; render(); await load('allowed', true); }
    else { ADSV.blockedSearch = v; S.blocked = null; render(); await load('blocked', true); }
    render();
  }
  if (f === 'ads-srcadd') {
    const url = e.target.querySelector('[name=url]').value.trim();
    if (!/^https:\/\/[A-Za-z0-9.-]+(:[0-9]{1,5})?\/[A-Za-z0-9._~\/%+=&?-]*$/.test(url) || url.length > 300) { fieldErr(e.target, 'Нужен адрес https://…, без пробелов и логина'); return; }
    const x = await adsControl({ op: 'source-add', url: url, format: e.target.querySelector('[name=format]').value }, 'Источник добавлен в режиме «Проверка»', 'ads-src');
    if (x && x.ok) adsControl({ op: 'enqueue', job: 'sources-update' }, 'Источник добавлен, загрузка поставлена в очередь', 'ads-src');
  }
  if (f === 'ads-check') {
    const raw = $('adsCheck').value, v = hostOf(raw);
    if (!DOMAIN.test(v)) { ADSCHK = { value: v, error: 'Требуется домен (например, ads.example.com) или ссылка.' }; render(); return; }
    await adsCheck(v, raw.trim()); return;
  }
  if (f === 'ads-probe') {
    const v = $('adsProbe').value.trim().toLowerCase();
    if (!DOMAIN.test(v)) { fieldErr(e.target, 'Введите домен, например example.com'); return; }
    adsProbe(v);
  }
  if (f === 'ads-rule') {
    const v = $('adsRuleDomain').value.trim().toLowerCase();
    if (!DOMAIN.test(v)) { fieldErr(e.target, 'Введите домен, например example.com'); return; }
    await adsControl({ op: $('adsRuleType').value, domain: v, scope: $('adsRuleScope').value }, 'Правило добавлено', 'ads-rule');
  }
}

/* ---------- Тема и обновление данных ---------- */
// «По времени суток»: светлая с 07:00 до 20:00, тёмная ночью.
const THEMES = { system: 'как в системе', time: 'по времени суток', light: 'светлая', dark: 'тёмная' };
function applyTheme() {
  const r = document.documentElement, h = new Date().getHours();
  const t = theme === 'time' ? (h >= 7 && h < 20 ? 'light' : 'dark') : theme;
  if (t === 'system') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', t);
  $('themeBtn').innerHTML = ico(theme === 'light' ? 'sun' : theme === 'dark' ? 'moon' : 'auto');
  $('themeBtn').setAttribute('aria-label', 'Тема: ' + THEMES[theme]);
}
function setTheme(v) { theme = THEMES[v] ? v : 'system'; store.set('vward-theme', theme); applyTheme(); if (current === 'settings') render(); }
let timer = null;
// A hidden tab does not poll the router; it catches up as soon as it is shown.
function tick() {
  if (document.hidden) return;
  const ph = plat().phase;
  if (UPD_BUSY.includes(ph)) updOverlayShow({ op: ph === 'ROLLING_BACK' ? 'rollback' : 'apply', phase: ph, done: false });
  else if (updOverlay && !updOverlay.done && !updOverlay.manual && ph === 'IDLE' && updOverlay.seenBusy) updOverlayShow({ done: true, ok: true, version: plat().version });
  if (updOverlay && UPD_BUSY.includes(ph)) updOverlay.seenBusy = true;
  if (theme === 'time') applyTheme();
  if (current !== 'logs') refreshPage(false, true);
  if (current === 'd-adaptive' && !ADV.paused) adFeedLoad();
  load('status', true).then(renderNav);
}
function restartTimer() {
  if (timer) clearInterval(timer);
  timer = setInterval(tick, REFRESH_SEC * 1000);
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) return;
  // tick() reloads the open journal too; otherwise the journal alone.
  if (Date.now() - (S.loadedAt.status || 0) >= REFRESH_SEC * 1000) tick();
});

$('backBtn').innerHTML = ico('back');
$('backBtn').addEventListener('click', () => { if (histDepth() > 0) history.back(); else go(parentOf(current) || 'overview', null, 'replace'); });
window.addEventListener('popstate', e => {
  // No state: the address was typed or a link changed it.
  const s = e.state || { p: idOf(location.pathname) || 'overview', d: 0 };
  if (!e.state) history.replaceState({ p: page(s.p) ? s.p : 'overview', d: histDepth() }, '', pathOf(page(s.p) ? s.p : 'overview'));
  if ($('layer').innerHTML) closeLayer(true);
  if (s.p !== current) go(s.p, null, 'pop');
});
WIDE.addEventListener('change', renderNav);
$('searchBtn').innerHTML = ico('search');
$('searchBtn').addEventListener('click', openSearch);
$('bellBtn').addEventListener('click', openNotes);
$('themeBtn').addEventListener('click', () => { setTheme(({ system: 'time', time: 'light', light: 'dark', dark: 'system' })[theme] || 'system'); toast('Тема: ' + THEMES[theme]); });
applyTheme();
{ const h = decodeURIComponent(location.hash.slice(1)), id = h && page(h) ? h : idOf(location.pathname); if (id && page(id)) current = id; }
cacheRead();
history.replaceState({ p: current, d: 0 }, '', pathOf(current));
busyStart(current);
render();
Promise.all(['status', 'security', 'update'].map(k => load(k))).then(() => { render(); refreshPage(true); });
restartTimer();
})();
